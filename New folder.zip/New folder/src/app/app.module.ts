import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LoginComponent } from './auth/login/login.component';
import { MaterialModule } from './_helpers/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { TopNavComponent } from './layout/top-nav/top-nav.component';
import { SideNavComponent } from './layout/side-nav/side-nav.component';
import { FooterComponent } from './layout/footer/footer.component'; 
import { ContentComponent } from './layout/content/content.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { TablesComponent } from './components/tables/tables.component';
import { RegisterComponent } from './auth/register/register.component';
import { BreadcrumbComponent } from './_helpers/breadcrumb/breadcrumb.component';
import { ProfileComponent } from './components/profile/profile.component';
import { IconsComponent } from './components/icons/icons.component';
import { ProductsComponent } from './components/products/products.component';
import { DocsComponent } from './components/docs/docs.component';
 
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    TopNavComponent,
    SideNavComponent,
    FooterComponent, 
    ContentComponent, DashboardComponent, TablesComponent, RegisterComponent, BreadcrumbComponent, ProfileComponent, IconsComponent, ProductsComponent, DocsComponent 
     
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    BrowserAnimationsModule,
   FormsModule,
   ReactiveFormsModule,
   HttpClientModule,
   
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
