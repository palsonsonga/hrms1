import { Component, Input, OnInit, Output } from '@angular/core';
import * as EventEmitter from 'events';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.css']
})
export class TopNavComponent implements OnInit {

@Output('toggle')  togglr=new EventEmitter
nav
  constructor() { }

  ngOnInit(): void {
  }

  toggle(){ 
   this.togglr.emit(this.nav)
  }
}
