import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {
menuItems=[
  {path:'/dashboard',title:'Dashboard',icon:'',type:'link',active:true,children:[]},
  {path:'/profile',title:'Profile',icon:'',type:'link',active:true,children:[]}, 
  {path:'/icons',title:'Icons',icon:'',type:'link',active:true,children:[]},
  {path:'/tables',title:'Tables',icon:'',type:'link',active:true,children:[]},
  {path:'/google',title:'Google',icon:'',type:'link',active:true,children:[]}, 
  {path:'/login',title:'Login',icon:'',type:'link',active:true,children:[]},
  {path:'/register',title:'Register',icon:'',type:'link',active:true,children:[]},
  {title:'Logout',icon:'',type:'logout',active:true,children:[]},
  {path:'/docs',title:'Docs',icon:'',type:'link',active:true,children:[]},
  {path:'/products',title:'Products',icon:'',type:'link',active:true,children:[]}
]
  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  logout(){ 
    sessionStorage.removeItem('user')
    this.router.navigate(['/login'])
  }
}
