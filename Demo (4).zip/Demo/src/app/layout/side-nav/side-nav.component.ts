import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {
menuItems=[
  {path:'/dashboard',title:'Dashboard',icon:'fa fa-tv text-primary ',type:'link',active:true,children:[]},
  {path:'/profile',title:'Profile',icon:'fa fa-user text-dark ',type:'link',active:true,children:[]}, 
  {path:'/icons',title:'Icons',icon:'fa fa-info-circle text-info',type:'link',active:true,children:[]},
  {path:'/tables',title:'Tables',icon:'fa fa-list-ul text-warning ',type:'link',active:true,children:[]},
  {path:'/google',title:'Google',icon:'fa fa-map-marker  text-success ',type:'link',active:true,children:[]}, 
  {path:'/logged-in',title:'Login',icon:'fa fa-sign-in text-link ',type:'link',active:true,children:[]},
  {path:'/register',title:'Register',icon:'fa fa-address-card text-danger',type:'link',active:true,children:[]},
  {path:'/logout',title:'Logout',icon:'fa fa-sign-out text-info ',type:'link',active:true,children:[]}
]
reSources=[ 
  {path:'/docs',title:'Docs',icon:'fa fa-rocket text-secondary ',type:'re-link',active:true,children:[]},
  {path:'/products',title:'Products',icon:'fa fa-square  text-secondary ',type:'re-link',active:true,children:[]}
]
  constructor(private router:Router) { }

  ngOnInit(): void {
  }
 
}
