import { HttpClient } from '@angular/common/http'; 
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

// const data =[
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:90},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:40},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
//   {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60}
//      ]
@Injectable({
  providedIn: 'root'
})
export class TableService {
proData
url: string = 'api/tableData'
  constructor(private http:HttpClient) { }

  getData():Observable<any>{
   // this.proData=data
    return this.proData
  }

  getTableDataList(){
    return this.http.get(this.url)
  }
   saveTableData(tableData: any) { 
    return this.http.post(this.url, tableData);
  }

  updateTableData(tableData: any, id: any) {
    return this.http.put(this.url+'/' + id, tableData);
  }

  deleteTableData(id: any){
    console.log(id)
    return this.http.delete(this.url+'/' + id);
  }
}
