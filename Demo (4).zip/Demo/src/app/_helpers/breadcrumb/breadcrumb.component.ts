import { Component, OnInit, ɵConsole } from '@angular/core';
import { ActivatedRoute, Router,NavigationEnd,Data, PRIMARY_OUTLET } from '@angular/router';
import { filter, distinctUntilChanged, map, subscribeOn } from 'rxjs/operators';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.css']
})
export class BreadcrumbComponent implements OnInit {
title='Dashboard'
url='/dashboard'
label='dashboard'
  constructor(private router:Router, private _ar:ActivatedRoute) { 
  
  }

  ngOnInit()  {
   this.router.events.pipe(filter(event => event instanceof NavigationEnd)).subscribe(res=>{
        let data:any =res
        this.url=data.urlAfterRedirects
        //console.log(this.url)
        this._ar.children[0].data.subscribe(data=>{
          this.title =data['breadcrumb']
          this.label = this.title.toLowerCase()
         // console.log(this.url)
   })
    }) 
  }

}
