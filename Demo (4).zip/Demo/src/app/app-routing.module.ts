import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { LoginComponent } from './auth/login/login.component';
import { RegisterComponent } from './auth/register/register.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DocsComponent } from './components/docs/docs.component';
import { GoogleComponent } from './components/google/google.component';
import { IconsComponent } from './components/icons/icons.component';
import { LoggedInComponent } from './components/logged-in/logged-in.component';
import { LogoutComponent } from './components/logout/logout.component';
import { ProductsComponent } from './components/products/products.component';
import { ProfileComponent } from './components/profile/profile.component';
import { TablesComponent } from './components/tables/tables.component';
import { ContentComponent } from './layout/content/content.component';


const routes: Routes = [
  {path:'',component:ContentComponent,children:
      [
        {path:'dashboard',component:DashboardComponent,data:{ breadcrumb:'Dashboard'
}},
        {path:'tables',component:TablesComponent,data:{
          breadcrumb:'Tables'
        }},
        {path:'profile',component:ProfileComponent,data:{
          breadcrumb:'Profile'
        }},
        {path:'icons',component:IconsComponent,data:{
          breadcrumb:'Icons'
        }},
        {path:'google',component:GoogleComponent,data:{
          breadcrumb:'Google'
        }},
        {path:'products',component:ProductsComponent,data:{
          breadcrumb:'Products'
        }},
        {path:'docs',component:DocsComponent,data:{
          breadcrumb:'Docs'
        }},
  {path:'register',component:RegisterComponent,data:{
    breadcrumb:'Register'
  }},
  {path:'logout',component:LogoutComponent,data:{
    breadcrumb:'Logout'
  }},
  {path:'logged-in',component:LoggedInComponent,data:{
    breadcrumb:'Login'
  }},
      ],canActivate:[AuthGuard]
  },
  {path:'login',component:LoginComponent,canDeactivate:[AuthGuard]},
  {path:'**',redirectTo:'dashboard',pathMatch:'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
