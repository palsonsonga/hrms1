import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class TableDataListService implements InMemoryDbService {

  constructor() { }
  createDb() {
    let tableData = [
      { id: 1,icon:'fa fa-home', project: 'pro', budget: '$2000 USD', status: 'completed',path:'assets/download.png ', users: "arjun, john, sam", completion: 100 },
      {id:2, project: 'Angular', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:3, project: 'pro', budget: '$1255', status: 'delayed', users:"arjun, john , sam", completion: 40 },
      {id:4, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:5, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:6, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:7, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:8, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:9, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
    ]

    return { tableData };
  }
}
