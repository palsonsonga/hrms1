package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.HrmsAdminApplication;
import com.hrms.admin.dto.DesignationDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.exceptions.DesignationRecordNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.DesignationService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for Designation Record
 * 
 * @author {Ramesh}
 *
 */
@CrossOrigin
@RestController
@RequestMapping("/admin/designation")
public class DesignationController {

	private static final Logger logger = LoggerFactory.getLogger(HrmsAdminApplication.class);

	@Autowired
	DesignationService designationService;

	/**
	 * Returns All Designations data when designation data is available
	 * 
	 * @return - List of DesignationResponseModel
	 */

	/*
	 * @GetMapping public Map<String, Object> getAll(@RequestParam(defaultValue =
	 * "0") Integer pageIndex,
	 * 
	 * @RequestParam(defaultValue = "5") Integer pageSize){
	 * 
	 * try{ List<DesignationResponse> allDesignations =
	 * designationService.getAllDesignations(); logger.debug("Found " +
	 * allDesignations.size() + " Designations"); return allDesignations; } catch
	 * (Exception e) { // TODO: handle exception
	 * logger.error("error while getting all Designation Record "); throw new
	 * DesignationRecordNotFoundException("Designations not found"); }
	 * 
	 * 
	 * return designationService.getAllDesignations(pageIndex, pageSize,
	 * "designation"); }
	 */

	/**
	 * Returns Designation and status code when designation data is available by id
	 * 
	 * @param id - designation Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<DesignationDTO> getById(@PathVariable("id") Long id) {
		try {
			DesignationDTO designationById = designationService.getById(id);
			logger.debug("Designation fond with ID = " + id + " " + designationById);
			return new ResponseEntity<DesignationDTO>(designationById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Designation by Id :: " + id);
			throw new DesignationRecordNotFoundException("Designation is not available for Id :" + id);
		}

	}

	/**
	 * Returns status code when new designation is created
	 * 
	 * @param model - new designation data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody DesignationDTO model) {

		try {
			designationService.save(model);
			logger.debug("Designation Added :: " + model);

			return new ResponseEntity<Response>(
					new Response(model.getDesignation() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Designation :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getDesignation() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns status code when existing designation data is updated
	 * 
	 * @param model - new designation data
	 * @param id    - designation Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody DesignationDTO model, @PathVariable long id) {

		try {
			 designationService.updateDesignation(model, id);
			logger.debug("Designation ID = " + id + " is updated :: " + model);
			
				return new ResponseEntity<Response>(
						new Response(model.getDesignation() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
						HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("Error while updating Designation :: " + id);
			return new ResponseEntity<Response>(
					new Response(model.getDesignation() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);

		}
	}

	/**
	 * Returns status code when designation data is deleted
	 * 
	 * @param id - designation id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteById(@PathVariable("id") Long id) {
		try {
			designationService.deleteDesignation(id);
			logger.debug("Designation record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response("Designation " + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Department not exist ");
			;
			return new ResponseEntity<Response>(
					new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/list/{id}")
	public ResponseEntity<List<DesignationDTO>> allDesigation(@PathVariable long id) {
		List<DesignationDTO> allDesignations = designationService.getDepartmentById(id);
		if (allDesignations != null) {
			logger.debug("Found " + allDesignations.size() + " Designation");
			return new ResponseEntity<List<DesignationDTO>>(allDesignations, HttpStatus.OK);
		}
		throw new DesignationRecordNotFoundException("Designation is not available for Id :");

	}

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return designationService.getAllDesignation(pagingDto.getPageIndex(), pagingDto.getPageSize(),
				pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy());
	}
	
	
}
