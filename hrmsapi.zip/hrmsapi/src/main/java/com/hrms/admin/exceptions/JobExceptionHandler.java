package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.hrms.admin.dto.JobErrorType;


@RestControllerAdvice
public class JobExceptionHandler {
	
	
	
	
	//@ResponseBody
		@ExceptionHandler(JobNotFoundException.class)
		public ResponseEntity<JobErrorType> handleNotFound(
				JobNotFoundException recordNotFoundException)
		{
			
			return new ResponseEntity<JobErrorType>(
					new JobErrorType(
							new Date(System.currentTimeMillis()).toString(), 
							"404- NOT FOUND", 
							recordNotFoundException.getMessage()), 
					HttpStatus.NOT_FOUND);
		}

}
