package com.hrms.admin.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class NotificationNotCreatedException extends RuntimeException{

	public NotificationNotCreatedException(String exception) {
		super(exception);
	}
}
