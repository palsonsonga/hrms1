package com.hrms.admin.exceptions;

public class HolidayNotFoundExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public HolidayNotFoundExceptions(String message) {
		super(message);
	}
}
