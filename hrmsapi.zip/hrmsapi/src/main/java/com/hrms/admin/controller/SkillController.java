package com.hrms.admin.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.dto.SkillDTO;
import com.hrms.admin.exceptions.DepartmentNotFoundExceptions;
import com.hrms.admin.service.impl.SkillServiceImpl;
import com.hrms.admin.util.Constants;



/**
 * Contains method to provide APIs for Skill Record
 * 
 * @author {Prabhat}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/skill")
public class SkillController {

	private static final Logger logger = LoggerFactory.getLogger(SkillController.class);

	@Autowired
	private SkillServiceImpl service;

	/**
	 * Returns status code when new skill is created
	 * 
	 * @param model - new skill data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody SkillDTO model) {
		try {
			 service.save(model);
			
				logger.debug("Skill Added :: " + model);
				return new ResponseEntity<Response>(new Response(model.getSkillSet()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);
			
		} catch (Exception e) {
			logger.error("Error while adding Skill :: ", e);
			return new ResponseEntity<Response>(new Response(model.getSkillSet()+" "+Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}




	/**
	 * Returns status code when existing skill data is updated
	 * 
	 * @param model - new skill data
	 * @param id    - skill Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody SkillDTO model, @PathVariable Long id) {

		try {
			service.updateSkill(model, id);
							logger.debug("Skill ID = " + id + " is updated :: " + model);
				return new ResponseEntity<Response>(new Response(model.getSkillSet()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("Error while updating record");
			return new ResponseEntity<Response>(new Response(model.getSkillSet()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns Skill and status code when skill data is available by id
	 * 
	 * @param id - skill Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<SkillDTO> getById(@PathVariable Long id) {

		try {
			SkillDTO skillById = service.getById(id);
			logger.debug("Skill fond with ID = " + id + " " + skillById);
			return new ResponseEntity<SkillDTO>(skillById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Skill by Id :: " + id);
			throw new DepartmentNotFoundExceptions("Skill");
		}
	}

	/**
	 * Returns Skill data and status code when skill data is available by
	 * name
	 * 
	 * @param name - skillset
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<SkillDTO> getByName(@PathVariable String name) {
		try {
			SkillDTO skillByName = service.getByName(name);
			logger.debug("Skill fond with Name = " + name + " " + skillByName);
			return new ResponseEntity<SkillDTO>(skillByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Skill by name :: " + name);
			throw new DepartmentNotFoundExceptions("Skill not found");
		}


	}
	/**
	 * Returns status code when skill data is deleted
	 * 
	 * @param id - skill id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
		ResponseEntity<SkillDTO> byId = getById(id);
		
			service.deleteSkill(id);
			logger.debug("Skill record is Deleted with id " + id);
			return new ResponseEntity<Response>(new Response(Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Skill not exist ");
			return new ResponseEntity<Response>(new Response("No value present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllSkill(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
}