package com.hrms.admin.dto;

public class FileDTO {

	private Long id;
	private String filename;
	private String filePath;
	private String folderName;
	
	
	
	public FileDTO() {
		super();
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getFilename() {
		return filename;
	}



	public void setFilename(String filename) {
		this.filename = filename;
	}



	public String getFilePath() {
		return filePath;
	}



	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}



	public String getFolderName() {
		return folderName;
	}



	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}



	public FileDTO(Long id, String filename, String filePath, String folderName) {
		super();
		this.id = id;
		this.filename = filename;
		this.filePath = filePath;
		this.folderName = folderName;
	}

	
}
