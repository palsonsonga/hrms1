package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.PolicyDTO;

public interface PolicyService {

	public boolean save(PolicyDTO model,MultipartFile file);

	public List<PolicyDTO> getAllPolicy();

	public PolicyDTO getPolicyById(Long id);

	public PolicyDTO getPolicyByName(String name);

	public boolean deletePolicy(Long id);

	public boolean update(Long id, PolicyDTO policydto, MultipartFile file);

//	public Map<String, Object> getAllPolicy(Integer pageIndex, Integer pageSize, String sortBy);
	
	public Map<String, Object> getAllPolicy(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

}
