package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.exceptions.ProjectNotFoundExceptions;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.ProjectService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Project Record
 * 
 * @author {MD Atif}
 *
 */

@RestController
@CrossOrigin
@RequestMapping("/admin/project")
public class ProjectController {

	private static final Logger logger = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	private ProjectService service;

	/**
	 * Returns status code when new project is created
	 * 
	 * @param model - new project data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody ProjectDTO model) {

		try {
			service.save(model);
			logger.debug("project Added :: " + model);

			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Project :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns All project data when project data is available
	 * 
	 * @return - List of project
	 */

	/*
	 * @GetMapping
	 * public Map<String, Object> getAll(@RequestParam(defaultValue = "0") Integer
	 * pageIndex,
	 * 
	 * @RequestParam(defaultValue = "5") Integer pageSize) {
	 * 
	 * // public List<ProjectDTO> getAllProjects() { // List<ProjectDTO> allProject
	 * = service.getAllProject(); // if (allProject != null) { //
	 * logger.debug("Found " + allProject.size() + " Project"); // return
	 * allProject; // } // logger.error("error while getting all Project Record");
	 * // throw new ProjectNotFoundExceptions("Project not found"); // } return
	 * service.getAllProject(pageIndex, pageSize, "name"); }
	 */

	/**
	 * Returns Project and status code when project data is available by id
	 * 
	 * @param id - project Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ProjectDTO> getById(@PathVariable Long id) {

		try {

			ProjectDTO projectById = service.getById(id);
			logger.debug("project find with ID = " + id + " " + projectById);
			return new ResponseEntity<ProjectDTO>(projectById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Project by Id :: " + id);
			throw new ProjectNotFoundExceptions("Project");
		}

	}
	/**
	 * Returns project data and status code when project data is available by
	 * name
	 * 
	 * @param name - Project name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<ProjectDTO> getByName(@PathVariable String name) {
		try {
			ProjectDTO projectByName = service.getByName(name);
			logger.debug("Project found with Name = " + name + " " + projectByName);
			return new ResponseEntity<ProjectDTO>(projectByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Project by name :: " + name);
			throw new ProjectNotFoundExceptions("Project not found");
		}



	}

	/**
	 * Returns status code when project data is deleted
	 * 
	 * @param id - project id
	 * @return - ResponseEntity
	 */

	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteProject(@PathVariable Long id) {
		try {
			ProjectDTO project = service.getById(id);

			service.deleteProject(id);
			logger.debug("Project record is Deleted with id " + id);
			return new ResponseEntity<Response>(new Response(project.getName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Project not exist ");
			return new ResponseEntity<Response>(new Response("No value present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns status code when existing project data is updated
	 * 
	 * @param model - new project data
	 * @param id    - project Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody ProjectDTO model, @PathVariable Long id) {
		try {
			service.updateProject(model, id);
			logger.debug("Project ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while updating Project :: ");
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}


	@GetMapping("/totalemp/{id}")
	public ResponseEntity<ProjectDTO> getEmployeesByProjId(@PathVariable Long id) {

		try {

			ProjectDTO findAllEmpByProjId = service.findAllEmployeeByProjId(id);
			logger.debug("Employees found with project  ID = " + id + " " + findAllEmpByProjId);
			return new ResponseEntity<ProjectDTO>(findAllEmpByProjId, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while Employees found with project  ID :: " + id);
			throw new ProjectNotFoundExceptions("Project");
		}
	}

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllProject(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}

	@GetMapping("/list")
	public ResponseEntity<List<ProjectDTO>> getAllProjects(){
		List<ProjectDTO> allProject = service.getAllProject();
		if (allProject != null) {
			logger.debug("Found " + allProject.size() + " Project");
			return new ResponseEntity<List<ProjectDTO>>(allProject,HttpStatus.OK);
		}
		logger.error("error while getting all Project Record");
		throw new ProjectNotFoundExceptions("Project");
	}

}
