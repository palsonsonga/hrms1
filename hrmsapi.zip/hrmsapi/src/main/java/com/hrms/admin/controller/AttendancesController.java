package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.AttendanceDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.AttendanceNotFoundExceptions;
import com.hrms.admin.service.AttendanceService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Attendance Record
 * 
 * @author {Chandu}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/attendance")
public class AttendancesController {
	private static final Logger logger = LoggerFactory.getLogger(AttendancesController.class);

	@Autowired
	private AttendanceService service;

	/**
	 * Returns status code when new attendance is created
	 * 
	 * @param model - new attendance data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody AttendanceDTO model) {
		try {
			service.save(model);
			logger.debug("Attendance Added :: " + model);
			return new ResponseEntity<Response>(
					new Response("Attendance " +" "+ Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);

		} catch (Exception e) {
			logger.error("Error while adding Attendance :: ", e);
			return new ResponseEntity<Response>(
					new Response( "Attendance " +" "+ Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Returns status code when existing attendance data is updated
	 * 
	 * @param model - new attendance data
	 * @param id    - attendance Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody AttendanceDTO model, @PathVariable Long id) {
		try {
			service.updateAttendnace(model, id);
			logger.debug("updated attendance :: ");
			return new ResponseEntity<Response>(
					new Response( "Attendance " +" "+Constants.UPDATE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating  Attendance :: ", e);
			return new ResponseEntity<Response>(
					new Response("Attendance " +" "+Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns attendance and status code when attendance data is available by id
	 * 
	 * @param id - attendance Id
	 * @return - ResponseEntity
	 */
	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllAttendnace(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}

	@GetMapping("/{id}")
	public ResponseEntity<AttendanceDTO> getById(@PathVariable Long id) {

		try {
			AttendanceDTO attendanceById = service.getById(id);
			logger.debug("Attendance fond with ID = " + id + " " + attendanceById);
			return new ResponseEntity<AttendanceDTO>(attendanceById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Attendance by Id :: " + id);
			throw new AttendanceNotFoundExceptions("Attendance");
		}
	}

	/**
	 * Returns All attendance data when attendance data is available
	 * 
	 * @return - List of attendanceModel
	 */
	/**
	 * Returns status code when attendance data is deleted
	 * 
	 * @param id - attendance id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			AttendanceDTO attendance = service.getById(id);

			service.deleteAttendnace(id);
			logger.debug("attendance record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(attendance.getCompanyName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("attendance not exist ");
			return new ResponseEntity<Response>(
					new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/list/{id}")
	public ResponseEntity<List<AttendanceDTO>> findByCompanyId(@PathVariable long id) {
		List<AttendanceDTO> allAttendance = service.getCompanyId(id);
		if (allAttendance != null) {
			logger.debug("Found " + allAttendance.size() + " Attendance");
			return new ResponseEntity<List<AttendanceDTO>>(allAttendance, HttpStatus.OK);
		}
		throw new AttendanceNotFoundExceptions("Attendance is not available for Id :");

	}
}
