package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.DesignationDTO;

public interface DesignationService {

//	public Map<String, Object> getAllDesignations(Integer pageIndex, Integer pageSize, String sortBy);

	public DesignationDTO getById(Long id);

	public boolean save(DesignationDTO model);

	public boolean updateDesignation(DesignationDTO model, Long id);

	public boolean deleteDesignation(Long  id);
	
	public List<DesignationDTO> getDepartmentById(Long id);
	
	public Map<String, Object> getAllDesignation(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
}
