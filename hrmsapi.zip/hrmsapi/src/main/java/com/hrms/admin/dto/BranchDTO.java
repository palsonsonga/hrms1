package com.hrms.admin.dto;

public class BranchDTO {

	

	private Long id;
	private String name;
	private String location;
	private String contactNo;
	private String email;
	private String fax;
	private Long companyId;
	private AddressDTO address;
	private String companyName;
	
	public BranchDTO() {
		super();
	}

	public BranchDTO(Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	public BranchDTO(Long id, String name, String location, String contactNo, String email, String fax, Long companyId,
			AddressDTO address, String companyName) {
		super();
		this.id = id;
		this.name = name;
		this.location = location;
		this.contactNo = contactNo;
		this.email = email;
		this.fax = fax;
		this.companyId = companyId;
		this.address = address;
		this.companyName = companyName;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public AddressDTO getAddress() {
		return address;
	}

	public void setAddress(AddressDTO address) {
		this.address = address;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
}
