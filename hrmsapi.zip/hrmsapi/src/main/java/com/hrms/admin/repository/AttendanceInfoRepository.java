package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.AttendanceInfo;

public interface AttendanceInfoRepository extends JpaRepository<AttendanceInfo,Long> {
	
	//insert into emp_time_track (empid,companyname,branch,intime,outtime) values (?, ?, ?, ?, ?, ?)
}
