package com.hrms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.hrms.admin.entity.BatchProcessEntity;
import com.hrms.admin.repository.BatchProcessRepository;
import com.hrms.admin.response.BatchResponse;
import com.hrms.admin.response.Data;
import com.hrms.admin.response.Response;
import com.hrms.admin.service.impl.FileStorageServiceImpl;


@RestController
@CrossOrigin
@RequestMapping("/admin/attendance")
public class FileUploadController {

    @Autowired
    private FileStorageServiceImpl fileStorageService;
    @Autowired	
	private BatchProcessRepository batchRepository;
    @Autowired
	private AttendanceInfoLoadController infoLoad;
	
	 @PostMapping("/uploadFile")
	    public BatchResponse uploadFile(@RequestParam("file") MultipartFile file) {
		 BatchResponse batchResponse = new BatchResponse();
			
			Data data = new Data();
			
			try {
				 
				String fileName = fileStorageService.storeFile(file);
				System.out.println("=============="+fileName);
				if(fileName.contains(fileName)) {
					infoLoad.load();
					List<BatchProcessEntity> findByJobExecutionId = batchRepository.findByStepName("ATTENDANCE-file-load");				
					for (BatchProcessEntity batchProcessEntity : findByJobExecutionId) {					
						data.setSuccessCount(batchProcessEntity.getReadCount());
						data.setFailureCount(batchProcessEntity.getReadSkipCount());
						batchResponse.setData(data);
						batchResponse.setMessage(" Upload File successfully...");
						batchResponse.setStatus(true);
					}
				}

			} catch (Exception e) {
				batchResponse.setMessage(" Upload File fail...");
				batchResponse.setData(data);
				batchResponse.setStatus(false);
				
				return batchResponse;
			}
			return batchResponse;
		}
}
