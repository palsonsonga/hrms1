package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author {Benarji}
 *
 */

@Entity
@Table(name = "EMP_TIME_TRACK")
public class AttendanceInfo extends AuditingEntity{

	@Id
	@Column(name = "ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column(name = "empid")
	private Long empId;

	@Column(name = "COMPANYNAME")
	private String companyName;

	@Column(name = "BRANCH")
	private String branch;

	@Column(name = "INTIME", columnDefinition = "TIMESTAMP")
	private String inTime;

	@Column(name = "OUTTIME", columnDefinition = "TIMESTAMP")
	private String outTime;

	@Column(name = "DATE", columnDefinition = "TIMESTAMP")
	private String date;

	@Column(name = "nohours")
	private Long noOfHrs;

	@Column(name = "REASON")
	private String reason;

	@Column(name = "AttendsPercentage")
	private Long attndsPercentage;
	
	@Column(name = "EMPNAME")
	private String empName;

	public AttendanceInfo() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public Long getNoOfHrs() {
		return noOfHrs;
	}

	public Long setNoOfHrs(Long noOfHrs) {
		return this.noOfHrs = noOfHrs;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	
	public Long getAttndsPercentage() {
		return attndsPercentage;
	}

	public Long setAttndsPercentage(Long attndsPercentage) {
		return this.attndsPercentage = attndsPercentage;
	}
	

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public AttendanceInfo(Long id, Long empId, String companyName, String branch, String inTime, String outTime,
			String date, Long noOfHrs, String reason, Long attndsPercentage) {
		super();
		this.id = id;
		this.empId = empId;
		this.companyName = companyName;
		this.branch = branch;
		this.inTime = inTime;
		this.outTime = outTime;
		this.date = date;
		this.noOfHrs = noOfHrs;
		this.reason = reason;
		this.attndsPercentage = attndsPercentage;
	}
}
