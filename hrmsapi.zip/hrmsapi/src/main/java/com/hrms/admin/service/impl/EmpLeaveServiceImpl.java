package com.hrms.admin.service.impl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.joda.time.DateTimeComparator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EmpLeaveDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.entity.EmpLeave;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.LeaveType;
import com.hrms.admin.exceptions.EmpLeaveIdNotFoundException;
import com.hrms.admin.repository.EmpLeaveRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.LeaveTypeRepository;
import com.hrms.admin.service.EmpLeaveService;
import com.hrms.admin.util.DateCount;
import com.hrms.admin.util.EmailServiceUtil;

@Service
public class EmpLeaveServiceImpl implements EmpLeaveService {

	private static final Logger logger = LoggerFactory.getLogger(EmpLeaveServiceImpl.class);

	@Autowired
	private EmpLeaveRepository repo;

	@Autowired
	private DateCount dateCount;

	@Autowired
	private EmailServiceUtil email;
	
	@Autowired
	private LeaveTypeRepository leaveTypeRepository;
    @Autowired
	private EmployeeRepository employeeRepository;
	/*
	 * @Autowired private Leave l;
	 */

	/**
	 * Returns All EmpLeave data when empLeave data is available in database
	 * 
	 * @return - List of EmpLeavemodel
	 */
	@Override
	public List<EmpLeaveDTO> getAllEmpLeave() {
		List<EmpLeave> empLeave = repo.findAll();
		List<EmpLeaveDTO> models = empLeave.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setEmailId(entity.getEmailId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;
	}

	/**
	 * Returns EmpLeave data when empLeave data is available in database by id
	 * 
	 * @param id - Id
	 * @return - EmpLeaveModel
	 */
	@Override
	public EmpLeaveDTO getEmpLeaveByid(Long id) {

		Optional<EmpLeave> optional = repo.findById(id);
		if (optional.isPresent()) {
			EmpLeave entity = optional.get();
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setEmailId(entity.getEmailId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getStartDate());
			model.setId(entity.getId());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			logger.debug("EmpLeave found with ID = " + id + " " + entity);
			return model;
		} else {
			throw new EmpLeaveIdNotFoundException(" emp leave id not available::" + id);
		}
	}

	/**
	 * Returns true when new EmpLeave is store in database
	 * 
	 * @param model - new EmpLeaveRequest data
	 * @return - boolean
	 */
	@Override
	public boolean addEmpLeave(EmpLeaveDTO model1) {

		boolean flag = Boolean.FALSE;
		EmpLeave entity = new EmpLeave();
		LeaveType optional1 =leaveTypeRepository.findById(model1.getLeaveTypeId()).get();
		String lt = optional1.getLeaveType();
		entity.setEmployeeId(model1.getEmployeeId());
		entity.setStartDate(model1.getStartDate());
		entity.setEndDate(model1.getEndDate());
		entity.setReason(model1.getReason());
		entity.setManagerMailId(model1.getManagerMail());
		entity.setEmailId(model1.getEmailId());
		entity.setLeaveType(lt);
		entity.setStatus("Applied");
		entity.setLeaveTypeId(model1.getLeaveTypeId());
		entity.setTotalDays(dateCount.daysCount(model1.getStartDate(), model1.getEndDate()));
		entity.setLeaveApplyDate(new Timestamp(new Date().getTime()));
		EmpLeave l = repo.save(entity);
		if (!Objects.isNull(l))
			flag = Boolean.TRUE;
		logger.debug("EmpLeave Added into database :: " + entity);
		String to = model1.getManagerMail();
		MailDTO request = new MailDTO();
		request.setTo(to);
		request.setSubject("LeaveApproval");
		request.setTemplate("LeaveApply.ftl");
		request.setFrom(model1.getEmailId());
		Map<String, Object> model = new HashMap<>();
		model.put("leavetype", lt);
		model.put("emp", entity.getEmployeeId());
		email.sendEmail(request, model);
        return flag;

	}

	/**
	 * Returns true when empLeave data is deleted from database by id
	 * 
	 * @param id - id
	 * @return - boolean
	 */
	@Override
	public boolean deleteEmpLeave(Long id) {
		Optional<EmpLeave> empLeave = repo.findById(id);
		if (empLeave.isPresent()) {
			repo.deleteById(id);
			logger.debug("empLeave deleted from Database");
			return true;
		} else {
			throw new EmpLeaveIdNotFoundException(" emp leave id not available::" + id);
		}
	}

	/**
	 * Returns true when new EmpLeave is store in database
	 * 
	 * @param model - new EmpLeave data
	 * @return - boolean
	 */
	@Override
	public boolean updateEmpLeave(EmpLeaveDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<EmpLeave> findById = repo.findById(id);
		
		if (findById.isPresent()) {
			EmpLeave existingEmpLeave = findById.get();
			existingEmpLeave.setStatus("Applied");
			existingEmpLeave.setTotalDays(dateCount.daysCount(model.getStartDate(), model.getEndDate()));
			existingEmpLeave.setStartDate(model.getStartDate());
			existingEmpLeave.setEndDate(model.getEndDate());
			existingEmpLeave.setReason(model.getReason());
			existingEmpLeave.setLeaveApplyDate(new Timestamp(new Date().getTime()));
			existingEmpLeave.setLeaveTypeId(model.getLeaveTypeId());
			EmpLeave n = repo.save(existingEmpLeave);
			if (!Objects.isNull(n))
				flag = Boolean.TRUE;
			logger.debug("EmpLeave ID = " + id + " is updated in to database :: " + existingEmpLeave);
			return flag;
		} else {
			logger.error("empLeave is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns true when leave approved/rejected
	 * 
	 * @param approval - Approved/Rejected
	 * @param Long     - EmpLeaveId
	 * @return - boolean
	 */
	@Override
	public boolean approveOrReject(String approval, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<EmpLeave> optional = repo.findById(id);
		if (optional.isPresent()) {
			EmpLeave entity = optional.get();
			System.out.println(approval.toString());
			System.out.println(approval);
			if (approval.equalsIgnoreCase("APPROVED")) {
				entity.setStatus(approval);
				EmpLeave n = repo.save(entity);
				if (!Objects.isNull(n))
					flag = Boolean.TRUE;
				MailDTO request = new MailDTO();
				request.setTo(entity.getEmailId());
				request.setSubject("Approval");
				request.setName("employee");
				request.setTemplate("LeaveApproval.ftl");
				request.setFrom(entity.getEmailId());
				Map<String, Object> model = new HashMap<>();
				String leavetype = entity.getLeaveType1().getLeaveType();
				//String status = approval;
				model.put("leavetype", leavetype);
				model.put("status", approval);
				model.put("LeaveId", entity.getId());
				email.sendEmail(request, model);
				logger.debug("EmpLeave ID = " + id + " is approved in to database :: " + entity);
				return flag;
			} else if (approval.equalsIgnoreCase("REJECTED")) {
				entity.setStatus(approval);
				EmpLeave n = repo.save(entity);
				if (!Objects.isNull(n))
					flag = Boolean.TRUE;
				MailDTO request = new MailDTO();
				request.setTo(entity.getEmailId());
				request.setSubject("Approval");
				request.setName("employee");
				request.setTemplate("LeaveApproval.ftl");
				Map<String, Object> model = new HashMap<>();
				String leavetype = entity.getLeaveType1().getLeaveType();
				//String status = "rejected";
				model.put("leavetype", leavetype);
				model.put("status", approval);
				model.put("LeaveId", entity.getId());
				email.sendEmail(request, model);
				System.out.println("dddddddddddddd");
				logger.debug("EmpLeave ID = " + id + " is rejected in to database :: " + entity);
				return flag;

			} else
				logger.debug("EmpLeave ID = " + id + " is approval is invalid " + approval);

		}
		return flag;
	}

	/**
	 * Returns EmpLeave for given Date
	 * 
	 * @param date1 - Date
	 * @return - list of employee leaves
	 */
	@Override
	public List<EmpLeaveDTO> findLeavesbyDate(Date date) {

		List<EmpLeave> empLeave = repo.findByStartDate(date);
		List<EmpLeaveDTO> models = empLeave.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setEmailId(entity.getEmailId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;

	}

	/**
	 * Returns EmpLeave for given time period
	 * 
	 * @param date1 - startDate
	 * @param date2 - endDate
	 * @return - list of employee leaves
	 */
	@Override
	public List<EmpLeaveDTO> getEmpLeavesByDate(Long id, Date date1, Date date2) {
		List<EmpLeave> list2 = new ArrayList<>();
		List<EmpLeave> list = repo.findByEmployeeId(id);
		for (EmpLeave e : list) {
			Date mydate = e.getStartDate();
			DateTimeComparator dateTimeComparator = DateTimeComparator.getDateOnlyInstance();
			int retVal = dateTimeComparator.compare(mydate, date1);
			int retVal1 = dateTimeComparator.compare(mydate, date1);
			if (retVal == 0) {
				list2.add(e);
			} else if (retVal > 0) {
				list2.add(e);
			}
			if (retVal1 == 0) {
				list2.add(e);
			}

			else if (retVal1 < 0) {
				list2.add(e);
			}

		}
		List<EmpLeaveDTO> models = list2.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setEmailId(entity.getEmailId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;
	}

	/**
	 * Returns EmpLeave for given employee
	 * 
	 * @param id - empId
	 * @return - list of employee leaves
	 */
	@Override
	public List<EmpLeaveDTO> findLeavesbyEmpId(Long id) {
		List<EmpLeave> empLeave = repo.findByEmployeeId(id);
		List<EmpLeaveDTO> models = empLeave.stream().map(entity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setEmployeeId(entity.getEmployeeId());
			model.setId(entity.getId());
			model.setStartDate(entity.getStartDate());
			model.setEndDate(entity.getEndDate());
			model.setLeaveApplyDate(entity.getLeaveApplyDate());
			model.setLeaveType(entity.getLeaveType1().getLeaveType());
			model.setReason(entity.getReason());
			model.setTotalDays(entity.getTotalDays());
			model.setEmailId(entity.getEmailId());
			return model;
		}).collect(Collectors.toList());
		// @formatter:on

		return models;
	}

	@Override																			   
	public Map<String, Object> getAllEmpLeaves(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<EmpLeave> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}


	public static Map<String, Object> mapData(Page<EmpLeave> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmpLeaveDTO> jobModels = pagedResult.stream().map(jobEntity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			BeanUtils.copyProperties(jobEntity, model);
			return model;
		}).collect(Collectors.toList());

		response.put("data", jobModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
	
	@Override
	public Map<String, Object> getAllTeamLeaves(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {

		Pageable paging = null;

		Page<EmpLeave> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			// Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		} else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData1(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	public static Map<String, Object> mapData1(Page<EmpLeave> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmpLeaveDTO> leaveModels = pagedResult.stream().map(leaveEntity -> {
			EmpLeaveDTO model = new EmpLeaveDTO();
			model.setId(leaveEntity.getId());
			model.setEmailId(leaveEntity.getEmailId());
			model.setStartDate(leaveEntity.getStartDate());
			model.setEndDate(leaveEntity.getEndDate());
			model.setLeaveTypeId(leaveEntity.getLeaveTypeId());
			model.setReason(leaveEntity.getReason());
			model.setTotalDays(leaveEntity.getTotalDays());
			model.setLeaveApplyDate(leaveEntity.getLeaveApplyDate());
			model.setStatus(leaveEntity.getStatus());
			model.setLeaveType(leaveEntity.getLeaveType1().getLeaveType());
			model.setEmployeeId(leaveEntity.getEmployeeId());
			return model;
		}).collect(Collectors.toList());

		response.put("data", leaveModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
	
	public List<String> findManagerList(Long id) {
		Optional<Employee> optional = employeeRepository.findById(id);
		Employee e = optional.get();
		Long dId = e.getDepartmentId();
		List<String> mngr = new ArrayList<>();
		List<Employee> l = employeeRepository.findByDepartmentId(dId);
		for (Employee e1 : l) {
		String des = e1.getDesignation().getDesignation();
		if (des.equalsIgnoreCase("Manager")) {
		mngr.add(e1.getEmail());
		}
		}

		return mngr;

		}
}
