package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.LeaveTypeDTO;
import com.hrms.admin.entity.LeaveType;
import com.hrms.admin.repository.LeaveTypeRepository;
import com.hrms.admin.service.LeaveTypeService;

@Service
public class LeaveTypeServiceImpl implements LeaveTypeService{

	private static final Logger logger = LoggerFactory.getLogger(LeaveTypeServiceImpl.class);


	@Autowired
	private LeaveTypeRepository repo; 

	@Override
	public boolean save(LeaveTypeDTO model) {
		boolean flag = Boolean.FALSE;
		//for null check
				if(model.getLeaveType().equals(null)|| model.equals(null)) {
					flag = Boolean.FALSE;
					return flag;
				}
				/*
				 * //duplicate validation Optional<LeaveType> findByLeaveType =
				 * repo.findByLeaveType(model.getLeaveType()); if(findByLeaveType.isPresent()) {
				 * LeaveType leaveType = findByLeaveType.get();
				 * if(leaveType.getLeaveType()==model.getLeaveType()); flag = Boolean.FALSE;
				 * return flag; }
				 */
		LeaveType entity = new LeaveType();
		//setting values
		entity.setLeaveType((model.getLeaveType()));
		entity.setDescription((model.getDescription()));
		entity.setCompanyId(model.getCompanyId());
		entity.setBranchId(model.getBranchId());
		LeaveType d=repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Leave Added into database :: " + entity);
		return flag;
	}


	/**
	 * Returns true when existing leave data is store in database
	 * 
	 * @param model - new leave data
	 * @param id - leave Id
	 * @return - boolean
	 */

	/**
	 * Returns All Leave data when Leave data is available in database
	 * @return - List of LeaveresponseModel
	 */
	@Override																			   
	public Map<String, Object> getAllLeaves(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<LeaveType> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	/**
	 * Returns Leave data when branch data is available in database by id
	 * @param id - Leave Id
	 * @return - LeaveResponseModel
	 */
	@Override
	public LeaveTypeDTO getById(Long id) {
		Optional<LeaveType> optionalEntity = repo.findById(id);
		LeaveType entity = optionalEntity.get();
		LeaveTypeDTO model = new LeaveTypeDTO();
		model.setId(entity.getId());
		model.setLeaveType(entity.getLeaveType());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompanyId());
		model.setBranchId(entity.getBranchId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		logger.debug("Skill found with ID = " + id + " " + entity);
		return model;
	}

	/**
	 * Returns true when leave data is deleted from database by id
	 * @param id - leave id
	 * @return - boolean
	 */
	@Override
	public boolean deleteLeave(Long id) {
		repo.deleteById(id);
		logger.debug(" Leave record is deleted from database ");
		return true;

	}

	/**
	 * Returns true when existing Leave data is store in database
	 * 
	 * @param model - new Leave data
	 * @param id - Leave Id
	 * @return - boolean
	 */
	@Override
	public boolean updateLeave(LeaveTypeDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		//for null check
		if(model.getLeaveType().equals(null)|| model.equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * //duplicate validation Optional<LeaveType> findByLeaveType =
		 * repo.findByLeaveType(model.getLeaveType()); if(findByLeaveType.isPresent()) {
		 * LeaveType leaveType = findByLeaveType.get();
		 * if(leaveType.getLeaveType()==model.getLeaveType()); flag = Boolean.FALSE;
		 * return flag; }
		 */
		Optional<LeaveType> findById = repo.findById(id);
		if (findById.isPresent()) {
			LeaveType oldLeave = findById.get();
			oldLeave.setLeaveType((model.getLeaveType()));
			oldLeave.setDescription(model.getDescription());
			oldLeave.setCompanyId(model.getCompanyId());
			oldLeave.setBranchId(model.getBranchId());
			LeaveType d =repo.save(oldLeave);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Leave ID = " + id + " is updated in to database :: " + oldLeave);
			return flag;
		} else {
			logger.error("Leave is not available in to database with ID= " + id);
			return flag;
		}

	}

	public static Map<String, Object> mapData(Page<LeaveType> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<LeaveTypeDTO> leaveModels = pagedResult.stream().map(entity -> { 
			LeaveTypeDTO model =	new LeaveTypeDTO(); 
			model.setId(entity.getId());
			model.setLeaveType(entity.getLeaveType());
			return	model;}).collect(Collectors.toList());

		response.put("data", leaveModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
	@Override
	public List<LeaveTypeDTO> AllLeavesTypes() {
		List<LeaveType> allDepartment = repo.findAll();
		List<LeaveTypeDTO> models = allDepartment.stream().map(entity -> {
			LeaveTypeDTO model = new LeaveTypeDTO();
			model.setId(entity.getId());
			model.setLeaveType(entity.getLeaveType());
			return model;
		}).collect(Collectors.toList());
		return models;
	}
}