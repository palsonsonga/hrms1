package com.hrms.admin.dto;


public class BankDTO {

	private Long id;
	private String	bankName;
	private String  accountNo;
	private String	accountHolderName;
	private String	ifscCode;
	private String	branchName;
	

	public BankDTO() {
		super();
	}

	
	public BankDTO(long id, String bankName, String ifscCode, String accountHolderName, String accountNo,
			String branchName) {
		super();
		this.id = id;
		this.bankName = bankName;
		this.ifscCode = ifscCode;
		this.accountHolderName = accountHolderName;
		this.accountNo = accountNo;
		this.branchName = branchName;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	
	
}
