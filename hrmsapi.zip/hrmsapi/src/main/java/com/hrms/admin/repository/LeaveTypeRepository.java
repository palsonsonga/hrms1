package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.LeaveType;

@Repository
public interface LeaveTypeRepository  extends JpaRepository<LeaveType, Long>{

	Page<LeaveType> findAll(Pageable paging);

	@Query(value = "SELECT l FROM LeaveType l WHERE l.leaveType LIKE %?1%")
	Page<LeaveType> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<LeaveType> findByLeaveType(String leaveType);
}
