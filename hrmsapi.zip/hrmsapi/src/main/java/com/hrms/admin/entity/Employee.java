package com.hrms.admin.entity;



/**
 * This is the entity class for storing employee information
 * 
 * @author Mani
 *
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "EMPLOYEE")
//@Data
@ApiModel(description = "Details of Employee entity")
@JsonIdentityInfo(generator = ObjectIdGenerators.PropertyGenerator.class, property = "id")
public class Employee extends AuditingEntity{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "employee_id")
	private Long id;

	@ApiModelProperty(notes = "Should not null")
	private String firstName;

	@ApiModelProperty(notes = "Should not null")
	private String lastName;
	@ApiModelProperty(notes = "Should not null")
	private String email;

	@ApiModelProperty(notes = "Should not null")
	private String userName;

	@Temporal(TemporalType.TIMESTAMP)
	private Date dateOfBirth;

	@ApiModelProperty(notes = "Enter gender")
	private String gender;

	@ApiModelProperty(notes = "Should not null")
	private String maritalStatus;

	@ApiModelProperty(notes = "Should not null")
	private String contactNo;

	@ApiModelProperty(notes = "Proovide if have")
	private String alternateContactNo;


	@ApiModelProperty(notes = "Should not null")
	private String aadharCard;

	@ApiModelProperty(notes = "Should not null")
	private String panCard;

	@ApiModelProperty(notes = "Should not null")
	private String voterID;

	@Temporal(TemporalType.TIMESTAMP)
	private Date joiningDate;


	@ApiModelProperty(notes = "Should not null")
	private String bloodGroup;

	@Column(name = "FILES_FOLDER_NAME")
	private String folderName;

	@Column(name = "IS_ACTIVE")
	private Boolean isActive;


	@Column(name = "IS_APPROVE")
	private Boolean isApprove;

	@OneToMany(cascade = CascadeType.ALL) //one to many with Employee
	@JoinColumn(name = "employeeId")
	private List<Address> address = new ArrayList<>();

	@Column(name = "BANK_ACCOUNT_ID")
	private Long bankAccontId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST) //one to one with bankDetails
	@JoinColumn(name = "BANK_ACCOUNT_ID", insertable = false, updatable = false)
	private BankDetails bankDetails;

	@Column(name = "DEPARTMENT_ID")
	private Long departmentId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name ="DEPARTMENT_ID",insertable = false, updatable = false)
	private Department department;

	@Column(name = "DESIGINATION_ID")
	private Long desiginationId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name ="DESIGINATION_ID",insertable = false, updatable = false)
	private Designation designation ;

	@Column(name = "COMPANY_ID")
	private Long companyId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "COMPANY_ID",insertable = false, updatable = false)
	private Company company;


	@Column(name = "BRANCH_ID")
	private Long branchId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name ="BRANCH_ID",insertable = false, updatable = false)
	private Branch branch;



	//many to many with project
	@ManyToMany(targetEntity = Project.class, 
			cascade = {CascadeType.PERSIST} )
	private List<Project> projects;

	//many to many with policies
	@ManyToMany(targetEntity = Policy.class,cascade = {CascadeType.PERSIST} )
	private List<Policy> policies;

	@Column(name = "PROFILE_IMAGE_ID")
	private Long profileImageId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST) //one to one with profileimage
	@JoinColumn(name = "PROFILE_IMAGE_ID", insertable = false, updatable = false)
	private ProfileImage ProfileImage;

	@Column(name = "IP_ADDRESS")
	private String ipAddress;

	@Column(name = "PORT")
	private String port;
	
	
	  @OneToMany(cascade = CascadeType.ALL) //one to many with Employee
	  
	  @JoinColumn(name = "employeeId")
private List<AcademicDetails> academicDetails = new ArrayList<>();
	  
	  @OneToMany(cascade = CascadeType.ALL)
	  
	  @JoinColumn(name = "employeeId") 
	  private List<ProfessionalDetails> professionalDetails;
	
	public List<AcademicDetails> getAcademicDetails() {
		return academicDetails;
	}

	public void setAcademicDetails(List<AcademicDetails> academicDetails) {
		this.academicDetails = academicDetails;
	}

	public List<ProfessionalDetails> getProfessionalDetails() {
		return professionalDetails;
	}

	public void setProfessionalDetails(List<ProfessionalDetails> professionalDetails) {
		this.professionalDetails = professionalDetails;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMaritalStatus() {
		return maritalStatus;
	}

	public void setMaritalStatus(String maritalStatus) {
		this.maritalStatus = maritalStatus;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getAlternateContactNo() {
		return alternateContactNo;
	}

	public void setAlternateContactNo(String alternateContactNo) {
		this.alternateContactNo = alternateContactNo;
	}

	public String getAadharCard() {
		return aadharCard;
	}

	public void setAadharCard(String aadharCard) {
		this.aadharCard = aadharCard;
	}

	public String getPanCard() {
		return panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}

	public String getVoterID() {
		return voterID;
	}

	public void setVoterID(String voterID) {
		this.voterID = voterID;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public String getBloodGroup() {
		return bloodGroup;
	}

	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}

	public String getFolderName() {
		return folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public Boolean getIsActive() {
		return isActive;
	}

	public void setIsActive(Boolean isActive) {
		this.isActive = isActive;
	}

	public Boolean getIsApprove() {
		return isApprove;
	}

	public void setIsApprove(Boolean isApprove) {
		this.isApprove = isApprove;
	}

	public List<Address> getAddress() {
		return address;
	}

	public void setAddress(List<Address> address) {
		this.address = address;
	}

	public Long getBankAccontId() {
		return bankAccontId;
	}

	public void setBankAccontId(Long bankAccontId) {
		this.bankAccontId = bankAccontId;
	}

	public BankDetails getBankDetails() {
		return bankDetails;
	}

	public void setBankDetails(BankDetails bankDetails) {
		this.bankDetails = bankDetails;
	}

	public Long getDepartmentId() {
		return departmentId;
	}

	public void setDepartmentId(Long departmentId) {
		this.departmentId = departmentId;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Long getDesiginationId() {
		return desiginationId;
	}

	public void setDesiginationId(Long desiginationId) {
		this.desiginationId = desiginationId;
	}

	public Designation getDesignation() {
		return designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public Branch getBranch() {
		return branch;
	}

	public void setBranch(Branch branch) {
		this.branch = branch;
	}

	public List<Project> getProjects() {
		return projects;
	}

	public void setProjects(List<Project> projects) {
		this.projects = projects;
	}

	public List<Policy> getPolicies() {
		return policies;
	}

	public void setPolicies(List<Policy> policies) {
		this.policies = policies;
	}

	public Long getProfileImageId() {
		return profileImageId;
	}

	public void setProfileImageId(Long profileImageId) {
		this.profileImageId = profileImageId;
	}

	public ProfileImage getProfileImage() {
		return ProfileImage;
	}

	public void setProfileImage(ProfileImage profileImage) {
		ProfileImage = profileImage;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	
	
}
