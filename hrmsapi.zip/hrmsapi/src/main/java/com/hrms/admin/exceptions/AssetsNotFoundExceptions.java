package com.hrms.admin.exceptions;

public class AssetsNotFoundExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public AssetsNotFoundExceptions(String msg) {
		super(msg);
	}
}
