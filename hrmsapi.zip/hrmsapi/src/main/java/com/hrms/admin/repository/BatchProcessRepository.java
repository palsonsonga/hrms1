package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.BatchProcessEntity;

public interface BatchProcessRepository extends JpaRepository<BatchProcessEntity, Long>{
	
//	public List<BatchProcessEntity> findByJobExecutionId(Long jobExecutionId);
	
	public List<BatchProcessEntity> findByStepName(String stepName);
}
