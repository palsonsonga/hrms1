package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Skill;

public interface SkillRepository extends JpaRepository<Skill, Long> {
	
	public Skill findByskillSet(String skilset);
	
	public Page<Skill> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Skill a WHERE  a.skillSet LIKE %?1%")
	Page<Skill> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	
	public Optional<Skill> findBySkillSet(String skillSet);
}
