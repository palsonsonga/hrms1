package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Project;


public interface ProjectRepository extends JpaRepository<Project, Long> {

	public Project findByname(String name);
	
	Page<Project> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Project a WHERE  a.name LIKE %?1%")
	Page<Project> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Project> findByName(String name);
	
	

}
