package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Designation;

@Repository
public interface Designationrepository extends JpaRepository<Designation, Long> {

	
	@Query(value = "SELECT a FROM Designation a WHERE  a.designation LIKE %?1%     OR a.skills LIKE %?1%")
	Page<Designation> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Designation> findBydesignation(String designation);
	
		@Query(value = "FROM Designation d WHERE d.departmentid=:departmentid")
	public List<Designation>  findByDepartmentId(Long departmentid);
}
