package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.util.concurrent.Service;
import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.EmployeeComIDBranchID;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.exceptions.BranchNotFoundException;
import com.hrms.admin.exceptions.EmployeesNotFoundException;
import com.hrms.admin.exceptions.EmpolyeeExceptions;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.util.Constants;

@RestController
@RequestMapping("/onboard/employee")
@CrossOrigin
public class EmployeeController {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);

	@Autowired
	private EmployeeService employeeService;

	// employee on boarding with files upload to s3 bucket
	@PostMapping(consumes = { "multipart/form-data" })
	public ResponseEntity<Response> saveemp(
			@RequestPart String employee,
			@RequestPart MultipartFile[] files,
			@RequestPart MultipartFile image) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			EmployeeDTO employeedto = mapper.readValue(employee, EmployeeDTO.class);
			Integer saveEmployee=employeeService.saveEmployee(employeedto, files,image);
			logger.debug("Employee Added :: " + employee);
			if (saveEmployee == 1) {
				logger.error("Email is duplicate");
				return new ResponseEntity<Response>(
						new Response(employeedto.getEmail() + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			} else if (saveEmployee == 2) {
				logger.error("User Name is duplicate");
				return new ResponseEntity<Response>(
						new Response(employeedto.getUserName() + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			} else if (saveEmployee == 3) {
					logger.error("contactNo Name is duplicate");
				return new ResponseEntity<Response>(
						new Response(employeedto.getContactNo() + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.CREATED);
			}else {
				logger.debug("Employee added");
				return new ResponseEntity<Response>(
						new Response(employeedto.getFirstName() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
						HttpStatus.CREATED);
			}
			
		} catch (Exception e) {
			logger.error("Error while adding Employee :: ", e);
			return new ResponseEntity<Response>(new Response("Employee" + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	// get employee
	@GetMapping("/{id}")
	public ResponseEntity<EmployeeDTO> getEmployee(@PathVariable Long id) throws EmpolyeeExceptions {
		try {
			EmployeeDTO Employee = employeeService.getEmployeeById(id);
			logger.debug("Employee found with ID = " + id + " " + Employee);
			return new ResponseEntity<EmployeeDTO>(Employee, HttpStatus.OK);
		} catch (Exception e) {
			System.out.println(e);
			logger.error("Error while getting Employee by Id :: " + id);
			throw new EmpolyeeExceptions("Employee");
		}
	}

	@PutMapping("/empStatus/{id}")
	public ResponseEntity<Response> updateEmployeeByStatus(@PathVariable Long id, @RequestBody Map<String,Object> status)
			throws EmpolyeeExceptions {
		try {
			boolean status1 = employeeService.updateEmployeeByStatus(id, status.get("status").toString());
			if (status1 == Boolean.TRUE) {
				logger.debug("Employee Deaactived With id::" + id);
				return new ResponseEntity<Response>(
						new Response("Employee " + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.error("Error while deactiving Employee by Id :: " + id);
				return new ResponseEntity<Response>(
						new Response("Employee " + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
			}
		} catch (Exception e) {
			logger.error("Error while updating Employee Status by Id :: " + id);
			throw new EmpolyeeExceptions("Employee");
		}
	}


	@GetMapping("/allAppliedList")
	public ResponseEntity<List<Employee>> getAllAppliedEmployees() {
		List<Employee> empList = employeeService.appliedList();
		if (empList != null) {
			logger.debug("list of applied employees");
			return new ResponseEntity<List<Employee>>(empList, HttpStatus.OK);
		} else {
			logger.error("Error while getting list of Employee");
			return null;
		}
	}

	@PutMapping("/approve/{id}") 
	public ResponseEntity<Response> approveById(@PathVariable Long id) {
		Employee approveEmp = employeeService.approveById(id);
		if (approveEmp != null) {
			logger.debug("Employee Aactived With id::" + id);
			return new ResponseEntity<Response>(
					new Response("Employee " + " " + Constants.APPROVE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while Activing Employee by Id :: " + id);
			return new ResponseEntity<Response>(
					new Response("Employee " + " " + Constants.APPROVE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	@PutMapping("/{id}") // update employee on onboarding with files
	public ResponseEntity<Response> updateEmployee(@PathVariable Long id,@RequestPart String employee,
			@RequestPart(required = false) MultipartFile[] files,
			@RequestPart(required = false) MultipartFile image) throws JsonMappingException, JsonProcessingException {
		ObjectMapper mapper = new ObjectMapper();
		EmployeeDTO employeedto = mapper.readValue(employee, EmployeeDTO.class);
		boolean updateEmployee = employeeService.updateEmplyee(id, employeedto, files,image);
		if (updateEmployee) {
			logger.debug("Employee ID = " + id + " is updated :: " + employeedto);
			return new ResponseEntity<Response>(
					new Response(employeedto.getFirstName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while updating Employee :: ");
			return new ResponseEntity<Response>(
					new Response(employeedto.getFirstName() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}
	//Assigning Project to Employee by EmployeeId(Many to Many with project)
	@PutMapping("/empproject/{id}")
	public ResponseEntity<Response> updateEmployeeProject(@PathVariable Long id, @RequestBody EmployeeDTO model) {
		boolean updateEmployee = employeeService.updateEmployeeProject(model, id);
		if (updateEmployee) {
			logger.debug("Employee ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(new Response(Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while updating Employee :: ");
			return new ResponseEntity<Response>(new Response(Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/page")
	public Map<String, Object> getAllPagination(@RequestBody PaginationDTO pagingDto) {
		return employeeService.getAllEmployeePage(pagingDto.getPageIndex(), 
				pagingDto.getPageSize(), 
				pagingDto.getSortBy(),
				pagingDto.getSearchKey(),
				pagingDto.getOrderBy());
	}


	@DeleteMapping("/{id}/{fileId}")
	public ResponseEntity<Response> deleteEmployeeFile(@PathVariable Long id,@PathVariable Long fileId) {
		EmployeeDTO employeeDTO = employeeService.getEmployeeById(id);
		if(!Objects.isNull(employeeDTO)) {
			employeeService.deleteEmployeeFile(id, fileId);
			logger.debug("File Deleted with ID::" + fileId+", With Employee ID ::"+id);
			return new ResponseEntity<Response>(new Response(fileId+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}else {
			logger.debug("Employe ID::"+id+","+"File ID::"+fileId+"file not exist");
			return new ResponseEntity<Response>(new Response("No file present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
		}
	}
	
	@DeleteMapping("{imageid}")
	public ResponseEntity<Response> deleteEmployeeProfileImage(@PathVariable Long imageid) {
		boolean flag = employeeService.deleteEmployeeProfileImage(imageid);
		if(flag==true) {
			employeeService.deleteEmployeeProfileImage(imageid);
			logger.debug("Image Deleted with ID::" + imageid);
			return new ResponseEntity<Response>(new Response("image"+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}else {
			logger.debug("Image ID::"+imageid+"image  not exist");
			return new ResponseEntity<Response>(new Response("No file present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
		}
	}
	
	//adding or updating resource to employee
		@PutMapping(value = "/resources/{id}")
		public ResponseEntity<Response> add(@RequestBody EmployeeDTO model,@PathVariable Long id) {
			try {
				employeeService.AddResourcetoEmployee(model,id);
					return new ResponseEntity<Response>(
							new Response("ITResources " + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
			} catch (Exception e) {
				return new ResponseEntity<Response>(
						new Response("ITResources " + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.BAD_REQUEST);
			}
		}

	// Employee updated with Policies
	@PutMapping(value = "/image/{id}",consumes = { "multipart/form-data" })
	public ResponseEntity<Response> updateEmployeeProfileImage(@PathVariable Long id,@RequestPart MultipartFile image) {
		boolean updateEmployeeimage = employeeService.updateEmployeeProfileImage(id,image);
		if (updateEmployeeimage) {
			logger.debug("Employee ID = " + id + " is with profile image updated :: " );
			return new ResponseEntity<Response>(new Response(Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Employee ID = " + id + " is with profile image updated :: ");
			return new ResponseEntity<Response>(new Response(Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}
	
	// Employee updated with Policies
	@PutMapping("/emppolicy/{id}")
		public ResponseEntity<Response> updateEmployeePolicies(@PathVariable Long id, @RequestBody EmployeeDTO model) {
			boolean updateEmployee = employeeService.updateEmployeePolicies(model, id);
			if (updateEmployee) {
				logger.debug("Employee ID = " + id + " is updated :: " + model);
				return new ResponseEntity<Response>(new Response(Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.error("Error while updating Employee :: ");
				return new ResponseEntity<Response>(new Response(Constants.UPDATE_FAIL, Constants.FALSE),
						HttpStatus.NOT_FOUND);
			}
		}
	
	@GetMapping("/cmp/{companyId}/{branchId}")
	public List<EmployeeComIDBranchID> getEmployeeDetailsfromCompanyandBranch(@PathVariable Long companyId,
			@PathVariable Long branchId) {

		List<EmployeeComIDBranchID> employeeDetails = employeeService.getEmployeeDetails(companyId, branchId);

		return employeeDetails;

	}
	
	@GetMapping("/list")
	public ResponseEntity<List<EmployeeDTO>> allBranch(@PathVariable long id) {
		List<EmployeeDTO> allemp = employeeService.listOfEmployee();
		if (allemp != null) {
			logger.debug("Found " + allemp.size() + " Branch");
			return new ResponseEntity<List<EmployeeDTO>>(allemp, HttpStatus.OK);
		}
		throw new EmployeesNotFoundException("Employees not found");

	}

}
