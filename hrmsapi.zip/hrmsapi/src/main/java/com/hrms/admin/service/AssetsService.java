package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.AssetsDTO;

public interface AssetsService {

	public boolean save(AssetsDTO model);

	public AssetsDTO getById(Long id);

	public AssetsDTO getByName(String name);

	public boolean deleteAssets(Long id);

	public boolean updateAssets(AssetsDTO model, Long id);

	public List<AssetsDTO> AllAssets();

}
