package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.BankDetails;

public interface BankRepository extends JpaRepository<BankDetails, Long>{

}
