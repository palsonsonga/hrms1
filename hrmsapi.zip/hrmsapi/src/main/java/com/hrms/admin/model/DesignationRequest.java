package com.hrms.admin.model;

import java.time.LocalDateTime;

public class DesignationRequest {

	private String designation;
	private String skills;
	private Long experiance;
	private LocalDateTime createDate;
	private String createdBy;
	private LocalDateTime updateDate;
	private String updatedBy;

	public DesignationRequest() {

	}

	public DesignationRequest(String designation, String skills, Long experiance, LocalDateTime createDate,
			String createdBy, LocalDateTime updateDate, String updatedBy) {

		this.designation = designation;
		this.skills = skills;
		this.experiance = experiance;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.updateDate = updateDate;
		this.updatedBy = updatedBy;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public Long getExperiance() {
		return experiance;
	}

	public void setExperiance(Long experiance) {
		this.experiance = experiance;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

}
