package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.DesignationDTO;
import com.hrms.admin.entity.Designation;
import com.hrms.admin.repository.Designationrepository;
import com.hrms.admin.service.DesignationService;

/**
 * Contains method to perform DB operation on Designation Record
 * 
 * @author {Ramesh}
 *
 */
@Service
public class DesignationServiceImpl implements DesignationService {

	private final static Logger logger = LoggerFactory.getLogger(DesignationServiceImpl.class);

	@Autowired
	Designationrepository repo;

	/**
	 * Returns Designation data when designation data is available in database by id
	 * 
	 * @param id - Designation Id
	 * @return - DesignationModel
	 */
	@Override
	public DesignationDTO getById(Long id) {

		Optional<Designation> designation = repo.findById(id);
		Designation entity = designation.get();
		DesignationDTO model = new DesignationDTO();
		model.setId(entity.getId());
		model.setDesignation(entity.getDesignation());
		model.setSkills(entity.getSkills());
		model.setExperiance(entity.getExperiance());
		model.setDepartmentid(entity.getDepartmentid());
		model.setCompanyId(entity.getCompanyId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		model.setBranchId(entity.getBranchId());
		logger.debug("Designation found with ID = " + id + " " + entity);
		return model;

	}

	/**
	 * Returns true when new Designation is store in database
	 * 
	 * @param model - new designation data
	 * @return - boolean
	 */

@Override
	public boolean save(DesignationDTO model) {

		Boolean flag = Boolean.FALSE; // null check
		if (model.getDesignation().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}

		/*
		 * // duplicate check for Designation Optional<Designation> findBydesignation =
		 * repo.findBydesignation(model.getDesignation());
		 * 
		 * if (findBydesignation.isPresent()) { Designation designation =
		 * findBydesignation.get(); if
		 * (designation.getDesignation().equals(model.getDesignation())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		Designation entity = new Designation();
		entity.setDesignation(model.getDesignation());
		entity.setSkills(model.getSkills());
		entity.setExperiance(model.getExperiance());
		entity.setDepartmentid(model.getDepartmentid());
		entity.setCompanyId(model.getCompanyId());
		entity.setBranchId(model.getBranchId());
		repo.save(entity);
		logger.debug("Designation Added into database :: " + entity);
		return true;

	}

	/**
	 * Returns true when existing designation data is store in database
	 * 
	 * @param model - new designation data
	 * @param id    - designation Id
	 * @return - boolean
	 */
	@Override
	public boolean updateDesignation(DesignationDTO model, Long id) {

		boolean flag = Boolean.FALSE;
		logger.info("insert into updateDesignationById method in DesignationServiceImpl class ");
		// null check
		if (model.getDesignation().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate checking for Project Name Optional<Designation>
		 * findBydesignation = repo.findBydesignation(model.getDesignation()); if
		 * (findBydesignation.isPresent()) { Designation designation =
		 * findBydesignation.get(); if
		 * (designation.getDesignation().equals(model.getDesignation())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		Optional<Designation> findById = repo.findById(id);
		if (findById != null) {
			Designation olddesignationEntity = findById.get();
			olddesignationEntity.setDesignation(model.getDesignation());
			olddesignationEntity.setSkills(model.getSkills());
			olddesignationEntity.setExperiance(model.getExperiance());
			olddesignationEntity.setDepartmentid(model.getDepartmentid());
			olddesignationEntity.setCompanyId(model.getCompanyId());
			olddesignationEntity.setBranchId(model.getBranchId());
			repo.save(olddesignationEntity);
			logger.debug("Designation ID = " + id + " is updated in to database :: " + olddesignationEntity);
			return true;
		}

		logger.error("Designation is not available in to database with ID= " + id);
		return false;
	}

	/**
	 * Returns true when Designation data is deleted from database by id
	 * 
	 * @param id - designation id
	 * @return - boolean
	 */
	@Override
	public boolean deleteDesignation(Long id) {

		repo.deleteById(id);
		logger.debug(" Designation record is deleted from database: " + id);
		return true;
	}

	public static Map<String, Object> mapData(Page<Designation> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<DesignationDTO> designationModels = pagedResult.stream().map(entity -> {
			DesignationDTO model = new DesignationDTO();
			model.setId(entity.getId());
			model.setDesignation(entity.getDesignation());
			model.setSkills(entity.getSkills());
			model.setExperiance(entity.getExperiance());
			return model;
		}).collect(Collectors.toList());

		response.put("data", designationModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override																			   
	public Map<String, Object> getAllDesignation(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<Designation> pagedResult = null;
		
		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
			
		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
	
	@Override
	public List<DesignationDTO> getDepartmentById(Long id) {
		//List<AttendanceDTO> att = new ArrayList<>();
		List<Designation> a = repo.findByDepartmentId(id);
		List<DesignationDTO> models = a.stream().map(entity -> {
			DesignationDTO model = new DesignationDTO();
			model.setId(entity.getId());
			model.setDesignation(entity.getDesignation());
			return model;
		}).collect(Collectors.toList());

		return models;
	}
}
