package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

public interface MenuService {

	public List<Map<String, Object>> getByMenu(Long menuId);

}
