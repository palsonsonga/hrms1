package com.hrms.admin.dto;


public class AddressDTO {

	private long id;
	
	private String address;

	private String landmark;
	
	private String street;
	
	private String village;

	private String district;
	
	private String state;
	
	private String pincode;
	
	private String country;
	
	private String type;
	
	

	public AddressDTO() {
		super();
	}

	

	


	public AddressDTO(long id, String address, String landmark, String street, String village, String district,
			String state, String pincode, String country, String type) {
		super();
		this.id = id;
		this.address = address;
		this.landmark = landmark;
		this.street = street;
		this.village = village;
		this.district = district;
		this.state = state;
		this.pincode = pincode;
		this.country = country;
		this.type = type;
	}






	public String getType() {
		return type;
	}






	public void setType(String type) {
		this.type = type;
	}






	public long getId() {
		return id;
	}



	public void setId(long id) {
		this.id = id;
	}



	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getLandmark() {
		return landmark;
	}

	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getVillage() {
		return village;
	}

	public void setVillage(String village) {
		this.village = village;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	
	

}
