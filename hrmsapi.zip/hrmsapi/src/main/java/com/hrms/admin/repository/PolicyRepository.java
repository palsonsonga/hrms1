package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Policy;

@Repository
public interface PolicyRepository extends JpaRepository<Policy, Long> {

	//Policy findByName(String name);

	Page<Policy> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Policy a WHERE  a.name LIKE %?1%")
	Page<Policy> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Policy> findByName(String name);
}
