package com.hrms.admin.util;

import com.hrms.admin.entity.Job;

public class JobUtil {

	
	public void copyNonNullValues(Job  req, Job db) {
		

		if(req.getName()!=null) {
			db.setName((req.getName()));
		}
		if(req.getDescription()!=null ) {
			db.setDescription((req.getDescription()));
		}
		


	}
}
