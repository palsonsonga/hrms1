package com.hrms.admin.util;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.hrms.admin.dto.Response;
import com.hrms.admin.model.NotificationRequest;

public class NotificationUtil {
	public static final ResponseEntity<Response> getResponse(Object o, String status) {
		ResponseEntity<Response> response = null;

		NotificationRequest request = null;
		if (o instanceof NotificationRequest)
			request = (NotificationRequest) o;

		switch (status) {
		case "POST":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);
			break;
		case "PUT":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			break;
		case "DELETE":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			break;
		case "POST_INTERNAL_SERVER_ERROR":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
			break;
		case "PUT_NOT_FOUND":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
			break;
		case "PUT_BAD_REQUEST":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.BAD_REQUEST);
			break;
		case "DELETE_NO_CONTENT":
			new ResponseEntity<Response>(
					new Response(request.getSubject() + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NO_CONTENT);
			break;
		default:
			break;
		}

		return response;
	}
}
