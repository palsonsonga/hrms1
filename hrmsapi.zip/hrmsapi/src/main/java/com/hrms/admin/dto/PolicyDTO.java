package com.hrms.admin.dto;

public class PolicyDTO {
	
	private Long id;
	
	private String name;

	private String description;

	private String attachmentLink;
	
	private Long companyId;
	private String companyName;
	public PolicyDTO() {
	
	}
	public PolicyDTO(Long id, String name, String description, String attachmentLink) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.attachmentLink = attachmentLink;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getAttachmentLink() {
		return attachmentLink;
	}
	public void setAttachmentLink(String attachmentLink) {
		this.attachmentLink = attachmentLink;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	
}
