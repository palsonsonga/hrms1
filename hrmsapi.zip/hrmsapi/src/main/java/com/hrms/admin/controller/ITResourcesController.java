package com.hrms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.ItResourceDTO;
import com.hrms.admin.exceptions.ResourceNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.ITResourcesService;
import com.hrms.admin.util.Constants;

@RestController
@RequestMapping("/onboard/IT")
@CrossOrigin	
public class ITResourcesController {
	@Autowired
	private ITResourcesService itService;

	@GetMapping
	public ResponseEntity<List<ItResourceDTO>> getAll() {

		List<ItResourceDTO> allResource = itService.getAll();
		if (allResource != null) {
			return new ResponseEntity<List<ItResourceDTO>>(allResource, HttpStatus.ACCEPTED);
		}
		throw new ResourceNotFoundException("Resource Not Found");

	}

	@GetMapping("/{id}")
	public ResponseEntity<ItResourceDTO> getById(@PathVariable Long id) {
		try {
			ItResourceDTO reById = itService.getById(id);
			return new ResponseEntity<ItResourceDTO>(reById, HttpStatus.OK);

		} catch (Exception e) {
			throw new ResourceNotFoundException("Resource is not there");
		}

	}

	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody ItResourceDTO model, @PathVariable Long id) {
		boolean update = itService.update(model, id);
		if (update) {
			return new ResponseEntity<Response>(
					new Response("ITResources " + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} else {
			return new ResponseEntity<Response>(
					new Response(model.getIpAddress() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			ItResourceDTO resource = itService.getById(id);

			itService.delete(id);
			return new ResponseEntity<Response>(
					new Response(resource.getIpAddress() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<Response>(
					new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}
	


}
