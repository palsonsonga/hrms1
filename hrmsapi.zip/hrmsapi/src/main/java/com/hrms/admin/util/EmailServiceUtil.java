package com.hrms.admin.util;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.mail.MessagingException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang3.RandomStringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.Response;

import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;

@Service
public class EmailServiceUtil {
	
	//private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);
	
	@Autowired
	private JavaMailSender sender;
	
	@Autowired
	private Configuration config;
	
	@Value("${mail.logoUrl}")
	private String logoUrl;

	public Response sendEmail(MailDTO request, Map<String, Object> model) {

		Response response = new Response();
		MimeMessage message = sender.createMimeMessage();
		try {
			// set mediaType
			MimeMessageHelper helper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_MIXED_RELATED,
					StandardCharsets.UTF_8.name());
			// add attachment
			helper.addAttachment("logo.png", new ClassPathResource("logo.png"));
			
				Template t = config.getTemplate(request.getTemplate());
				Map<String,Object> m = model;
			
			String html = FreeMarkerTemplateUtils.processTemplateIntoString(t, m);

			helper.setTo(request.getTo());
			helper.setText(html, true);
			helper.setSubject(request.getSubject());
			helper.setFrom(new InternetAddress(request.getFrom()));
			sender.send(message);

			response.setMessage("mail send to : " + request.getTo());
			response.setStatus(Boolean.TRUE);
			
		} catch (MessagingException | IOException | TemplateException e) {
			response.setMessage("Mail Sending failure : " + e.getMessage());
			System.out.println(e.getMessage());
			response.setStatus(Boolean.FALSE);
		}

		return response;
	}

	
	 public String generateCommonLangPassword() {
		    String upperCaseLetters = RandomStringUtils.random(2, 65, 90, true, true);
		    String lowerCaseLetters = RandomStringUtils.random(2, 97, 122, true, true);
		    String numbers = RandomStringUtils.randomNumeric(2);
		    String specialChar = RandomStringUtils.random(2, 33, 47, false, false);
		    String totalChars = RandomStringUtils.randomAlphanumeric(2);
		    String combinedChars = upperCaseLetters.concat(lowerCaseLetters)
		      .concat(numbers)
		      .concat(specialChar)
		      .concat(totalChars);
		    List<Character> pwdChars = combinedChars.chars()
		      .mapToObj(c -> (char) c)
		      .collect(Collectors.toList());
		    Collections.shuffle(pwdChars);
		    String password = pwdChars.stream()
		      .collect(StringBuilder::new, StringBuilder::append, StringBuilder::append)
		      .toString();
		    return password;
		}

}
