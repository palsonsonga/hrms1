package com.hrms.admin.model;

public class CompanyRequest {
	
	private long id;
	private String companyName;
	private String designation;
	
	public CompanyRequest() {
		
	}
	public CompanyRequest(Long id, String companyName, String designation) {
		
		this.id = id;
		this.companyName = companyName;
		this.designation = designation;
		
	}
	public CompanyRequest(long id, String companyName, String designation) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.designation = designation;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "CompanyRequest [id=" + id + ", companyName=" + companyName + ", designation=" + designation + "]";
	}
	
	
	
}
