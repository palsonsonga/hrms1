package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.ResourceItems;
import com.hrms.admin.repository.ResourceItemsRepository;
import com.hrms.admin.service.ResourceItemsService;

@Service
public class ResourceItemsServiceImpl implements ResourceItemsService {

	@Autowired
	private ResourceItemsRepository itemsRepo;

	@Override
	public ResourceItems save(ResourceItemsDTO model) {

		ResourceItems entity = new ResourceItems();
		/*
		 * BeanUtils.copyProperties(model, entity); entity.setType(model.getType());
		 * entity.setValue(model.getValue()); //
		 * entity.setResourceId(model.getResourceId()); ResourceItems d =
		 * itemsRepo.save(entity); if (!Objects.isNull(d)) ;
		 */
		return entity;

	}

	@Override
	public List<ResourceItemsDTO> getAll() {
		List<ResourceItems> allItems = itemsRepo.findAll();
		List<ResourceItemsDTO> models = allItems.stream().map(entity -> {
			ResourceItemsDTO model = new ResourceItemsDTO();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;

	}

	@Override
	public ResourceItemsDTO getById(Long id) {
		Optional<ResourceItems> optionalEntity = itemsRepo.findById(id);
		ResourceItems entity = optionalEntity.get();
		ResourceItemsDTO model = new ResourceItemsDTO();
		BeanUtils.copyProperties(entity, model);
		return model;
	}

	@Override
	public ResourceItemsDTO getByName(String name) {
		return null;
		/*
		 * ResourceItems findByPolicyName = itemsRepo.findByType(name); ResourceItemsDTO
		 * model = new ResourceItemsDTO(); BeanUtils.copyProperties(findByPolicyName,
		 * model); return model;
		 */
	}

	@Override
	public boolean delete(Long id) {
		itemsRepo.deleteById(id);
		return true;
	}

	@Override
	public boolean update(ResourceItemsDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		/*Optional<ResourceItems> findById = itemsRepo.findById(id);
		if (findById.isPresent()) {
			ResourceItems oldItems = findById.get();
			oldItems.setType(model.getType());
			oldItems.setValue(model.getValue());
//			oldItems.setResourceId(model.getResourceId());
			ResourceItems p = itemsRepo.save(oldItems);
			if (!Objects.isNull(p))
				flag = Boolean.TRUE;
			return flag;
		} else {*/
			return flag;
		}
	
}
