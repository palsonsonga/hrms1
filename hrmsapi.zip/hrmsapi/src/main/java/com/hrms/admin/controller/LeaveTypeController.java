package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.LeaveTypeDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.exceptions.LeaveTypeNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.LeaveTypeService;
import com.hrms.admin.util.Constants;

@RestController
@CrossOrigin
@RequestMapping("/admin/leavetype")
public class LeaveTypeController {

	private static final Logger logger = LoggerFactory.getLogger(LeaveTypeController.class);

	@Autowired
	private LeaveTypeService service;	

	/**
	 * Returns status code when new leave is created
	 * 
	 * @param model - new leave data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody LeaveTypeDTO model) {
		try {
			service.save(model);
			logger.debug("Leave Added :: " + model);
				return new ResponseEntity<Response>(
						new Response("Leave " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Leave :: ", e);
			return new ResponseEntity<Response>(new Response("Leave " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}



	/**
	 * Returns All Leave data when Leave data is available
	 * 
	 * @return - List of LeaveResponseModel
	 */
	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllLeaves(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(), pagingDto.getSearchKey(), pagingDto.getOrderBy());
	}

	/**
	 * Returns leave and status code when leave data is available by id
	 * 
	 * @param id - Leave Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<LeaveTypeDTO> getById(@PathVariable Long id) {

		try {
			LeaveTypeDTO leaveById = service.getById((id));
			logger.debug("Leave fond with ID = " + id + " " + leaveById);
			return new ResponseEntity<LeaveTypeDTO>(leaveById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Leave by Id :: " + id);
			throw new LeaveTypeNotFoundException("LeaveType");
		}
	}

	/**
	 * Returns status code when existing leave data is updated
	 * 
	 * @param model - new leave data
	 * @param id    - leave Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody LeaveTypeDTO model, @PathVariable Long id) {

		try {
			service.updateLeave(model, id);
			
				logger.debug("Branch updated");
				return new ResponseEntity<Response>(
						new Response(model.getLeaveType() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
						HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while updating the Branch");
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			LeaveTypeDTO leavetype = service.getById(id);
			service.deleteLeave(id);
			logger.debug("Leave record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(leavetype.getLeaveType() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Leave not exist ");
			return new ResponseEntity<Response>(new Response("No value present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}

	}

	@GetMapping("/list")
	public ResponseEntity<List<LeaveTypeDTO>> leaveTypes() {
		List<LeaveTypeDTO> allLeavesTypes = service.AllLeavesTypes();
		if (allLeavesTypes != null) {
			logger.debug("Found " + allLeavesTypes.size() + " LeaveTypes");
			return new ResponseEntity<List<LeaveTypeDTO>>(allLeavesTypes,HttpStatus.OK);
		}
		logger.error("error while getting all Company Record");
		throw  new LeaveTypeNotFoundException("LeaveType");
	}
}