package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Branch;

@Repository
public interface BranchRepository extends JpaRepository<Branch, Long> {

	//public Branch findByBranchName(String branchName);
	
    //public Branch findByName(String name);
	
	Page<Branch> findAll(Pageable paging);

	@Query(value = "FROM Branch b WHERE b.companyId=:companyId" )
	List<Branch> findByCompanyId(Long companyId);
	
	@Query(value = "SELECT a FROM Branch a WHERE  a.name LIKE %?1%     OR a.location LIKE %?1% OR a.company LIKE %?1%")
	Page<Branch> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Branch> findByName(String name);
	
	public List<Branch> getCompanyById(Long companyId);
}
