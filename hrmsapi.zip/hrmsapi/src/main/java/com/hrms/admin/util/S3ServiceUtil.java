package com.hrms.admin.util;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.ListObjectsRequest;
import com.amazonaws.services.s3.model.ObjectListing;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;

@Component
public class S3ServiceUtil {
	
	private static String SUFFIX = "/";

	@Value("${aws.Consolelink}")
	private String endpointUrl;

	@Value("${aws.bucket}")
	private String bucketName;
	
	@Value("${aws.Region}")
    private String region;
	
	@Autowired
	private AmazonS3 s3client;
	
	@Transactional
	public boolean uploadFileInFolder(MultipartFile[] Files,String foldername) {

		boolean isFlag=true;
		for(MultipartFile file:Files) {
			try {
				//File file1 = convertMultiPartToFile(file);
				String fileName = file.getOriginalFilename();
				String fileNamewithfolder = foldername + SUFFIX + fileName;
				uploadFileTos3bucket(fileNamewithfolder, file);
				//file.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return isFlag;
	}


	public List<String> getAllFilesInFolder(String foldername) {
		String filrUrl="";
		if (!SUFFIX.endsWith(SUFFIX)) {
			SUFFIX += SUFFIX;
		}
		List<String> keys = new ArrayList<>();
		List<String> fileurls = new ArrayList<>();
		ListObjectsRequest listObjectsRequest = new ListObjectsRequest()
				.withBucketName(bucketName).withPrefix(foldername+SUFFIX);

		ObjectListing objects = s3client.listObjects(listObjectsRequest); 
		for (;;) {
			List<S3ObjectSummary> summaries = objects.getObjectSummaries();
			if
			(summaries.size() < 1) {
				break;
			} summaries.forEach(s ->
			keys.add(s.getKey())); objects = s3client.listNextBatchOfObjects(objects); }
		for(String key:keys) {
			filrUrl=endpointUrl+SUFFIX+key;
			fileurls.add(filrUrl);
		}
		//fileurls.remove(0);
		return fileurls;    
	}


	public String createFolder(String foldername ) {
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(0);
		// create empty content
		InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
		// create a PutObjectRequest passing the folder name suffixed by /
		PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
				foldername + SUFFIX, emptyContent, metadata);
		// send request to S3 to create folder
		s3client.putObject(putObjectRequest);
		return foldername;
	}

	/*
	 * private File convertMultiPartToFile(MultipartFile file) throws IOException {
	 * File convFile = new File(file.getOriginalFilename()); FileOutputStream fos =
	 * new FileOutputStream(convFile); fos.write(file.getBytes()); fos.close();
	 * return convFile; }
	 */
	
	private void uploadFileTos3bucket(String fileName, MultipartFile file) throws IOException {
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentLength(file.getSize());
		InputStream input = new ByteArrayInputStream(file.getBytes());
		s3client.putObject(new PutObjectRequest(bucketName, fileName, input, metadata));
				
	}

	public boolean deleteFileFromFolder(String filename,String foldername) {
		boolean flag = Boolean.TRUE;
		String bucket=bucketName+SUFFIX+foldername;
		s3client.deleteObject(new DeleteObjectRequest(bucket, filename)); 
		return flag;
	}	

	public String deleteFolder( String foldername) {
		for (S3ObjectSummary listOfFolders : s3client.listObjects(bucketName,foldername).getObjectSummaries()){
			s3client.deleteObject(bucketName, listOfFolders.getKey());
		}
		return "Deleted folder name :"+foldername ;
	}
	
	public String generateFileUrl(String filename,String foldername) {
	String url=endpointUrl;
	String filrUrl=url+SUFFIX+foldername+SUFFIX+filename;
		return filrUrl;
	}
	
	// for single file with customized file name
	@Transactional
	public boolean uploadFileInFolder(MultipartFile File,String foldername,String filename) {
		boolean isFlag=true;
			try {
				//File file1 = convertMultiPartToFile(File);
				String fileNamewithfolder = foldername + SUFFIX + filename;
				uploadFileTos3bucket(fileNamewithfolder, File);
				//file1.delete();
			} catch (Exception e) {
				e.printStackTrace();
			}
	
		return isFlag;
	}
	public S3Object getS3File(String fileName,String foldername) {
		 return s3client.getObject(new GetObjectRequest(bucketName+SUFFIX+foldername, fileName));
		 }
}
