package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.SkillDTO;

public interface SkillService {

	public boolean save(SkillDTO model);

	public boolean updateSkill(SkillDTO model, Long id);

	public SkillDTO getById(Long id);
	
	public SkillDTO getByName(String skillSet);

	public List<SkillDTO> getAllSkill();

	public boolean deleteSkill(Long id);
	
//	public Map<String, Object> getAllSkill(Integer pageIndex, Integer pageSize, String sortBy);

	public Map<String, Object> getAllSkill(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
}
