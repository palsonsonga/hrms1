package com.hrms.admin.response;

import java.util.List;

import org.springframework.batch.core.BatchStatus;

public class BatchResponse {
	private String message;
	private boolean status;
	private Data data;

	public BatchResponse() {

	}

	public BatchResponse(String message, boolean status, Data data) {
		super();
		this.message = message;
		this.status = status;
		this.data = data;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param batchStatus the message to set
	 */
	public void setMessage(String batchStatus) {
		this.message = batchStatus;
	}

	/**
	 * @return the status
	 */
	public boolean isStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(boolean status) {
		this.status = status;
	}

	/**
	 * @return the data
	 */
	public Data getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Data data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "BatchResponse [message=" + message + ", status=" + status + ", data=" + data + "]";
	}

}
