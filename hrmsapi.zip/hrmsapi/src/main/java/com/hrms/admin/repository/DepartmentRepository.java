package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> {

	public Department findByname(String name);
	
	public Page<Department> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Department a WHERE  a.name LIKE %?1%")
	Page<Department> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Department> findByName(String name);
	
	@Query(value = "FROM Department d WHERE d.branchId=:branchId" )
	public List<Department>  findByBranchId(Long branchId);
}
