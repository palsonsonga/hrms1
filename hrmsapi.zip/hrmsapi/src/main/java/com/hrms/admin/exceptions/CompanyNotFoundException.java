package com.hrms.admin.exceptions;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;


@ResponseStatus(HttpStatus.NOT_FOUND)
public class CompanyNotFoundException extends RuntimeException {
	private static final Logger logger = LoggerFactory.getLogger(CompanyNotFoundException.class);
	private static final long serialVersionUID = 1L;

	public CompanyNotFoundException() {
		super();
		logger.info("Enter into CompanyNotFoundException() Default Constructor CompanyNotFoundException Class");

	}

	public CompanyNotFoundException(String message) {
		super(message);
		 logger.info("Enter into CompanyNotFoundException() Parm-Constructor in CompanyNotFoundException class"+message);

	}

}
