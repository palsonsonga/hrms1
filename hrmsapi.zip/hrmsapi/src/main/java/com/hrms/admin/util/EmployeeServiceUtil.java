package com.hrms.admin.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.AcademicDetailsDTO;
import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.BankDTO;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.FileDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.ProfessionalDetailsDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.AcademicDetails;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.BankDetails;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Files;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.entity.ProfessionalDetails;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.ResourceItems;
import com.hrms.admin.repository.BankRepository;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.FilesRepository;
import com.hrms.admin.repository.ResourceItemsRepository;

@Component
public class EmployeeServiceUtil {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceUtil.class);
	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private BankRepository bankRepo;

	@Autowired
	private FilesRepository filerepo;

	@Autowired
	private ResourceItemsRepository ResourceItemsRepo;

	public Employee  saveEmployee(EmployeeDTO employeedto ) {

		Employee employee = new Employee();
		employee.setFirstName(employeedto.getFirstName());
		employee.setLastName(employeedto.getLastName());
		employee.setEmail(employeedto.getEmail());
		employee.setUserName(employeedto.getUserName());
		employee.setDateOfBirth(employeedto.getDateOfBirth());
		employee.setGender(employeedto.getGender());
		employee.setMaritalStatus(employeedto.getMaritalStatus());
		employee.setContactNo(employeedto.getContactNo());
		employee.setAlternateContactNo(employeedto.getAlternateContactNo());
		employee.setAadharCard(employeedto.getAadharCard());
		employee.setPanCard(employeedto.getPanCard());
		employee.setVoterID(employeedto.getVoterID());
		employee.setJoiningDate(employeedto.getJoiningDate());
		employee.setBloodGroup(employeedto.getBloodGroup()); // saving bank details
		BankDetails bankdetails=new BankDetails();
		bankdetails.setBankName(employeedto.getBankDetail().getBankName());
		bankdetails.setIfscCode(employeedto.getBankDetail().getIfscCode());
		bankdetails.setAccountHolderName(employeedto.getBankDetail().
				getAccountHolderName());
		bankdetails.setAccountNo(employeedto.getBankDetail().getAccountNo());
		bankdetails.setBranchName(employeedto.getBankDetail().getBankName());
		BankDetails bankinfo=bankRepo.save(bankdetails);
		employee.setBankAccontId(bankinfo.getId());
		List<Address> addresses = new ArrayList<>();
		Map<String, Object> addressMap = employeedto.getAddresses();
		for ( String key : addressMap.keySet() ) {
			ObjectMapper mapper = new ObjectMapper();
			AddressDTO addressdto = mapper.convertValue(addressMap.get(key), AddressDTO.class);
			Address address=new Address();
			address.setAddress(addressdto.getAddress());
			address.setLandmark(addressdto.getLandmark());
			address.setStreet(addressdto.getStreet());
			address.setVillage(addressdto.getVillage());
			address.setDistrict(addressdto.getDistrict());
			address.setState(addressdto.getState());
			address.setPinCode(addressdto.getPincode());
			address.setCountry(addressdto.getCountry());
			address.setType(key);
			addresses.add(address);
		}
		employee.setAddress(addresses);
		//academicDetail adding

		List<AcademicDetails> academicDetaillist = new ArrayList<>();
		Map<String, Object> academicDetailsmap = employeedto.getAcademicDetails(); 
		for ( String key : academicDetailsmap.keySet() ) {
			ObjectMapper mapper = new  ObjectMapper();
			AcademicDetailsDTO academicDetailsDTO = mapper.convertValue(academicDetailsmap.get(key), AcademicDetailsDTO.class);
			AcademicDetails academicDetails=new AcademicDetails();
			academicDetails.setInstituteName(academicDetailsDTO.getInstituteName());
			academicDetails.setPercentage(academicDetailsDTO.getPercentage());
			academicDetails.setQualification(academicDetailsDTO.getQualification());
			academicDetails.setYearOfPassing(academicDetailsDTO.getYearOfPassing());
			academicDetails.setType(key); 
			academicDetaillist.add(academicDetails); 
		}
		employee.setAcademicDetails(academicDetaillist);

		List<ProfessionalDetails> proDetails = new ArrayList<>();
		for (ProfessionalDetailsDTO prdDto:employeedto.getProfessionalDetails()) {
			ProfessionalDetails details=new ProfessionalDetails();
			details.setClient(prdDto.getClient());
			details.setCompanyName(prdDto.getCompanyName());
			details.setExperience(prdDto.getExperience());
			details.setJoiningDate(prdDto.getJoiningDate());
			details.setRelievingDate(prdDto.getRelievingDate());
			proDetails.add(details);
		} employee.setProfessionalDetails(proDetails);

		employee.setDepartmentId(employeedto.getDepartmentId());
		employee.setDesiginationId(employeedto.getDesignationId());
		employee.setCompanyId(employeedto.getCompanyId());
		employee.setBranchId(employeedto.getBranchId());
		employee.setIsApprove(Boolean.FALSE);
		employee.setIsActive(Boolean.TRUE);

		Employee employee1 = employeeRepo.save(employee);
		logger.debug("Employee saved with ID::"+employee1.getId());
		return employee1;

	}



	public EmployeeDTO getEmployee(Employee employee) {
		EmployeeDTO employeedto=new EmployeeDTO();
		employeedto.setId(employee.getId());
		employeedto.setFirstName(employee.getFirstName());
		employeedto.setLastName(employee.getLastName());
		employeedto.setEmail(employee.getEmail());
		employeedto.setUserName(employee.getUserName());
		employeedto.setDateOfBirth(employee.getDateOfBirth());
		employeedto.setGender(employee.getGender());
		employeedto.setMaritalStatus(employee.getMaritalStatus());
		employeedto.setContactNo(employee.getContactNo());
		employeedto.setAlternateContactNo(employee.getAlternateContactNo());
		employeedto.setAadharCard(employee.getAadharCard());
		employeedto.setPanCard(employee.getPanCard());
		employeedto.setVoterID(employee.getVoterID());
		employeedto.setJoiningDate(employee.getJoiningDate());
		employeedto.setBloodGroup(employee.getBloodGroup()); 
		BankDTO bankdto=new BankDTO();
		bankdto.setId(employee.getBankDetails().getId());
		bankdto.setBankName(employee.getBankDetails().getBankName());
		bankdto.setIfscCode(employee.getBankDetails().getIfscCode());
		bankdto.setAccountHolderName(employee.getBankDetails().
				getAccountHolderName());
		bankdto.setAccountNo(employee.getBankDetails().getAccountNo());
		bankdto.setBranchName(employee.getBankDetails().getBankName());
		employeedto.setBankDetail(bankdto);
		Map<String,Object> addresses = new HashMap<>(); 
		for(Address address:employee.getAddress()) {
			AddressDTO addressdto=new AddressDTO();
			addressdto.setId(address.getId());
			addressdto.setAddress(address.getAddress());
			addressdto.setLandmark(address.getLandmark());
			addressdto.setStreet(address.getStreet());
			addressdto.setVillage(address.getVillage());
			addressdto.setDistrict(address.getDistrict());
			addressdto.setState(address.getState());
			addressdto.setPincode(address.getPinCode());
			addressdto.setCountry(address.getCountry());
			addressdto.setType(address.getType());
			addresses.put(address.getType(), addressdto);
		}
		employeedto.setAddresses(addresses);

		Map<String,Object> academicDetailmap = new HashMap<>();
		for(AcademicDetails academicDetail:employee.getAcademicDetails()) { 
			AcademicDetailsDTO  academicDetailsDTO=new AcademicDetailsDTO();
			academicDetailsDTO.setId(academicDetail.getId());
			academicDetailsDTO.setInstituteName(academicDetail.getInstituteName());
			academicDetailsDTO.setPercentage(academicDetail.getPercentage());
			academicDetailsDTO.setQualification(academicDetail.getQualification());
			academicDetailsDTO.setYearOfPassing(academicDetail.getYearOfPassing());
			academicDetailsDTO.setType(academicDetail.getType());
			academicDetailmap.put(academicDetail.getType(), academicDetailsDTO); 
		}
		employeedto.setAcademicDetails(academicDetailmap);

		List<ProjectDTO> list=new ArrayList<>();
		for(Project project:employee.getProjects()) {
			ProjectDTO projectdto = new ProjectDTO();
			projectdto.setId(project.getId());
			projectdto.setName(project.getName());
			projectdto.setDescription(project.getDescription());
			list.add(projectdto);
		}		   
		employeedto.setProjects(list);
		List<FileDTO> files=new ArrayList<>();
		List<Files> filesList=filerepo.findByemployeeId(employee.getId());
		for(Files file:filesList) {
			FileDTO filedto=new FileDTO();
			filedto.setId(file.getId());
			filedto.setFilename(file.getName());
			filedto.setFilePath(file.getFilePath());
			files.add(filedto);
		}
		employeedto.setFiles(files);
		// policies
		List<PolicyDTO> policylist=new ArrayList<>();
		for(Policy policy:employee.getPolicies()) {
			PolicyDTO policydto = new PolicyDTO();
			policydto.setId(policy.getId());
			policydto.setName(policy.getName());
			policydto.setDescription(policy.getDescription());
			policydto.setAttachmentLink(policy.getAttachmentLink());
			policylist.add(policydto);
		}
		employeedto.setPolicies(policylist);
		// Resource items

		List<ResourceItemsDTO> resourceItemDtolist=new ArrayList<>();
		List<ResourceItems> resourceItemlist=ResourceItemsRepo.findByEmployeeId(employee.getId());
		for(ResourceItems resourceItems:resourceItemlist)
		{
			ResourceItemsDTO resourceItemsDTO = new ResourceItemsDTO();
			resourceItemsDTO.setId(resourceItems.getId()); //add asset to resource item
			resourceItemsDTO.setName(resourceItems.getAsset().getName());
			resourceItemsDTO.setDescription(resourceItems.getAsset().getDescription());
			resourceItemsDTO.setValue(resourceItems.getValue());
			resourceItemsDTO.setAssetId(resourceItems.getAsset().getId());
			resourceItemDtolist.add(resourceItemsDTO);
		}
		employeedto.setResourceItems(resourceItemDtolist);

		//ProfessionalDetails

		List<ProfessionalDetailsDTO> professionalList=new ArrayList<>();
		for(ProfessionalDetails professional:employee.getProfessionalDetails()) {
			ProfessionalDetailsDTO professionalDTO = new ProfessionalDetailsDTO();
			professionalDTO.setId(professional.getId());
			professionalDTO.setClient(professional.getClient());
			professionalDTO.setCompanyName(professional.getCompanyName());
			professionalDTO.setExperience(professional.getExperience());
			professionalDTO.setJoiningDate(professional.getJoiningDate());
			professionalDTO.setRelievingDate(professional.getRelievingDate());
			professionalList.add(professionalDTO); }
		employeedto.setProfessionalDetails(professionalList);

		// profile image details
		ProfileImageDTO profileImageDTO=new ProfileImageDTO();
		profileImageDTO.setId(employee.getProfileImage().getId());
		profileImageDTO.setImageName(employee.getProfileImage().getImageName());
		profileImageDTO.setImageurl(employee.getProfileImage().getImageurl());
		employeedto.setProfileiamge(profileImageDTO);

		employeedto.setIpAddress(employee.getIpAddress());
		employeedto.setPort(employee.getPort());
		employeedto.setDepartmentId(employee.getDepartmentId());
		employeedto.setDepartmentName(employee.getDepartment().getName());
		employeedto.setDesignationId(employee.getDesiginationId());
		employeedto.setDesignationName(employee.getDesignation().getDesignation());
		employeedto.setCompanyId(employee.getCompanyId());
		employeedto.setCompanyName(employee.getCompany().getName());
		employeedto.setBranchId(employee.getBranchId());
		employeedto.setBranchName(employee.getBranch().getName());
		employeedto.setIsApprove(employee.getIsApprove());
		employeedto.setIsActive(employee.getIsActive());
		employeedto.setFolderName(employee.getFolderName());
		logger.debug("Employee found with ID::"+employeedto.getId());
		return employeedto;
	}

	public Employee updateEmplyee(EmployeeDTO model, Long id) {
		Optional<Employee> findEmployee = employeeRepo.findById(id);
		Employee employee = findEmployee.get();
		if (findEmployee.isPresent()) {
			employee.setFirstName(model.getFirstName());
			employee.setLastName(model.getLastName());
			employee.setEmail(model.getEmail());
			employee.setUserName(model.getUserName());
			employee.setDateOfBirth(model.getDateOfBirth());
			employee.setGender(model.getGender());
			employee.setMaritalStatus(model.getMaritalStatus());
			employee.setContactNo(model.getContactNo());
			employee.setAlternateContactNo(model.getAlternateContactNo());
			employee.setAadharCard(model.getAadharCard());
			employee.setPanCard(model.getPanCard());
			employee.setVoterID(model.getVoterID());
			employee.setJoiningDate(model.getJoiningDate());
			employee.setBloodGroup(model.getBloodGroup()); // saving bank details
			BankDetails bankdetails=new BankDetails();
			bankdetails.setId(model.getBankDetail().getId());
			bankdetails.setBankName(model.getBankDetail().getBankName());
			bankdetails.setIfscCode(model.getBankDetail().getIfscCode());
			bankdetails.setAccountHolderName(model.getBankDetail().
					getAccountHolderName());
			bankdetails.setAccountNo(model.getBankDetail().getAccountNo());
			bankdetails.setBranchName(model.getBankDetail().getBankName());
			BankDetails bankinfo=bankRepo.save(bankdetails);
			employee.setBankAccontId(bankinfo.getId());
			List<Address> addresses = new ArrayList<>();
			Map<String, Object> addressMap = model.getAddresses();
			for ( String key : addressMap.keySet() ) {
				ObjectMapper mapper = new ObjectMapper();
				AddressDTO addressdto = mapper.convertValue(addressMap.get(key), AddressDTO.class);
				Address address=new Address();
				address.setId(addressdto.getId());
				address.setAddress(addressdto.getAddress());
				address.setLandmark(addressdto.getLandmark());
				address.setStreet(addressdto.getStreet());
				address.setVillage(addressdto.getVillage());
				address.setDistrict(addressdto.getDistrict());
				address.setState(addressdto.getState());
				address.setPinCode(addressdto.getPincode());
				address.setCountry(addressdto.getCountry());
				address.setType(key);
				addresses.add(address);
			}
			//academicDetail adding

			List<AcademicDetails> academicDetaillist = new ArrayList<>();
			Map<String, Object> academicDetailsmap = model.getAcademicDetails();
			for ( String key : academicDetailsmap.keySet() ) {
				ObjectMapper mapper = new ObjectMapper();
				AcademicDetailsDTO academicDetailsDTO = mapper.convertValue(academicDetailsmap.get(key), AcademicDetailsDTO.class);
				AcademicDetails academicDetails=new AcademicDetails();
				academicDetails.setId(academicDetailsDTO.getId());
				academicDetails.setInstituteName(academicDetailsDTO.getInstituteName());
				academicDetails.setPercentage(academicDetailsDTO.getPercentage());
				academicDetails.setQualification(academicDetailsDTO.getQualification());
				academicDetails.setYearOfPassing(academicDetailsDTO.getYearOfPassing());
				academicDetails.setType(key);
				academicDetaillist.add(academicDetails);
			}
			employee.setAcademicDetails(academicDetaillist); 
			//ProfessionalDetails
			List<ProfessionalDetails> proDetails = new ArrayList<>(); 
			for (ProfessionalDetailsDTO prdDto:model.getProfessionalDetails()) {
				ProfessionalDetails details=new ProfessionalDetails();
				details.setId(prdDto.getId());
				details.setClient(prdDto.getClient());
				details.setCompanyName(prdDto.getCompanyName());
				details.setExperience(prdDto.getExperience());
				details.setJoiningDate(prdDto.getJoiningDate());
				details.setRelievingDate(prdDto.getRelievingDate());
				proDetails.add(details);
			} employee.setProfessionalDetails(proDetails);

			employee.setAddress(addresses);
			employee.setDepartmentId(model.getDepartmentId());
			employee.setDesiginationId(model.getDesignationId());
			employee.setCompanyId(model.getCompanyId());
			employee.setBranchId(model.getBranchId());
			employee.setIsApprove(Boolean.FALSE);
			employee.setIsActive(Boolean.TRUE);
		}
		Employee emp =employeeRepo.save(employee);
		logger.debug("Employee saved with ID::"+emp.getId());
		return emp;

	}


}
