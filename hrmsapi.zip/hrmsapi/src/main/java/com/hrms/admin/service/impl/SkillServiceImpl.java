package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.SkillDTO;
import com.hrms.admin.entity.Skill;
import com.hrms.admin.repository.SkillRepository;
import com.hrms.admin.service.SkillService;



/**
 * Contains method to perform DB operation on Skills Record
 * @author {Prabhat}
 *
 */
@Service
public class SkillServiceImpl implements SkillService {

	private static final Logger logger = LoggerFactory.getLogger(SkillServiceImpl.class);

	@Autowired
	private SkillRepository repo;

	/**
	 * Returns true when new skill is store in database
	 * 
	 * @param model - new skill data
	 * @return - boolean
	 */
	@Override
	public boolean save(SkillDTO model) {
		boolean flag = Boolean.FALSE;
		//null check
		if(model.equals(null) || model.getSkillSet().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		
		/*
		 * //duplicate check Optional<Skill> findBySkillSet =
		 * repo.findBySkillSet(model.getSkillSet()); if(findBySkillSet.isPresent()) {
		 * Skill skill = findBySkillSet.get();
		 * if(skill.getSkillSet().equals(model.getSkillSet())) { flag = Boolean.FALSE;
		 * return flag; }
		 * 
		 * }
		 */
		Skill entity = new Skill();
		entity.setSkillSet(model.getSkillSet());
		entity.setDescription(model.getDescription());
		entity.setCompanyId(model.getCompanyId());
		Skill savedSkill = repo.save(entity);
		if(!Objects.isNull(savedSkill))
			flag = Boolean.TRUE;
		logger.debug("Skill Added into database :: " + entity);
		return flag;
	}

	/**
	 * Returns true when existing skill data is store in database
	 * 
	 * @param model - new skill data
	 * @param id - skill Id
	 * @return - boolean
	 */
	@Override
	public boolean updateSkill(SkillDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		//null check
		if(model.equals(null) || model.getSkillSet().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		
		/*
		 * //duplicate check Optional<Skill> findBySkillSet =
		 * repo.findBySkillSet(model.getSkillSet()); if(findBySkillSet.isPresent()) {
		 * Skill skill = findBySkillSet.get();
		 * if(skill.getSkillSet().equals(model.getSkillSet())) { flag = Boolean.FALSE;
		 * return flag; }
		 * 
		 * }
		 */
		Optional<Skill> findById = repo.findById(id);
		if (findById.isPresent()) {
			Skill oldSkill = findById.get();
			oldSkill.setId(id);
			oldSkill.setSkillSet(model.getSkillSet());
			oldSkill.setDescription(model.getDescription());
			oldSkill.setCompanyId(model.getCompanyId());
			Skill updated =repo.save(oldSkill);
			if(!Objects.isNull(updated))
				flag = Boolean.TRUE;
			logger.debug("Skill ID = " + id + " is updated in to database :: " + oldSkill);
			return flag;
		} else {
			logger.error("Skill is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns Skill data when Skill data is available in database by id
	 * @param id - skill Id
	 * @return - SkillResponse
	 */
	@Override
	public SkillDTO getById(Long id) {
		Optional<Skill> optionalEntity = repo.findById(id);
		Skill skillEntity = optionalEntity.get();
		SkillDTO model = new SkillDTO();
		model.setId(skillEntity.getId());
		model.setSkillSet(skillEntity.getSkillSet());
		model.setDescription(skillEntity.getDescription());
		model.setCompanyId(skillEntity.getCompanyId());
		model.setCompanyName(skillEntity.getCompany().getName());
		BeanUtils.copyProperties(skillEntity, model);
		logger.debug("Skill found with ID = " + id + " " + skillEntity);
		return model;
	}

	/**
	 * Returns Skill data when Skill data is available in database by name
	 * @param name - skillSet name
	 * @return - DepartmentModel
	 */
	@Override
	public SkillDTO getByName(String skillSet) {
		Skill skillEntity = repo.findByskillSet(skillSet);
		SkillDTO model = new SkillDTO();
		model.setId(skillEntity.getId());
		model.setSkillSet(skillEntity.getSkillSet());
		model.setDescription(skillEntity.getDescription());
		model.setCompanyId(skillEntity.getCompanyId());
		model.setCompanyName(skillEntity.getCompany().getName());
		logger.debug("Skill found with Name = " + skillSet + " " + skillEntity);
		return model;
	}

	/**
	 * Returns All Skills data when skill data is available in database
	 * @return - List of Skill
	 */
	@Override
	public List<SkillDTO> getAllSkill() {

		List<Skill> skillEntity = repo.findAll();
		List<SkillDTO> models = skillEntity.stream().map(entity -> {
			SkillDTO model = new SkillDTO();
			model.setId(entity.getId());
			model.setSkillSet(entity.getSkillSet());
			model.setDescription(entity.getDescription());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns true when skill data is deleted from database by id
	 * @param id - skill id
	 * @return - boolean
	 */
	@Override
	public boolean deleteSkill(Long id) {
		repo.deleteById(id);
		logger.debug(" Skill record is deleted from database ");
		return true;

	}

	//paging

	/*
	 * @Override public Map<String, Object> getAllSkill(Integer pageIndex, Integer
	 * pageSize, String sortBy) { Pageable paging = PageRequest.of(pageIndex,
	 * pageSize, Sort.by(sortBy)); Page<Skill> pagedResult = repo.findAll(paging);
	 * 
	 * if(pagedResult.hasContent()) { return mapData(pagedResult); } else { return
	 * new HashMap<String, Object>(); } }
	 */


	public static Map<String, Object> mapData(Page<Skill> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<SkillDTO> skillModels = pagedResult.stream().map(skillEntity -> { 
			SkillDTO model =	new SkillDTO(); 
			model.setId(skillEntity.getId());
			model.setSkillSet(skillEntity.getSkillSet());
			model.setDescription(skillEntity.getDescription());
			return	model;}).collect(Collectors.toList());
		response.put("data", skillModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override
	public Map<String, Object> getAllSkill(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {

		Pageable paging = null;

		Page<Skill> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
}