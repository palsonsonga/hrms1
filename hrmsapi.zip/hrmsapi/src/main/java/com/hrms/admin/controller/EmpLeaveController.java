package com.hrms.admin.controller;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.EmpLeaveDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.EmpLeaveIdNotFoundException;
import com.hrms.admin.service.EmpLeaveService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Employee Leave Record
 * 
 * @author {Sandeep}
 *
 */
@RestController
@RequestMapping("/employee/leave")
@CrossOrigin
public class EmpLeaveController {

	private static final Logger logger = LoggerFactory.getLogger(EmpLeaveController.class);

	@Autowired
	private EmpLeaveService service;

	/**
	 * Returns status code when new EmpLeave is created
	 * 
	 * @param model - new empLeave data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> applyLeave(@RequestBody EmpLeaveDTO model) {
		try {
			service.addEmpLeave(model);
			logger.debug("EmpLeave Added :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding EmpLeave :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns status code when existing empLeave data is updated
	 * 
	 * @param model - new empLeave data
	 * @param id    - Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody EmpLeaveDTO model, @PathVariable Long id) {

		boolean updateEmpLeave = service.updateEmpLeave(model, id);
		if (updateEmpLeave) {
			logger.debug("EmpLeave ID = " + id + " is updated :: " + model);

			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);

		} else {
			logger.error("Error while updating EmpLeave :: ");
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns status code when existing empLeave data is updated
	 * 
	 * @param model - new empLeave data
	 * @param id    - Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/approval/{id}")
	public ResponseEntity<Response> approval(@RequestBody Map<String,Object> approval, @PathVariable Long id) {

		boolean empLeaveApproval = service.approveOrReject(approval.get("approval").toString(), id);
		if (empLeaveApproval) {
			logger.debug("EmpLeave ID = " + id + " is updated :: ");

			return new ResponseEntity<Response>(new Response(id + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} else {
			logger.error("Error while  EmpLeave approval:: ");
			return new ResponseEntity<Response>(new Response(id + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns EmpLeave and status code when empLeave data is available by id
	 * 
	 * @param id - Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<EmpLeaveDTO> getById(@PathVariable Long id) {

		try {
			EmpLeaveDTO empLeaveById = service.getEmpLeaveByid(id);
			logger.debug("empLeave fond with ID = " + id + " " + empLeaveById);
			return new ResponseEntity<EmpLeaveDTO>(empLeaveById, HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while getting empLeave by Id :: " + id);
			throw new EmpLeaveIdNotFoundException("empLeave is not available for Id ::" + id);
		}

	}

	/**
	 * Returns EmpLeave for given Date
	 * 
	 * @param date1 - Date
	 * @return - list of employee leaves
	 */
	@GetMapping("/date{date}")
	public List<EmpLeaveDTO> getByDate(@PathVariable("date") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date) {

		try {

			List<EmpLeaveDTO> findLeavesbyDate = service.findLeavesbyDate(date);
			logger.debug("empLeave fond with ID = " + date + " " + findLeavesbyDate);
			return findLeavesbyDate;

		} catch (Exception e) {
			logger.error("Error while getting empLeave by Id :: ");
			throw new EmpLeaveIdNotFoundException("empLeave is not available for Id ::");
		}

	}

	/**
	 * Returns All Leaves data when empLeave data is available
	 * 
	 * @return - List of empLeaveModel
	 */
	@GetMapping
	public List<EmpLeaveDTO> getEmpLeavelist() {
		List<EmpLeaveDTO> allEmpLeaves = service.getAllEmpLeave();
		if (allEmpLeaves != null) {
			logger.debug("Found " + allEmpLeaves.size() + " EmpLeave");
			return allEmpLeaves;
		}
		logger.error("error while getting all EmpLeave Record");
		throw new EmpLeaveIdNotFoundException("EmpLeave not found");
	}

	/**
	 * Returns status code when empLeave data is deleted
	 * 
	 * @param id - id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteEmpLeave(@PathVariable Long id) {
		try {
		EmpLeaveDTO empLeave = service.getEmpLeaveByid(id);

			service.deleteEmpLeave(id);
			logger.debug("empLeave record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(empLeave.getLeaveType() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("empLeave not exist ");
			return new ResponseEntity<Response>(
					new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns EmpLeave for given time period
	 * 
	 * @param date1 - startDate
	 * @param date2 - endDate
	 * @return - list of employee leaves
	 */
	@GetMapping("id/{id}/{date1}/{date2}")
	public List<EmpLeaveDTO> getEmpLeavesByDate(@PathVariable("id") Long id,
			@PathVariable("date1") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date1,
			@PathVariable("date2") @DateTimeFormat(pattern = "yyyy-MM-dd") Date date2) {

		List<EmpLeaveDTO> list = service.getEmpLeavesByDate(id, date1, date2);
		logger.debug("empLeave records are found with id ");

		return list;

	}

	/**
	 * Returns EmpLeave for given employee
	 * 
	 * @param id - empId
	 * @return - list of employee leaves
	 */
	@GetMapping("/empId/{id}")
	public List<EmpLeaveDTO> getEmpLeavesByDate(@PathVariable() Long id) {

		List<EmpLeaveDTO> list = service.findLeavesbyEmpId(id);
		logger.debug("empLeave records are found with id ");

		return list;

	}
	
	@PostMapping("emp/page")
	public Map<String, Object> getAllEmpLeaves(@RequestBody PaginationDTO pagingDto) {
	    return service.getAllEmpLeaves(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
	
	@PostMapping("team/page")
	public Map<String, Object> getAllTeamLeaves(@RequestBody PaginationDTO pagingDto) {
	    return service.getAllTeamLeaves(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
	@GetMapping("mngr/{id}")
	public List<String> getManagers(@PathVariable Long id){
	List<String> managers = service.findManagerList(id);
	return managers;

	}
}
