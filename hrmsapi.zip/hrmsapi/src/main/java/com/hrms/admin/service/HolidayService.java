package com.hrms.admin.service;

import java.util.Map;

import com.hrms.admin.dto.HolidayDTO;

public interface HolidayService {

	/**
	 * Takes Reg Form data as input and returns true
	 * 
	 * @param holidayId
	 */
	public boolean save(HolidayDTO model);

	/**
	 * select all rows and give as List<Holidays>
	 */
//	public Map<String, Object> getAllHolidays(Integer pageIndex, Integer pageSize, String sortBy);

	/**
	 * Provide id as input and returns one row as one object
	 */
	public HolidayDTO getById(Long id);

	public HolidayDTO getByName(String name);

	/**
	 * Takes PK(ID) as input and perform delete operation
	 */
	public boolean deleteHoliday(Long id);

	public boolean updateHoliday(HolidayDTO model, Long id);
	
	public Map<String, Object> getAllHoliday(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
	
	
}
