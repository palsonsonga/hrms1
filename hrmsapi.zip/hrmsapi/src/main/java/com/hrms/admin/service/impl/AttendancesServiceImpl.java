package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AttendanceDTO;
import com.hrms.admin.entity.Attendance;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Company;
import com.hrms.admin.repository.AttendancesRepository;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.service.AttendanceService;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Chandu}
 *
 */
@Service
public class AttendancesServiceImpl implements AttendanceService {

	private static final Logger logger = LoggerFactory.getLogger(AttendancesServiceImpl.class);

	@Autowired
	private AttendancesRepository attRepo;
	
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private BranchRepository branchRepo;
	/**
	 * Returns true when new Attendance is store in database
	 * 
	 * @param model - new Attendance data
	 * @return - boolean
	 */

	@Override
	public boolean save(AttendanceDTO model) {

		boolean flag = Boolean.FALSE;

		
		// null check
		if(model.getBranchId().equals(null) && model.getCompanyId().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		
		/*
		 * // duplicate check for company Optional<Attendance> findByCompany =
		 * attRepo.findByCompany(model.getCompany()); if(findByCompany.isPresent()) {
		 * Attendance attendance = findByCompany.get(); System.out.println(attendance);
		 * if(attendance.getCompany().equals(model.getCompany())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		/*
		 * // duplicate check for branch Optional<Attendance> findByBranch =
		 * attRepo.findByBranch(model.getBranch()); if(findByBranch.isPresent()) {
		 * Attendance attendance = findByBranch.get();
		 * if(attendance.getBranch().equals(model.getBranch())) { flag = Boolean.FALSE;
		 * return flag; } }
		 */
		Attendance entity = new Attendance();
		entity.setCompanyId(model.getCompanyId());
		entity.setBranchId(model.getBranchId());
		entity.setInTime(model.getInTime());
		entity.setOutTime(model.getOutTime());
		Company company=companyRepo.findById(model.getCompanyId()).get();
		entity.setCompanyName(company.getName());
		entity.setBranchId(model.getBranchId());
		Branch branch=branchRepo.findById(model.getBranchId()).get();
		entity.setBranchName(branch.getName());
		Attendance a=attRepo.save(entity);
		if(!Objects.isNull(a)) 
			flag = Boolean.TRUE;
		logger.debug("Attendance Added into database :: " + entity);
		return flag;
	}

	@Override																			   
	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<Attendance> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = attRepo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = attRepo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	/**
	 * Returns Attendance data when Attendance data is available in database by id
	 * @param id - Attendance Id
	 * @return - AttendanceModel
	 */
	@Override
	public AttendanceDTO getById(Long id) {
		Optional<Attendance> optionalEntity = attRepo.findById(id);
		Attendance entity = optionalEntity.get();
		AttendanceDTO model = new AttendanceDTO();
		model.setId(entity.getId());
		model.setCompanyId(entity.getCompanyId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		model.setBranchId(entity.getBranchId());
		model.setInTime(entity.getInTime());
		model.setOutTime(entity.getOutTime());
		logger.debug("Attendance found with ID = " + id + " " + entity);
		return model;
	}

	@Override
	public boolean deleteAttendnace(Long id) {
		attRepo.deleteById(id);
		logger.debug(" Attendnace record is deleted from database ");
		return true;
	}

	/**
	 * Returns true when existing Attendance data is store in database
	 * 
	 * @param model - new Attendance data
	 * @param id - Attendance Id
	 * @return - boolean
	 */
	@Override
	public boolean updateAttendnace(AttendanceDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		// null check
		if(model.getBranchId().equals(null) && model.getCompanyId().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate check for company Optional<Attendance> findByCompany =
		 * attRepo.findByCompany(model.getCompany()); if(findByCompany.isPresent()) {
		 * Attendance attendance = findByCompany.get(); System.out.println(attendance);
		 * if(attendance.getCompany().equals(model.getCompany())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		// duplicate check for branch
		/*
		 * Optional<Attendance> findByBranch = attRepo.findByBranch(model.getBranch());
		 * if(findByBranch.isPresent()) { Attendance attendance = findByBranch.get();
		 * if(attendance.getBranch().equals(model.getBranch())) { flag = Boolean.FALSE;
		 * return flag; } }
		 */
		Optional<Attendance> findById = attRepo.findById(id);
		if (findById.isPresent()) {
			Attendance oldAttendance = findById.get();
			oldAttendance.setCompanyId(model.getCompanyId());
			oldAttendance.setBranchId(model.getBranchId());
			oldAttendance.setInTime(model.getInTime());
			oldAttendance.setOutTime(model.getOutTime());
			Attendance a =attRepo.save(oldAttendance);
			if(!Objects.isNull(a))
				flag = Boolean.TRUE;
			logger.debug("Attendance ID = " + id + " is updated in to database :: " + oldAttendance);
			return flag;
		} else {
			logger.error("Attendance is not available in to database with ID= " + id);
			return flag;
		}
	}

	public static Map<String, Object> mapData(Page<Attendance> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<AttendanceDTO> attendenceModels = pagedResult.stream().map(entity -> { 
			AttendanceDTO model =	new AttendanceDTO(); 
			model.setId(entity.getId());
			model.setCompanyName(entity.getCompanyName());
			model.setBranchName(entity.getBranchName());
			model.setInTime(entity.getInTime());
			model.setOutTime(entity.getOutTime());
			return	model;}).collect(Collectors.toList());
		response.put("data", attendenceModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
	
	@Override
	public List<AttendanceDTO> getCompanyId(Long id) {
		//List<AttendanceDTO> att = new ArrayList<>();
		List<Attendance> a = attRepo.findByCompanyId(id);
		List<AttendanceDTO> models = a.stream().map(entity -> {
			AttendanceDTO model = new AttendanceDTO();
			model.setId(entity.getId());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompany().getName());
			model.setBranchName(entity.getBranch().getName());
			model.setBranchId(entity.getBranchId());
			model.setInTime(entity.getInTime());
			model.setOutTime(entity.getOutTime());
			return model;
		}).collect(Collectors.toList());

		return models;
	}
}


