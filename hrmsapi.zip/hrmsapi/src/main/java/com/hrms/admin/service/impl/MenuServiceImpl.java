package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Menu;
import com.hrms.admin.repository.MenuRepository;
import com.hrms.admin.service.MenuService;

@Service
public class MenuServiceImpl implements MenuService {

	@Autowired
	MenuRepository repo;

	@Override
	public List<Map<String, Object>> getByMenu(Long menuId) {
		Menu menus = repo.findByMenuId(menuId);
		List<Map<String, Object>> list = new ArrayList<>();

		Map<String, Object> obj = new HashMap<>();
		obj.put("menuTitle", menus.getMenuTitle());
		obj.put("menuIcon", menus.getMenuIcon());
		obj.put("menuPath", menus.getMenuPath());
		List<Menu> childMenus = repo.findAll();
		List<Map<String, Object>> childs = new ArrayList<>();
		for (Menu childMenu : childMenus) {

			Map<String, Object> child = new HashMap<>();
			if (menus.getMenuId() == childMenu.getParentId() && menus.getMenuId() != 0) {
				child.put("menuTitle", childMenu.getMenuTitle());
				child.put("menuIcon", childMenu.getMenuIcon());
				child.put("menuPath", childMenu.getMenuPath());
				childs.add(child);
			}
		}
		obj.put("childs", childs);
		list.add(obj);
		return list;
	}
}
