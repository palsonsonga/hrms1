package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Holiday;

public interface HolidayRepository extends JpaRepository<Holiday, Long> {

	//public Holiday findByname(String name);
	
	Page<Holiday> findAll(Pageable paging);	
	
	@Query(value = "SELECT a FROM Holiday a WHERE  a.name LIKE %?1%")
	Page<Holiday> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Holiday> findByName(String name);
}