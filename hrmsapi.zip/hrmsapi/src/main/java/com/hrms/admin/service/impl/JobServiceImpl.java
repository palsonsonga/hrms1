package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.JobDTO;
import com.hrms.admin.entity.Job;
import com.hrms.admin.repository.Jobrepository;
import com.hrms.admin.service.JobService;


@Service
public class JobServiceImpl implements JobService {

	private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

	@Autowired
	Jobrepository jobrepository;

	@Override
	public boolean save(JobDTO model) {

		boolean flag = Boolean.FALSE;
		Job entity = new Job();
		/*
		 * Optional<Job> findByJobName = jobrepository.findByname(model.getName());
		 * if(findByJobName.isPresent()) { Job jobName = findByJobName.get();
		 * if(jobName.getName()==model.getName()); flag = Boolean.FALSE; return flag; }
		 */
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setExperiance(model.getExperiance());
		 entity.setCompanyId(model.getCompanyId());
		 entity.setBranchId(model.getBranchId());
		Job j =jobrepository.save(entity);
		if(!Objects.isNull(j)) 
			flag = Boolean.TRUE;
		logger.debug("Job Added into database :: " + entity);
		return flag;	
	}


	@Override
	public Map<String, Object> getAllJob(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {

		Pageable paging = null;

		Page<Job> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			// Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = jobrepository.findAllSearchWithPagination(searchKey, paging);

		} else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = jobrepository.findAllSearchWithPagination(searchKey, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
	
	@Override
	public JobDTO getById(Long id) {
	Optional<Job> optionalEntity = jobrepository.findById(id);
	Job entity = optionalEntity.get();
	JobDTO model = new JobDTO();
	model.setId(entity.getId());
	model.setName(entity.getName());
	model.setDescription(entity.getDescription());
	model.setExperiance(entity.getExperiance());
	model.setCompanyId(entity.getCompanyId());
	model.setBranchId(entity.getBranchId());
	model.setCompanyName(entity.getCompany().getName());
	model.setBranchName(entity.getBranch().getName());
	logger.debug("Job found with ID = " + id + " " + entity);
	return model;

		}



	@Override
	public boolean deleteJob(Long id) {
		jobrepository.deleteById(id);
		logger.debug(" Job record is deleted from database ");
		return true;		
	}

	public boolean updateJob(JobDTO model, Long id) {

		boolean flag = Boolean.FALSE;
		/*
		 * Optional<Job> findByJobName = jobrepository.findByname(model.getName());
		 * if(findByJobName.isPresent()) { Job jobName = findByJobName.get();
		 * if(jobName.getName()==model.getName()); flag = Boolean.FALSE; return flag; }
		 */
		Optional<Job> findById = jobrepository.findById(id);
		if (findById.isPresent()) {
			Job oldJob = findById.get();
			oldJob.setName(model.getName());
			oldJob.setDescription(model.getDescription());
			oldJob.setExperiance(model.getExperiance());
			oldJob.setCompanyId(model.getCompanyId());
			oldJob.setBranchId(model.getBranchId());  
			Job j =jobrepository.save(oldJob);
			if(!Objects.isNull(j))
				flag = Boolean.TRUE;
			logger.debug("Job ID = " + id + " is updated in to database :: " + oldJob);
			return flag;
		} else {
			logger.error("Job is not available in to database with ID= " + id);
			return flag;
		}
	}
	//paging
	public static Map<String, Object> mapData(Page<Job> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<JobDTO> jobModels = pagedResult.stream().map(entity -> { 
			JobDTO model =	new JobDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			model.setExperiance(entity.getExperiance());
			return	model;}).collect(Collectors.toList());

		response.put("data", jobModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
}














