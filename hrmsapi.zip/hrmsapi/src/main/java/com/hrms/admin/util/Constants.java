package com.hrms.admin.util;

public class Constants {

	public static String INSERT_SUCCESS ="inserted succesfully";
	public static String UPDATE_SUCCESS ="updated succesfully";
	public static String DELETE_SUCCESS ="deleted succesfully";
	public static String DEACTIVE_SUCCESS ="deactive succesfully";
	public static String APPROVE_SUCCESS ="approve succesfully";
	public static String INSERT_FAIL ="failed to add";
	public static String UPDATE_FAIL ="failed to update";
	public static String DELETE_FAIL ="failed to delete";
	public static String DEACTIVE_FAIL ="failed to deactive";
	public static String APPROVE_FAIL ="failed to approve";
	public static String GET_FAIL ="failed to get details";
	public static boolean TRUE =true;
	public static boolean FALSE =false;
	
	public static String POST ="POST";
	public static String PUT ="PUT";
	public static String DELETE ="DELETE";
	public static String POST_INTERNAL_SERVER_ERROR ="POST_INTERNAL_SERVER_ERROR";
	public static String PUT_NOT_FOUND ="PUT_NOT_FOUND";
	public static String PUT_BAD_REQUEST ="PUT_BAD_REQUEST";
	public static String DELETE_NO_CONTENT ="DELETE_FAIL";
	public static String NOT_FOUND ="RECORD_NOT_FOUND";
	
	public static String ALREADY_EXIST ="record is already exist";

	
	
	
	
	
	
}
