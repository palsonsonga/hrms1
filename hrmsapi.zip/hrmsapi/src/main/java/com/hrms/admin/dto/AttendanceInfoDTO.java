package com.hrms.admin.dto;

public class AttendanceInfoDTO {

	private Long id;
	private Long empId;
	private String companyName;
	private String branch;
	private String inTime;
	private String outTime;
	private String date;
	private String reason;
	private Long noOfHrs;
	private String empName;

	public AttendanceInfoDTO() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmpId() {
		return empId;
	}

	public void setEmpId(Long empId) {
		this.empId = empId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getInTime() {
		return inTime;
	}

	public void setInTime(String inTime) {
		this.inTime = inTime;
	}

	public String getOutTime() {
		return outTime;
	}

	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Long getNoOfHrs() {
		return noOfHrs;
	}

	public void setNoOfHrs(Long noOfHrs) {
		this.noOfHrs = noOfHrs;
	}

	public AttendanceInfoDTO(Long id, Long empId, String companyName, String branch, String inTime, String outTime,
			String date, String reason, Long noOfHrs, String empName) {
		super();
		this.id = id;
		this.empId = empId;
		this.companyName = companyName;
		this.branch = branch;
		this.inTime = inTime;
		this.outTime = outTime;
		this.date = date;
		this.reason = reason;
		this.noOfHrs = noOfHrs;
		this.empName = empName;
	}


}
