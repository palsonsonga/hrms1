package com.hrms.admin.dto;

import java.util.List;

public class ProjectDTO {

	private Long id;
	private String name;
	private String description;
	private List<EmployeeDTO> employeeDtoList;
	private Long companyId;
	private String companyName;
	
	public ProjectDTO() {

	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public List<EmployeeDTO> getEmployeeDtoList() {
		return employeeDtoList;
	}

	public void setEmployeeDtoList(List<EmployeeDTO> employeeDtoList) {
		this.employeeDtoList = employeeDtoList;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	

}
