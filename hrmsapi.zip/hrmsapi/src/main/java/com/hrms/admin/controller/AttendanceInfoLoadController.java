package com.hrms.admin.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.repository.JobExecutionAlreadyRunningException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.supercsv.io.CsvBeanWriter;
import org.supercsv.io.ICsvBeanWriter;
import org.supercsv.prefs.CsvPreference;

import com.hrms.admin.dto.AttPercentageBarChartDTO;
import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.dto.Response;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.fileuploaddownload.property.ExcelGenerator;
import com.hrms.admin.fileuploaddownload.property.PdfReportGenerator;
import com.hrms.admin.response.ApiResponse;
import com.hrms.admin.service.AttendanceInfoService;
import com.hrms.admin.util.Constants;

@RestController
@RequestMapping("/admin/attendanceinfo")
@CrossOrigin
public class AttendanceInfoLoadController {

	@Autowired
	AttendanceInfoService attendanceservice;
	@Autowired
	JobLauncher jobLauncher;
	@Autowired
	Job job;

	//@GetMapping
	public BatchStatus load() throws JobParametersInvalidException, JobExecutionAlreadyRunningException,
	JobRestartException, JobInstanceAlreadyCompleteException {

		Map<String, JobParameter> maps = new HashMap<>();

		JobParameters parameters = new JobParameters(maps);
		JobExecution jobExecution = jobLauncher.run(job, parameters);

		System.out.println("JobExecution: " + jobExecution.getStatus());

		//System.out.println("Batch is Running...");
		while (jobExecution.isRunning()) {
			System.out.println("...");
		}

		return jobExecution.getStatus();
	}

	@PostMapping("/save")
	public ResponseEntity<Response> addEmployeeDetails(@RequestBody AttendanceInfo model) {
		try {
			attendanceservice.save(model);

			return new ResponseEntity<Response>(
					new Response("Employee " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} catch (Exception e) {

			return new ResponseEntity<Response>(
					new Response("Employee " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@GetMapping("/day/{empid}")
	public ApiResponse getAttendanceDayBaseById(@PathVariable Long empid, @RequestParam String dateString) {

		System.out.println("Teat..." + empid);

		try {
			Long percentage = attendanceservice.getAttendancePercentageDayBase(empid, dateString);
			return new ApiResponse(HttpStatus.OK.value(), "Employee Attendance percentage per day: " + percentage,
					percentage);
		} catch (Exception e) {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee Details not available for employee id ",
					null);
		}

	}

	@GetMapping("/date/{empid}")
	public ApiResponse getAttandanceBetweenDaysById(@PathVariable Long empid, @RequestParam String fromDate,
			@RequestParam String toDate) throws ParseException {

		try {
			Long percentage = attendanceservice.getAttendancePercentageDateBase(empid, fromDate, toDate);
			return new ApiResponse(HttpStatus.OK.value(), "Total number of working hours : " + percentage, percentage);
		} catch (Exception e) {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee Details not available ", null);
		}

	}

	@GetMapping("/day")
	public ApiResponse getAllAttendanceDateBase(@RequestParam String dateString) throws ParseException {

		try {
			Long percentage = attendanceservice.getAllEmpAttendancePercentageDayBase(dateString);

			return new ApiResponse(HttpStatus.OK.value(), "All Employee Attendance percentage per day: " + percentage,
					percentage);
		} catch (Exception e) {

			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee Details not available for perticular Day ",
					null);
		}
	}

	@GetMapping("/date")
	public ApiResponse getAllAttendanceBetweenTwoDates(@RequestParam String fromDate, @RequestParam String toDate)
			throws ParseException {

		try {
			Long percentage = attendanceservice.getAllAttendancePercentageDateBase(fromDate, toDate);
			return new ApiResponse(HttpStatus.OK.value(),
					"All Employee Attendance percentage per Date base: " + percentage, percentage);
		} catch (Exception e) {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(),
					"Employee Details not available in between these Dates", null);
		}
	}

	@GetMapping("/getAllEmp")
	public ApiResponse getAllEmployeesDetails() {
		List<AttendanceInfo> attensList = attendanceservice.getAllAttendancePercentage();
		if (attensList != null) {

			return new ApiResponse(HttpStatus.OK.value(), "Found all Employee Attendance percentages " + attensList,
					attensList);
		} else {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee Attendance not available", null);
		}
	}


	@GetMapping("/presentEmp")
	public ApiResponse getAllPresentEmployeesList() {
		List<AttendanceInfo> attensList = attendanceservice.getAllPresentEmployeeList();
		if (attensList != null) {

			return new ApiResponse(HttpStatus.OK.value(), "Found all Present Employee List" + attensList, attensList);
		} else {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee List not available", null);
		}
	}

	@GetMapping("/download/presentEmpExcelreport")
	public ResponseEntity<InputStreamResource> excelReportAllPresentAttendances() throws IOException {
		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllPresentEmployeeList();

		ByteArrayInputStream in = ExcelGenerator.attendanceInfoToExcel(allAttendenceDetails);
		// return IOUtils.toByteArray(in);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=EmpAttendance.xlsx");

		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(value = "/download/presentEmpPdfreport",produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportPresentAttendances() {

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllPresentEmployeeList();

		ByteArrayInputStream bis =PdfReportGenerator.attendanceReport(allAttendenceDetails);

		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
		String currentDate = formatter.format(date);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=EmpAttendance _" + currentDate + ".pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}

	@GetMapping("/download/presentEmpcsvreport")
	public void csvReportPresentAttendances(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllPresentEmployeeList();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = {"ID","EMPID","EMPNAME","BRANCH", "COMPANYNAME", "INTIME","OUTTIME","DATE","NOOFHOURS","RESASON","AttendsPercentage"};
		String[] nameMapping = {"id", "empId","empName", "branch","companyName", "inTime", "outTime","date","noOfHrs","reason","attndsPercentage"};

		csvWriter.writeHeader(csvHeader);

		for (AttendanceInfo att : allAttendenceDetails) {
			csvWriter.write(att, nameMapping);
		}

		csvWriter.close();

	}

	@GetMapping("/AbsentEmp")
	public ApiResponse getAllAbsentEmployeesList() {
		List<AttendanceInfo> absentList = attendanceservice.getAllAbsentEmployeeList();
		if (absentList != null) {
			return new ApiResponse(HttpStatus.OK.value(), "Found all Absent Employee List" + absentList, absentList);
		} else {
			return new ApiResponse(HttpStatus.NOT_FOUND.value(), "Employee List not available", null);
		}
	}


	@GetMapping("/download/AbsentEmpexcelreport")
	public ResponseEntity<InputStreamResource> excelReportAllAbsentAttendances() throws IOException {
		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAbsentEmployeeList();

		ByteArrayInputStream in = ExcelGenerator.attendanceInfoToExcel(allAttendenceDetails);
		// return IOUtils.toByteArray(in);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=EmpAttendance.xlsx");

		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(value = "/download/AbsentEmppdfreport",produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAbsentAttendances() {

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAbsentEmployeeList();

		ByteArrayInputStream bis =PdfReportGenerator.attendanceReport(allAttendenceDetails);

		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
		String currentDate = formatter.format(date);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=EmpAttendance _" + currentDate + ".pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}

	@GetMapping("/download/Absentcsvreport")
	public void csvReportAbsentAttendances(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAbsentEmployeeList();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = {"ID","EMPID","EMPNAME","BRANCH", "COMPANYNAME", "INTIME","OUTTIME","DATE","NOOFHOURS","RESASON","AttendsPercentage"};
		String[] nameMapping = {"id", "empId","empName", "branch","companyName", "inTime", "outTime","date","noOfHrs","reason","attndsPercentage"};

		csvWriter.writeHeader(csvHeader);

		for (AttendanceInfo att : allAttendenceDetails) {
			csvWriter.write(att, nameMapping);
		}

		csvWriter.close();

	}
	/**Download attendance*/

	@GetMapping("/download/excelreport")
	public ResponseEntity<InputStreamResource> excelReportAllAttendances() throws IOException {
		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAttendenceDetails();

		ByteArrayInputStream in = ExcelGenerator.attendanceInfoToExcel(allAttendenceDetails);
		// return IOUtils.toByteArray(in);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=Attendance.xlsx");

		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping("/download/excelreport/{empid}")
	public ResponseEntity<InputStreamResource> excelReportAttendancesByEmpId(@PathVariable Long empid) throws IOException {
		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAttendenceByEmpId(empid);

		ByteArrayInputStream in = ExcelGenerator.attendanceInfoToExcel(allAttendenceDetails);
		// return IOUtils.toByteArray(in);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment; filename=Attendance.xlsx");

		return ResponseEntity.ok().headers(headers).body(new InputStreamResource(in));
	}

	@GetMapping(value = "/download/pdfreport",produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAttendances() {

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAttendenceDetails();

		ByteArrayInputStream bis =PdfReportGenerator.attendanceReport(allAttendenceDetails);

		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
		String currentDate = formatter.format(date);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=Attendance _" + currentDate + ".pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}

	@GetMapping(value = "/download/pdfreport/{empid}",produces = MediaType.APPLICATION_PDF_VALUE)
	public ResponseEntity<InputStreamResource> pdfReportAttendancesById(@PathVariable Long empid) {

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAttendenceByEmpId(empid);

		ByteArrayInputStream bis =PdfReportGenerator.attendanceReport(allAttendenceDetails);

		Date date = new Date();  
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy"); 
		String currentDate = formatter.format(date);

		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=Attendance _" + currentDate + ".pdf");

		return ResponseEntity.ok().headers(headers).contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}

	@GetMapping("/download/csvreport")
	public void csvReportAttendances(HttpServletResponse response) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		List<AttendanceInfo> allAttendenceDetails = attendanceservice.getAllAttendenceDetails();

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = {"EMPID", "COMPANYNAME", "BRANCH", "INTIME","OUTTIME","DATE","NOOFHOURS","RESASON"};
		String[] nameMapping = {"id", "empId", "branch", "inTime", "outTime","date","noOfHrs","reason"};

		csvWriter.writeHeader(csvHeader);

		for (AttendanceInfo att : allAttendenceDetails) {
			csvWriter.write(att, nameMapping);
		}

		csvWriter.close();

	}

	@GetMapping("/download/csvreport/{empid}")
	public void csvReportAttendancesById(HttpServletResponse response,@PathVariable Long empid) throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH-mm-ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=users_" + currentDateTime + ".csv";
		response.setHeader(headerKey, headerValue);

		List<AttendanceInfo> allAttendenceDetails =attendanceservice.getAllAttendenceByEmpId(empid);

		ICsvBeanWriter csvWriter = new CsvBeanWriter(response.getWriter(), CsvPreference.STANDARD_PREFERENCE);
		String[] csvHeader = {"EMPID", "COMPANYNAME", "BRANCH", "INTIME","OUTTIME","DATE","NOOFHOURS","RESASON"};
		String[] nameMapping = {"id", "empId", "branch", "inTime", "outTime","date","noOfHrs","reason"};

		csvWriter.writeHeader(csvHeader);

		for (AttendanceInfo att : allAttendenceDetails) {
			csvWriter.write(att, nameMapping);
		}

		csvWriter.close();
	}

	@GetMapping("/pieChart")
	public AttPercentagePieChartDto AttendancePercentagePieChart() {
		AttPercentagePieChartDto attendancePercentagePieChart = attendanceservice.AttendancePercentagePieChart();
		return attendancePercentagePieChart;	
	}

	@GetMapping("/barChart")
	public AttPercentageBarChartDTO AttendancePercentageBarChart() {

		AttPercentageBarChartDTO attendancePercentageBarChart = attendanceservice.AttendancePercentageBarChart();
		return attendancePercentageBarChart;	

	}

}
