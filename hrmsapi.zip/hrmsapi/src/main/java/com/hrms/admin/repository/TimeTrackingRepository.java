package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.AttendanceInfo;

public interface TimeTrackingRepository extends JpaRepository<AttendanceInfo, Long> {

	@Query("select noOfHrs from AttendanceInfo where empid=:empid and date=:date")
	public Long getWorkingHrsDayBase(Long empid, String date);
	
	//@Query("select sum(noOfHrs) from AttendanceInfo where EMPLOYEE_ID=emp_id and date >=CAST(fromDate AS DATE) AND date <= CAST(toDate AS DATE) group by emp_id")
	 
	@Query("select sum(noOfHrs) from AttendanceInfo where empid=:empid and date >=:fromDate and date <=:toDate group by empid")
	public Long getSumOfWorkingHrs(Long empid, String fromDate, String toDate);

	@Query("select count(empid) from AttendanceInfo where empid=:empid and date >=:fromDate and date <=:toDate group by empid")
	public Long getNoOfDayCount(Long empid, String fromDate, String toDate);

	@Query("select sum(noOfHrs) from AttendanceInfo where date=:date")
	public Long getAllSumOfWrkingHrsDayBase(String date);
	
	@Query("select count(empid) from AttendanceInfo where date=:date")
	public Long getAllNumOfEmpsCount(String date);
	
	@Query("select sum(noOfHrs) from AttendanceInfo where date >=:fromDate and date <=:toDate")
	public Long getAllSumOfWrkingHrsDateBase( String fromDate, String toDate);
	
	@Query("select count(empid) from AttendanceInfo where date >=:fromDate and date <=:toDate")
	public Long getAllNumOfEmpsCount(String fromDate, String toDate);

	public List<AttendanceInfo> findByEmpId(Long empId);
	
	@Query("select count(empid) from AttendanceInfo where DATE_FORMAT(date,'%Y-%m-%d')>= ADDDATE(current_date(), -1) ")
	public Long getAllEmployeecountPerDay();

	@Query("select count(empid) from AttendanceInfo  where attndsPercentage<>0 and noOfHrs<>0 and  DATE_FORMAT(date,'%Y-%m-%d')>= ADDDATE(current_date(), -1)")
	public Long AttendancePresentPercentagePieChart();

	@Query("select count(empid) from AttendanceInfo where attndsPercentage=0 and noOfHrs=0 and  DATE_FORMAT(date,'%Y-%m-%d')>= ADDDATE(current_date(), -1)")
	public Long AttendanceAbsentPercentagePieChart();

	@Query("select count(empid) from AttendanceInfo  where attndsPercentage<>0 and noOfHrs<>0 and DATE_FORMAT(date,'%Y-%m-%d')>=ADDDATE(current_date(), -7)  group by date")
	public List<Long> AttendancePresentCountBarChart();

	@Query("select count(empid) from AttendanceInfo where attndsPercentage=0 and noOfHrs=0 and DATE_FORMAT(date,'%Y-%m-%d')>=ADDDATE(current_date(), -7)  group by date")
	public List<Long> AttendanceAbsentCountBarChart();
}
