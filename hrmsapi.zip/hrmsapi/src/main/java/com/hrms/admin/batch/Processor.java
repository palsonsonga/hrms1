package com.hrms.admin.batch;

import java.util.HashSet;
import java.util.Set;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.util.StringToDateUtility;

@Component
public class Processor implements ItemProcessor<AttendanceInfo, AttendanceInfo> {

	@Autowired
	private StringToDateUtility util;

	private Set<AttendanceInfo> seenAttendance = new HashSet<AttendanceInfo>();
	@Override
	public AttendanceInfo process(AttendanceInfo item) throws Exception {
		System.out.println("========================="+seenAttendance.size());
		item.getEmpId();
		item.getCompanyName();
		item.getBranch();
		item.getInTime();
		item.getInTime(); 
		item.getDate(); 
		System.out.println(String.format("Converted from [%s] ", item));
		item.setNoOfHrs(util.calculateWorkingHours(item.getInTime(), item.getOutTime()));
		return item;
	}

	
	
}
