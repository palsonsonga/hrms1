package com.hrms.admin.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.context.annotation.Configuration;

@Configuration
public class StringToDateUtility {

	public static Date convertToDate(String stringDate) throws ParseException { 
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		System.out.println(simpleDateFormat.parse(stringDate));
		return  simpleDateFormat.parse(stringDate);
	}		

	public Long calculateWorkingHours(String inTime, String outTime) {

		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Long hours = 0l;
		try {

			Date inTimeDate = sdf1.parse(inTime);
			Date outTimeDate = sdf2.parse(outTime);
			Long diffTime = outTimeDate.getTime() - inTimeDate.getTime();
			hours = (diffTime / (1000 * 60 * 60)) % 24;

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return hours;
	}
	public Long attendsPersentage(String inTime, String outTime, Long noOfHrs) {

		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Long percentage = 0l;
		try {

			Date inTimeDate = sdf1.parse(inTime);
			Date outTimeDate = sdf2.parse(outTime);
			Long diffTime = outTimeDate.getTime() - inTimeDate.getTime();
			Long actualHrs = (diffTime / (1000 * 60 * 60)) % 24;
			percentage = noOfHrs * 100 / actualHrs;

		} catch (ParseException e) {
			e.printStackTrace();
		}
		return percentage;
	}
}
