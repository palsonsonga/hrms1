package com.hrms.admin.dto;

import java.util.List;

public class EmployeeResourceDTO {

	private Long employeeId;
	private String ipAddress;
	private Long port;
	private List<ResourceItemsDTO> items;
	public Long getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}
	public String getIpAddress() {
		return ipAddress;
	}
	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}
	public Long getPort() {
		return port;
	}
	public void setPort(Long port) {
		this.port = port;
	}
	public List<ResourceItemsDTO> getItems() {
		return items;
	}
	public void setItems(List<ResourceItemsDTO> items) {
		this.items = items;
	}

	

}
