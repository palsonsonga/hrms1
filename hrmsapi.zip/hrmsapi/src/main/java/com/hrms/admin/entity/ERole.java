package com.hrms.admin.entity;

public enum ERole {

	ROLE_ADMIN,
	ROLE_CEO,
    ROLE_MANAGER,
    ROLE_BRANCH_MANAGER,
    ROLE_HR,
    ROLE_EMPLOYEE
}
