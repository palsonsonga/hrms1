package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Attendance;

public interface AttendancesRepository extends JpaRepository<Attendance, Long> {
	
	Page<Attendance> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Attendance a WHERE  a.companyName LIKE %?1%     OR a.branchName LIKE %?1%")
	Page<Attendance> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Attendance> findByCompany(String company);
	public Optional<Attendance> findByBranch(String branch);
	public List<Attendance>  findByCompanyId(Long companyId);
}
