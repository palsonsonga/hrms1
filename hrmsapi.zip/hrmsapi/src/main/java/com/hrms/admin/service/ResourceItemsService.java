package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.ResourceItems;

public interface ResourceItemsService {

	public ResourceItems save(ResourceItemsDTO model);

	public List<ResourceItemsDTO> getAll();

	public ResourceItemsDTO getById(Long id);

	public ResourceItemsDTO getByName(String name);

	public boolean delete(Long id);

	public boolean update(ResourceItemsDTO model, Long id);
}
