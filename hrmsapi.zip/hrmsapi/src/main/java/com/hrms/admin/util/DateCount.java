package com.hrms.admin.util;

import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.springframework.context.annotation.Configuration;

@Configuration
public class DateCount {

	public Long daysCount(Date start_date, Date end_date) {
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH);

		long diffInMillies = Math.abs(end_date.getTime() - start_date.getTime());
		long diff = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS) + 1;

		return (Long) diff;

	}
}
