package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice
@RestController
public class HolidayCustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

	

	  @ExceptionHandler(Exception.class)
	  public final ResponseEntity<HolidayExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
		  HolidayExceptionResponse holidayExceptionResponse = new HolidayExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(holidayExceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	  }

	  @ExceptionHandler(HolidayNotFoundExceptions.class)
	  public final ResponseEntity<HolidayExceptionResponse> handleholidayNotFoundException(HolidayNotFoundExceptions ex, WebRequest request) {
	    HolidayExceptionResponse holidayExceptionResponse = new HolidayExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(holidayExceptionResponse, HttpStatus.NOT_FOUND);
	  }


	  @ExceptionHandler(HolidayNotCreatedExceptions.class)
	  public final ResponseEntity<HolidayExceptionResponse> handleDepartmentNotCreatedException(HolidayNotCreatedExceptions ex, WebRequest request) {
	    HolidayExceptionResponse holidayExceptionResponse = new HolidayExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(holidayExceptionResponse, HttpStatus.BAD_REQUEST);
	  }
}
