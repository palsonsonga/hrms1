package com.hrms.admin.util;

import com.hrms.admin.dto.DesignationDTO;

public class DesignationsUtil {

	public static void copyNonNullValues(DesignationDTO req, DesignationDTO db) {

		if (req.getDesignation() != null) {
			db.setDesignation(req.getDesignation());
		}
		if (req.getSkills() != null) {
			db.setSkills(req.getSkills());
		}
		

	}
}
