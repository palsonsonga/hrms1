
package com.hrms.admin.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EmployeeDTO {
	
		private Long id;
		private String firstName;
		private String lastName;
		private String email;
		private String userName;
		private Date dateOfBirth;
		private String gender;
		private String maritalStatus;
		private String contactNo;
		private String alternateContactNo;
		private String aadharCard;
		private String panCard;
		private String voterID;
		private Date joiningDate;
		private String bloodGroup;
		
		private Long departmentId;
		private String departmentName;
		
		private Long designationId;
		private String designationName;
		
		private Long companyId;
		private String companyName;
		private Long branchId;
		private String branchName;
		
		private Boolean isActive;
		private Boolean isApprove;

		private String folderName;
		
		private BankDTO bankDetail;
		
		private Map<String,Object> addresses = new HashMap<>(); 
		private Map<String,Object> academicDetails = new HashMap<>(); 
		private List<FileDTO> files=new ArrayList<>();
		
		private List<ProjectDTO> projects;
		private List<PolicyDTO> policies;
		private ProfileImageDTO profileiamge;
		
		private String ipAddress;
		private String port;
		private List<ResourceItemsDTO> resourceItems;
		private List<ProfessionalDetailsDTO> professionalDetails;
		
		public Map<String, Object> getAcademicDetails() {
			return academicDetails;
		}
		public void setAcademicDetails(Map<String, Object> academicDetails) {
			this.academicDetails = academicDetails;
		}
		public List<ProfessionalDetailsDTO> getProfessionalDetails() {
			return professionalDetails;
		}
		public void setProfessionalDetails(List<ProfessionalDetailsDTO> professionalDetails) {
			this.professionalDetails = professionalDetails;
		}
		public ProfileImageDTO getProfileiamge() {
			return profileiamge;
		}
		public void setProfileiamge(ProfileImageDTO profileiamge) {
			this.profileiamge = profileiamge;
		}
		public List<PolicyDTO> getPolicies() {
			return policies;
		}
		public void setPolicies(List<PolicyDTO> policies) {
			this.policies = policies;
		}
		public List<ProjectDTO> getProjects() {
			return projects;
		}
		
	
		public String getIpAddress() {
			return ipAddress;
		}
		public void setIpAddress(String ipAddress) {
			this.ipAddress = ipAddress;
		}
		public String getPort() {
			return port;
		}
		public void setPort(String port) {
			this.port = port;
		}
		public List<ResourceItemsDTO> getResourceItems() {
			return resourceItems;
		}
		public void setResourceItems(List<ResourceItemsDTO> resourceItems) {
			this.resourceItems = resourceItems;
		}
		public void setProjects(List<ProjectDTO> projects) {
			this.projects = projects;
		}
		public BankDTO getBankDetail() {
			return bankDetail;
		}
		public String getFolderName() {
			return folderName;
		}
		public void setFolderName(String folderName) {
			this.folderName = folderName;
		}
		public Boolean getIsActive() {
			return isActive;
		}
		public void setIsActive(Boolean isActive) {
			this.isActive = isActive;
		}
		public Boolean getIsApprove() {
			return isApprove;
		}
		public void setIsApprove(Boolean isApprove) {
			this.isApprove = isApprove;
		}
		public void setBankDetail(BankDTO bankDetail) {
			this.bankDetail = bankDetail;
		}
		public String getCompanyName() {
			return companyName;
		}
		public void setCompanyName(String companyName) {
			this.companyName = companyName;
		}
		
		public String getBranchName() {
			return branchName;
		}
		public void setBranchName(String branchName) {
			this.branchName = branchName;
		}
		public String getDepartmentName() {
			return departmentName;
		}
		public void setDepartmentName(String departmentName) {
			this.departmentName = departmentName;
		}
		public String getDesignationName() {
			return designationName;
		}
		public void setDesignationName(String designationName) {
			this.designationName = designationName;
		}
		
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getUserName() {
			return userName;
		}
		public void setUserName(String userName) {
			this.userName = userName;
		}
		public Date getDateOfBirth() {
			return dateOfBirth;
		}
		public void setDateOfBirth(Date dateOfBirth) {
			this.dateOfBirth = dateOfBirth;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getMaritalStatus() {
			return maritalStatus;
		}
		public void setMaritalStatus(String maritalStatus) {
			this.maritalStatus = maritalStatus;
		}
		public String getContactNo() {
			return contactNo;
		}
		public void setContactNo(String contactNo) {
			this.contactNo = contactNo;
		}
		public String getAlternateContactNo() {
			return alternateContactNo;
		}
		public void setAlternateContactNo(String alternateContactNo) {
			this.alternateContactNo = alternateContactNo;
		}
		public String getAadharCard() {
			return aadharCard;
		}
		public void setAadharCard(String aadharCard) {
			this.aadharCard = aadharCard;
		}
		public String getPanCard() {
			return panCard;
		}
		public void setPanCard(String panCard) {
			this.panCard = panCard;
		}
		public String getVoterID() {
			return voterID;
		}
		public void setVoterID(String voterID) {
			this.voterID = voterID;
		}
		public Date getJoiningDate() {
			return joiningDate;
		}
		public void setJoiningDate(Date joiningDate) {
			this.joiningDate = joiningDate;
		}
		public Long getDepartmentId() {
			return departmentId;
		}
		public void setDepartmentId(Long departmentId) {
			this.departmentId = departmentId;
		}
		public Long getDesignationId() {
			return designationId;
		}
		public void setDesignationId(Long designationId) {
			this.designationId = designationId;
		}
		public Long getCompanyId() {
			return companyId;
		}
		public void setCompanyId(Long companyId) {
			this.companyId = companyId;
		}
		public Long getBranchId() {
			return branchId;
		}
		public void setBranchId(Long branchId) {
			this.branchId = branchId;
		}

		/*
		 * public List<AddressDTO> getAddressList() { return addressList; } public void
		 * setAddressList(List<AddressDTO> addressList) { this.addressList =
		 * addressList; }
		 */		public String getBloodGroup() {
			return bloodGroup;
		}
		public void setBloodGroup(String bloodGroup) {
			this.bloodGroup = bloodGroup;
		}
		public List<FileDTO> getFiles() {
			return files;
		}
		public void setFiles(List<FileDTO> files) {
			this.files = files;
		}
		public Map<String, Object> getAddresses() {
			return addresses;
		}
		public void setAddresses(Map<String, Object> addresses) {
			this.addresses = addresses;
		}
		
		
		
		

		
	


}
