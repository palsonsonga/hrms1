package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Address;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
