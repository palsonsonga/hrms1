package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.AttendanceDTO;

public interface AttendanceService {
	
	
	public boolean save(AttendanceDTO model);

	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
	
	public AttendanceDTO getById(Long id);

	public boolean deleteAttendnace(Long id);

	public boolean updateAttendnace(AttendanceDTO model, Long id);
	
	public List<AttendanceDTO> getCompanyId(Long id);
	
}
