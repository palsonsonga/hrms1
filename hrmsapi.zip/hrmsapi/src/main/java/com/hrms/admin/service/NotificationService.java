package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.NotificationDTO;



public interface NotificationService {

	public boolean save(NotificationDTO model);

	public NotificationDTO getById(Long id);

	public NotificationDTO getBySubject(String subject);

	public boolean deleteNotification(Long id);

	public boolean updateNotification(NotificationDTO model, Long id);

	//paging
	
	public Map<String, Object> getAllNotification(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	/**
	 * Returns All Notification data when notification data is available in database
	 * 
	 * @return - List of NotificationModel
	 */
	List<NotificationDTO> getAllNotificationList();

	/**
	 * Returns true when existing notification data is store in database
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - boolean
	 */
}
