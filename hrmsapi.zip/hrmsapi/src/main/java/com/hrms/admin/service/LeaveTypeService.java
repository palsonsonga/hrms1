package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.LeaveTypeDTO;

public interface LeaveTypeService {

	public boolean save(LeaveTypeDTO branch);

	public Map<String, Object> getAllLeaves(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public LeaveTypeDTO getById(Long id);

	public boolean deleteLeave(Long id);

	public boolean updateLeave(LeaveTypeDTO model, Long id);
	
	public List<LeaveTypeDTO> AllLeavesTypes();

}