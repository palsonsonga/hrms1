package com.hrms.admin.service;

import java.util.Map;

import com.hrms.admin.dto.JobDTO;

public interface JobService {
	
	
	public boolean save(JobDTO model);

	public Map<String, Object> getAllJob(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public JobDTO getById(Long id);
	
	public boolean deleteJob(Long id);

	public boolean updateJob(JobDTO model, Long id);
	
}
