package com.hrms.admin.dto;

import java.util.Date;

public class NotificationDTO {
	private Long id;
	private String subject;
	private String description;
	private Date eventDate;
	private String toMail;
	private Long companyId;
    private String companyName;
    private String fromMail;

	public NotificationDTO() {

	}

	

	public NotificationDTO(Long id, String subject, String description, Date eventDate, String toMail, Long companyId,
			String companyName, String fromMail) {
		super();
		this.id = id;
		this.subject = subject;
		this.description = description;
		this.eventDate = eventDate;
		this.toMail = toMail;
		this.companyId = companyId;
		this.companyName = companyName;
		this.fromMail = fromMail;
	}



	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getEventDate() {
		return eventDate;
	}

	public void setEventDate(Date eventDate) {
		this.eventDate = eventDate;
	}

	public String getToMail() {
		return toMail;
	}

	public void setToMail(String toMail) {
		this.toMail = toMail;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}



	public String getFromMail() {
		return fromMail;
	}



	public void setFromMail(String fromMail) {
		this.fromMail = fromMail;
	}
	

	
}
