package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AssetsDTO;
import com.hrms.admin.entity.Assets;
import com.hrms.admin.repository.AssetsRepository;
import com.hrms.admin.service.AssetsService;

@Service
public class AssetsServiceImpl implements AssetsService {
	private static final Logger logger = LoggerFactory.getLogger(AssetsServiceImpl.class);

	@Autowired
	private AssetsRepository repo;

	@Override
	public boolean save(AssetsDTO model) {
		boolean flag = Boolean.FALSE;
		Assets entity = new Assets();
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setCompanyId(model.getCompanyId()); 
		Assets d = repo.save(entity);
		if (!Objects.isNull(d))
			flag = Boolean.TRUE;
		logger.debug("Assets Added into database :: " + entity);
		return flag;
	}

	@Override
	public AssetsDTO getById(Long id) {
		Optional<Assets> optionalEntity = repo.findById(id);
		Assets entity = optionalEntity.get();
		AssetsDTO model = new AssetsDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompanyId());
		model.setCompanyName(entity.getCompany().getName());
		logger.debug("Assets found with ID = " + id + " " + entity);
		return model;
	}

	@Override
	public AssetsDTO getByName(String name) {
		Assets entity = repo.findByname(name);
		AssetsDTO model = new AssetsDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompanyId());
		model.setCompanyName(entity.getCompany().getName());
		logger.debug("Assets found with Name = " + name + " " + entity);
		return model;
	}

	@Override
	public boolean deleteAssets(Long id) {
		repo.deleteById(id);
		logger.debug(" Assets record is deleted from database ");
		return true;
	}

	@Override
	public boolean updateAssets(AssetsDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Assets> findById = repo.findById(id);
		if (findById.isPresent()) {
			Assets oldAssets = findById.get();
			oldAssets.setName(model.getName());
			oldAssets.setDescription(model.getDescription());
			oldAssets.setCompanyId(model.getCompanyId()); 
			Assets d = repo.save(oldAssets);
			if (!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Assets ID = " + id + " is updated in to database :: " + oldAssets);
			return flag;
		} else {
			logger.error("Assets is not available in to database with ID= " + id);
			return flag;
		}
	}

	@Override
	public List<AssetsDTO> AllAssets() {
		List<Assets> AllAsset = repo.findAll();
		List<AssetsDTO> models = AllAsset.stream().map(entity -> {
			AssetsDTO model = new AssetsDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompany().getName());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

}
