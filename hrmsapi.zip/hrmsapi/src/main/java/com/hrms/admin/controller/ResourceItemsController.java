package com.hrms.admin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.exceptions.ItemsNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.ResourceItemsService;
import com.hrms.admin.util.Constants;

@RestController
@RequestMapping("/onboard/ResourceItems")
@CrossOrigin
public class ResourceItemsController {

	@Autowired
	private ResourceItemsService itemsService;

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody ResourceItemsDTO model) {
		try {
			itemsService.save(model);
			return new ResponseEntity<Response>(
					new Response("ResourceItems " + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);
		} catch (Exception e) {
			return new ResponseEntity<Response>(
					new Response("ResourceItems " + " " + Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.CREATED);
		}
	}

	@GetMapping
	public ResponseEntity<List<ResourceItemsDTO>> getAll() {

		List<ResourceItemsDTO> allItems = itemsService.getAll();
		if (allItems != null) {
			return new ResponseEntity<List<ResourceItemsDTO>>(allItems, HttpStatus.ACCEPTED);
		}
		throw new ItemsNotFoundException("ResourcesItems Not Found");

	}

	@GetMapping("/{id}")
	public ResponseEntity<ResourceItemsDTO> getById(@PathVariable Long id) {
		try {
			ResourceItemsDTO findById = itemsService.getById(id);
			return new ResponseEntity<ResourceItemsDTO>(findById, HttpStatus.OK);

		} catch (Exception e) {
			throw new ItemsNotFoundException("ResourcesItems Not Found");
		}

	}

	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody ResourceItemsDTO model, @PathVariable Long id) {
		return null;
		/*
		 * boolean updateIteam = itemsService.update(model, id); if (updateIteam) {
		 * return new ResponseEntity<Response>(new Response("Items " + " " +
		 * Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
		 * 
		 * } else { return new ResponseEntity<Response>( new Response(model.getType() +
		 * " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND); }
		 */
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteResourcesItem(@PathVariable Long id) {
		return null;
		/*
		 * ResourceItemsDTO items = itemsService.getById(id); if
		 * (!Objects.isNull(items)) { itemsService.delete(id); return new
		 * ResponseEntity<Response>( new Response(items.getType() + " " +
		 * Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK); } else { return
		 * new ResponseEntity<Response>(new Response("Items " + " " +
		 * Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT); }
		 */
	}
}
