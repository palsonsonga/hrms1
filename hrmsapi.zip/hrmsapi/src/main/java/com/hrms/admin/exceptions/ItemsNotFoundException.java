package com.hrms.admin.exceptions;

public class ItemsNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public ItemsNotFoundException(String message) {
		super(message);
	}
}
