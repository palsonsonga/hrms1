package com.hrms.admin.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AttPercentagePieChartDto {

	@JsonProperty("data")
	private List<AtteDataPieChartDTO> data = null;
	
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public List<AtteDataPieChartDTO> getData() {
		return data;
	}

	public void setData(List<AtteDataPieChartDTO> data) {
		this.data = data;
	}

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}
	

}
