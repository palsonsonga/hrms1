package com.hrms.admin.exceptions;

public class PolicyNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PolicyNotFoundException(String exception) {
		super(exception);
	}
}
