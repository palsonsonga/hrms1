package com.hrms.admin.exceptions;

public class LeaveTypeNotFoundException extends RuntimeException{
	
	public LeaveTypeNotFoundException() {
		super();
	}
		public LeaveTypeNotFoundException(String message) {
			super(message);

		}
}
	
	


