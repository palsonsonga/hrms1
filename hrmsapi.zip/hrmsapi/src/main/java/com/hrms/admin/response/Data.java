package com.hrms.admin.response;

public class Data {
	private Long successCount;
	private Long failureCount;
	
	
	public Data() {
		super();
	}

	public Data(Long successCount, Long failureCount, String attachmentLInk) {
		super();
		this.successCount = successCount;
		this.failureCount = failureCount;
	}

	public Long getSuccessCount() {
		return successCount;
	}

	public void setSuccessCount(Long successCount) {
		this.successCount = successCount;
	}

	public Long getFailureCount() {
		return failureCount;
	}

	public void setFailureCount(Long failureCount) {
		this.failureCount = failureCount;
	}

}
