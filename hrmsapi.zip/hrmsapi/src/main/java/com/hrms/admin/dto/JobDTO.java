package com.hrms.admin.dto;

public class JobDTO {

	private Long id;
	private String name;
	private String description;
	private String experiance;
	private Long companyId;

	private String companyName;

	private Long branchId;

	private String branchName;

	public JobDTO(String experiance) {
		super();
		this.experiance = experiance;
	}

	public JobDTO() {
	}

	public JobDTO(Long id, String name, String description, String experiance) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.experiance = experiance;
	}


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getExperiance() {
		return experiance;
	}

	public void setExperiance(String experiance) {
		this.experiance = experiance;
	}

	public Long getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public Long getBranchId() {
		return branchId;
	}

	public void setBranchId(Long branchId) {
		this.branchId = branchId;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	
}
