package com.hrms.admin.util;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.hrms.admin.entity.ERole;
import com.hrms.admin.entity.Menu;
import com.hrms.admin.entity.Role;
import com.hrms.admin.repository.RoleRepository;

@Component
public class MenusUtility {

	@Autowired
	private RoleRepository roleRepository;

	public Set<Menu> getMenus(List<String> roles){
		
		Set<Role> dbRoles = new HashSet<>();
		Set<Menu> dbMenus = new HashSet<>();
		

		if (roles == null) {
			Role userRole = roleRepository.findByName(ERole.ROLE_EMPLOYEE)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
			dbRoles.add(userRole);
		} else {
			roles.forEach(role -> {
				switch (role) {
				case "ROLE_ADMIN":
					Role adminRole = roleRepository.findByName(ERole.ROLE_ADMIN)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(adminRole);
					break;

				case "ROLE_CEO":
					Role modRole = roleRepository.findByName(ERole.ROLE_CEO)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(modRole);
					break;

				case "ROLE_MANAGER":
					Role managerRole = roleRepository.findByName(ERole.ROLE_MANAGER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(managerRole);
					break;

				case "ROLE_BRANCH_MANAGER":
					Role brmanagerRole = roleRepository.findByName(ERole.ROLE_BRANCH_MANAGER)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(brmanagerRole);
					break;

				case "ROLE_HR":
					Role hrRole = roleRepository.findByName(ERole.ROLE_HR)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(hrRole);
					break;


				default:
					Role userRole = roleRepository.findByName(ERole.ROLE_EMPLOYEE)
					.orElseThrow(() -> new RuntimeException("Error: Role is not found."));
					dbRoles.add(userRole);
				}
			});
		}

		for (Role role : dbRoles) {
			
			dbMenus = role.getMenus();
		}
		
		return dbMenus;
	}
}
