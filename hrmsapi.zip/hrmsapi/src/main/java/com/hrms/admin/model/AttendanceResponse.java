package com.hrms.admin.model;

public class AttendanceResponse {
	private Long id;
	private String companyName;
	private String branch;
	private String inTime;
	private String outTime;
	public AttendanceResponse() {
	}
	public AttendanceResponse(Long id, String companyName, String branch, String inTime, String outTime) {
		
		this.id = id;
		this.companyName = companyName;
		this.branch = branch;
		this.inTime = inTime;
		this.outTime = outTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getInTime() {
		return inTime;
	}
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	@Override
	public String toString() {
		return "AttendanceResponse [id=" + id + ", name=" + companyName + ", branch=" + branch + ", inTime=" + inTime
				+ ", outTime=" + outTime + "]";
	}
	
	
		
	
	
}
