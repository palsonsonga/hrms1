package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.CompanyDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.CompanyNotFoundExceptions;
import com.hrms.admin.service.CompanyService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Company Record
 * 
 * @author {Benarji}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/company")
public class CompanyController {
	private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);

	@Autowired
	private CompanyService service;

	/**
	 * Returns status code when new Company is created
	 * 
	 * @param model - new Company data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody CompanyDTO model) {
		try {
			boolean save=service.save(model);
			if(save==false) {
				return new ResponseEntity<Response>(new Response("Company " + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);

			}else {
				logger.debug("Company Added :: " + model);
				return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);
			} 
		}catch (Exception e) {
			logger.error("Company Already Exist", e.getMessage());
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.BAD_REQUEST);
		}	
	}
	/**
	 * Returns status code when existing Company data is updated
	 * 
	 * @param model - new Company data
	 * @param id    - Company Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody CompanyDTO model, @PathVariable Long id) {
		try{
			boolean updateCompany = service.updateCompany(model, id);
			if (updateCompany == false) {
				return new ResponseEntity<Response>(
						new Response(model.getName() + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			} else {
				logger.debug("Company ID = " + id + " is updated :: " + model);
				return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			}
		}catch( Exception e) {
			logger.error("Error while updating Company :: ");
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Returns Company and status code when Company data is available by id
	 * 
	 * @param id - Company Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<CompanyDTO> getById(@PathVariable Long id) {

		try {
			CompanyDTO CompanyById = service.getById(id);
			logger.debug("Company fond with ID = " + id + " " + CompanyById);
			return new ResponseEntity<CompanyDTO>(CompanyById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Company by Id :: " + id);
			throw new CompanyNotFoundExceptions("Company");
		}
	}

	/**
	 * Returns All Company data when Company data is available
	 * 
	 * @return - List of CompanyModel
	 */

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllAttendnace(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),
				pagingDto.getSearchKey(), pagingDto.getOrderBy());
	}

	/**
	 * Returns status code when Company data is deleted
	 * 
	 * @param id - Company id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			CompanyDTO Company = service.getById(id);
			service.deleteCompany(id);
			logger.debug("Company record is Deleted with id " + id);
			return new ResponseEntity<Response>(new Response(Company.getName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}catch (Exception e) {
			logger.debug("Company not exist ");
			System.out.println(e);
			return new ResponseEntity<Response>(new Response("No value present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	@GetMapping("/list")
	public ResponseEntity<List<CompanyDTO>> companys() {

		List<CompanyDTO> allCompany = service.AllCompany();
		if (allCompany != null) {
			logger.debug("Found " + allCompany.size() + " Company");
			return new ResponseEntity<List<CompanyDTO>>(allCompany,HttpStatus.OK);
		}
		logger.error("error while getting all Company Record");
		throw new CompanyNotFoundExceptions("Company");

	}
}
