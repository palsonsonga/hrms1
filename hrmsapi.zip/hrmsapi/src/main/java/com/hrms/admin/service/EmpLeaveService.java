package com.hrms.admin.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.EmpLeaveDTO;

public interface EmpLeaveService {
	public boolean addEmpLeave(EmpLeaveDTO empLeave);

	public List<EmpLeaveDTO> findLeavesbyDate(Date date);

	public List<EmpLeaveDTO> findLeavesbyEmpId(Long empId);
	
	List<String> findManagerList(Long id);

	public EmpLeaveDTO getEmpLeaveByid(Long id);

	public List<EmpLeaveDTO> getAllEmpLeave();

	public boolean updateEmpLeave(EmpLeaveDTO empLeave, Long id);

	public boolean deleteEmpLeave(Long id);

	public boolean approveOrReject(String approval,Long id);

	public List<EmpLeaveDTO> getEmpLeavesByDate(Long id, Date date1, Date date2);

	public Map<String, Object> getAllEmpLeaves(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public Map<String, Object> getAllTeamLeaves(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
}
