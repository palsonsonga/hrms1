package com.hrms.admin.dto;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class AttPercentageBarChartDTO {

	@JsonProperty("Attendance")
	private List<AtteDataBarChartDTO> attBar = null;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	public List<AtteDataBarChartDTO> getAttBar() {
		return attBar;
	}

	public void setAttBar(List<AtteDataBarChartDTO> attBar) {
		this.attBar = attBar;
	}

	public Map<String, Object> getAdditionalProperties() {
		return additionalProperties;
	}

	public void setAdditionalProperties(Map<String, Object> additionalProperties) {
		this.additionalProperties = additionalProperties;
	}

}
