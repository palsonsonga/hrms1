package com.hrms.admin.exceptions;

public class PolicyInvalidInputException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PolicyInvalidInputException(String exception) {
		super(exception);
	}
}
