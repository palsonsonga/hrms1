package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.ProjectDTO;

public interface ProjectService {
	
	
	public boolean save(ProjectDTO model);
	
	public List<ProjectDTO> getAllProject(); 
	
	public ProjectDTO getById(Long id); 
	
	public ProjectDTO getByName(String name);
	
	public boolean deleteProject(Long id);

//	public List<Project> getAllProjectAccToPaging(Integer pageNo, Integer pageSize, String sortBy); 
//	public Map<String, Object> getAllProject(Integer pageIndex, Integer pageSize, String sortBy);
	
	public boolean updateProject(ProjectDTO model, Long id);  
	
	public ProjectDTO findAllEmployeeByProjId(Long id);
	
	public Map<String, Object> getAllProject(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);
}
