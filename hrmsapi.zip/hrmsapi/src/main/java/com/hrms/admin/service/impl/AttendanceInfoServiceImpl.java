package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AttPercentageBarChartDTO;
import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.dto.AtteDataBarChartDTO;
import com.hrms.admin.dto.AtteDataPieChartDTO;
import com.hrms.admin.entity.Attendance;
import com.hrms.admin.entity.AttendanceInfo;
import com.hrms.admin.repository.AttendancesRepository;
import com.hrms.admin.repository.TimeTrackingRepository;
import com.hrms.admin.service.AttendanceInfoService;
import com.hrms.admin.util.StringToDateUtility;

@Service
public class AttendanceInfoServiceImpl implements AttendanceInfoService {

	private Long actualhrs;
	@Autowired
	private TimeTrackingRepository timeTrackingRepo;

	@Autowired
	private AttendancesRepository attendancesRepository;

	private Attendance att;
	@Autowired
	private StringToDateUtility util;

	@Override
	public Long getAttendancePercentageDayBase(Long empid, String date) {

		Long wrkinghrs = timeTrackingRepo.getWorkingHrsDayBase(empid, date);
		Long actualhrs = util.calculateWorkingHours(att.getInTime(), att.getOutTime());

		Long attandancePercentage = (wrkinghrs * 100) / actualhrs;

		System.out.println("no of hrs: " + wrkinghrs + " - percentage " + attandancePercentage);

		return attandancePercentage;
	}

	@Override
	public Long getAttendancePercentageDateBase(Long empid, String fromDate, String toDate) {
		Long sumofwrkhrs = timeTrackingRepo.getSumOfWorkingHrs(empid, fromDate, toDate);
		Long NoofWrkDays = timeTrackingRepo.getNoOfDayCount(empid, fromDate, toDate);

		Long aattandancePercentage = (sumofwrkhrs * 100) / (NoofWrkDays * actualhrs);
		return aattandancePercentage;
	}

	@Override
	public Long getAllEmpAttendancePercentageDayBase(String date) {
		Long Allwrkinghrs = timeTrackingRepo.getAllSumOfWrkingHrsDayBase(date);
		Long noOfcount = timeTrackingRepo.getAllNumOfEmpsCount(date);

		Long allpercentage = (Allwrkinghrs * 100) / (noOfcount * actualhrs);
		return allpercentage;
	}

	@Override
	public Long getAllAttendancePercentageDateBase(String fromDate, String toDate) {
		Long Allwrkhrsdatebase = timeTrackingRepo.getAllSumOfWrkingHrsDateBase(fromDate, toDate);
		Long allNoofdaycount = timeTrackingRepo.getAllNumOfEmpsCount(fromDate, toDate);

		Long allpercentagedatebase = (Allwrkhrsdatebase * 100) / (allNoofdaycount * actualhrs);
		return allpercentagedatebase;
	}

	@Override
	public boolean save(AttendanceInfo model) {

		boolean flag = Boolean.FALSE;
		AttendanceInfo entity = new AttendanceInfo();
		Long id = model.getId();

		Optional<Attendance> findById = attendancesRepository.findById(id);
		Attendance att = findById.get();
		BeanUtils.copyProperties(model, entity);

		entity.setNoOfHrs(model.setNoOfHrs(util.calculateWorkingHours(model.getInTime(), model.getOutTime())));
		entity.setAttndsPercentage(model.setAttndsPercentage(util.attendsPersentage(att.getInTime().toString(), att.getOutTime().toString(), model.getNoOfHrs())));

		AttendanceInfo a = timeTrackingRepo.save(entity);
		if (!Objects.isNull(a))
			flag = Boolean.TRUE;
		return flag;
	}

	@Override
	public List<AttendanceInfo> getAllAttendancePercentage() {

		return timeTrackingRepo.findAll();

	}

	@Override
	public List<AttendanceInfo> getAllAttendenceDetails() {
		return timeTrackingRepo.findAll();
	}

	@Override
	public List<AttendanceInfo> getAllAttendenceByEmpId(Long empid) {

		return timeTrackingRepo.findByEmpId(empid);
	}

	@Override
	public List<AttendanceInfo> getAllPresentEmployeeList() {
		List<AttendanceInfo> getNoOfHrs = timeTrackingRepo.findAll();

		List<AttendanceInfo> presentEmp = new ArrayList<AttendanceInfo>();

		for (AttendanceInfo attendanceInfo : getNoOfHrs) {
			Long noOfHrs = attendanceInfo.getNoOfHrs();
			if (noOfHrs != 0) {

				presentEmp.add(attendanceInfo);
			}
		}
		return presentEmp;
	}

	@Override
	public List<AttendanceInfo> getAllAbsentEmployeeList() {
		List<AttendanceInfo> getNoOfHrs = timeTrackingRepo.findAll();

		List<AttendanceInfo> presentEmp = new ArrayList<AttendanceInfo>();

		for (AttendanceInfo attendanceInfo : getNoOfHrs) {
			Long noOfHrs = attendanceInfo.getNoOfHrs();
			if (noOfHrs == 0) {
				presentEmp.add(attendanceInfo);
			}
		}
		return presentEmp;
	}

	@Override
	public AttPercentagePieChartDto AttendancePercentagePieChart() {
		Long allEmpCount = timeTrackingRepo.getAllEmployeecountPerDay();
		Long allPresentEmpCount = timeTrackingRepo.AttendancePresentPercentagePieChart();
		Long allAbsentEmpCount = timeTrackingRepo.AttendanceAbsentPercentagePieChart();
		Double presentEmpAttPercentage = (double) ((allPresentEmpCount * 100) / allEmpCount);
		Double absentEmpAttPercentage = (double) allAbsentEmpCount * 100 / allEmpCount;

		AttPercentagePieChartDto att = new AttPercentagePieChartDto();

		AtteDataPieChartDTO atteDatap = new AtteDataPieChartDTO();
		atteDatap.setName("Present");
		atteDatap.setPercentage(presentEmpAttPercentage);

		AtteDataPieChartDTO atteDataa = new AtteDataPieChartDTO();
		atteDataa.setName("Abscent");
		atteDataa.setPercentage(absentEmpAttPercentage);

		List<AtteDataPieChartDTO> attndata = new ArrayList<>();
		attndata.add(atteDatap);
		attndata.add(atteDataa);

		att.setData(attndata);

		return att;
	}

	@Override
	public AttPercentageBarChartDTO AttendancePercentageBarChart() {

		List<Long> presentCount = timeTrackingRepo.AttendancePresentCountBarChart();
		List<Long> absentCount = timeTrackingRepo.AttendanceAbsentCountBarChart();
		AttPercentageBarChartDTO atts = new AttPercentageBarChartDTO();
		AtteDataBarChartDTO atteDaatap = new AtteDataBarChartDTO();
		atteDaatap.setName("Present");
		atteDaatap.setData(presentCount);

		AtteDataBarChartDTO atteDaataa = new AtteDataBarChartDTO();
		atteDaataa.setName("Abscent");
		atteDaataa.setData(absentCount);

		List<AtteDataBarChartDTO> attndaata = new ArrayList<>();
		attndaata.add(atteDaatap);
		attndaata.add(atteDaataa);

		atts.setAttBar(attndaata);
		return atts;
	}

}
