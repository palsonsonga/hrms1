package com.hrms.admin.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Employee;


public interface EmployeeRepository extends JpaRepository<Employee, Long> {

	
	Employee findByid(Long id);

	//deactive and approval
		public List<Employee> findAllByIsApprove(Boolean boolean1);

		@Query(value = "SELECT a FROM Employee a WHERE  a.firstName LIKE %?1%   "
				+ "  OR a.lastName LIKE %?1%	   OR a.email LIKE %?1%     "
				+ "OR a.userName LIKE %?1%  OR a.maritalStatus LIKE %?1%			"
				+ "OR a.contactNo LIKE %?1% ")
		Page<Employee> findAllSearchWithPagination(String searchKey,Pageable paging);
		
		// for duplicate check for email needed
		public Optional<Employee> findByEmail(String email);

		// for duplicate check for contactNo needed
		public Optional<Employee> findByContactNo(String contactNo);

		// for duplicate check  for userName needed
		public Optional<Employee> findByUserName(String userName);
		
		@Query("select a from Employee a where a.companyId=:companyId and a.branchId=:branchId")
		public List<Employee> findByCompanyIdAndBranchId(Long companyId, Long branchId);
		
		public List<Employee> findByDepartmentId(Long id);
		
}
