package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.dto.ItResourceDTO;

public interface ITResourcesService {

	public boolean save(ItResourceDTO model,Long id);

	public List<ItResourceDTO> getAll();

	public ItResourceDTO getById(Long id);

	public boolean delete(Long id);

	public boolean update(ItResourceDTO model, Long id);

	public boolean SaveOrupdateResource(ItResourceDTO model, Long id);

}
