package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.CompanyDTO;

public interface CompanyService {


	public boolean save(CompanyDTO model);

	//	public List<CompanyResponse> getAllCompany();

	public CompanyDTO getById(Long id);

	public boolean deleteCompany(Long id);

	public boolean updateCompany(CompanyDTO model, Long id);

	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public List<CompanyDTO> AllCompany();
}
