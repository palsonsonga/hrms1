package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.CompanyDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.Company;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.service.CompanyService;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Chandu}
 *
 */
@Service
public class CompanyServiceImpl implements CompanyService {

	private static final Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class);

	@Autowired
	private CompanyRepository attRepo;

	/**
	 * Returns true when new Attendance is store in database
	 * 
	 * @param model - new Attendance data
	 * @return - boolean
	 */

	@Override
	public boolean save(CompanyDTO model) {

		boolean flag = Boolean.FALSE;
		Company entity = new Company();
		BeanUtils.copyProperties(model, entity);
		//setting values
		/*
		 * Optional<Company> findByEmail = attRepo.findByEmail(model.getEmail());
		 * if(findByEmail.isPresent()) { Company companyEmail = findByEmail.get();
		 * if(companyEmail.getEmail()==model.getEmail()); flag = Boolean.FALSE; return
		 * flag; } Optional<Company> findByWebsite =
		 * attRepo.findByWebsite(model.getWebsite()); if(findByWebsite.isPresent()) {
		 * Company companyWebsite = findByEmail.get();
		 * if(companyWebsite.getWebsite()==model.getWebsite()); flag = Boolean.FALSE;
		 * return flag; }
		 */
		entity.setName(model.getName());
		entity.setContact(model.getContact());
		entity.setEmail(model.getEmail());
		entity.setWebsite(model.getWebsite());
		Address address=new Address();
		address.setAddress(model.getAddress().getAddress());
		address.setLandmark(model.getAddress().getLandmark());
		address.setStreet(model.getAddress().getStreet());
		address.setVillage(model.getAddress().getVillage());
		address.setDistrict(model.getAddress().getDistrict());
		address.setState(model.getAddress().getState());
		address.setCountry(model.getAddress().getCountry());
		address.setPinCode(model.getAddress().getPincode());
		entity.setAddress(address);
		Company a=attRepo.save(entity);
		if(!Objects.isNull(a)) 
			flag = Boolean.TRUE;
		logger.debug("Attendance Added into database :: " + entity);
		return flag;
	}


	/**
	 * Returns Company data when Company data is available in database by id
	 * @param id - Company Id
	 * @return - CompanyModel
	 */
	@Override
	public CompanyDTO getById(Long id) {
		Optional<Company> optionalEntity = attRepo.findById(id);
		Company entity = optionalEntity.get();
		CompanyDTO model = new CompanyDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setContact(entity.getContact());
		model.setEmail(entity.getEmail());
		model.setWebsite(entity.getWebsite());
		AddressDTO address=new AddressDTO();
		address.setId(entity.getAddress().getId());
		address.setAddress(entity.getAddress().getAddress());
		address.setLandmark(entity.getAddress().getLandmark());
		address.setStreet(entity.getAddress().getStreet());
		address.setVillage(entity.getAddress().getVillage());
		address.setDistrict(entity.getAddress().getDistrict());
		address.setState(entity.getAddress().getState());
		address.setCountry(entity.getAddress().getCountry());
		address.setPincode(entity.getAddress().getPinCode());
		model.setAddress(address);
		logger.debug("Company found with ID = " + id + " " + entity);
		return model;
	}

	@Override
	public boolean deleteCompany(Long id) {
		attRepo.deleteById(id);
		logger.debug(" Company record is deleted from database ");
		return true;
	}

	/**
	 * Returns true when existing Company data is store in database
	 * 
	 * @param model - new Company data
	 * @param id - Company Id
	 * @return - boolean
	 */
	 @Override
		public boolean updateCompany(CompanyDTO model, Long id) {
			boolean flag = Boolean.FALSE;
			
			/*
			 * Optional<Company> findByEmail = attRepo.findByEmail(model.getEmail());
			 * if(findByEmail.isPresent()) { Company companyEmail = findByEmail.get();
			 * if(companyEmail.getEmail().equals(model.getEmail())); flag = Boolean.FALSE;
			 * return flag; }
			 * 
			 * Optional<Company> findByWebsite = attRepo.findByWebsite(model.getWebsite());
			 * if(findByWebsite.isPresent()) { Company companyWebsite = findByEmail.get();
			 * if(companyWebsite.getWebsite().equals(model.getWebsite())); flag =
			 * Boolean.FALSE; return flag; }
			 */
			
			Optional<Company> findById = attRepo.findById(id);
			if (findById.isPresent()) {
				Company oldCompany = findById.get();
				oldCompany.setName(model.getName());
				oldCompany.setContact(model.getContact());
				oldCompany.setEmail(model.getEmail());
				oldCompany.setWebsite(model.getWebsite());
				Address address=new Address();
				address.setId(model.getAddress().getId());
				address.setAddress(model.getAddress().getAddress());
				address.setLandmark(model.getAddress().getLandmark());
				address.setStreet(model.getAddress().getStreet());
				address.setVillage(model.getAddress().getVillage());
				address.setDistrict(model.getAddress().getDistrict());
				address.setState(model.getAddress().getState());	
				address.setCountry(model.getAddress().getCountry());
				address.setPinCode(model.getAddress().getPincode());
				oldCompany.setAddress(address);
				Company a =attRepo.save(oldCompany);
				if(!Objects.isNull(a))
					flag = Boolean.TRUE;
				logger.debug("Company ID = " + id + " is updated in to database :: " + oldCompany);
				return flag;
			} else {
				logger.error("Company is not available in to database with ID= " + id);
				return flag;
			}
		}


	@Override																			   
	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<Company> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = attRepo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = attRepo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	public static Map<String, Object> mapData(Page<Company> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<CompanyDTO> companyModels = pagedResult.stream().map(companyEntity -> { 
			CompanyDTO model =	new CompanyDTO();
			BeanUtils.copyProperties(companyEntity, model);
			return	model;}).collect(Collectors.toList());

		response.put("data", companyModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override
	public List<CompanyDTO> AllCompany() {
		List<Company> allCompany = attRepo.findAll();
		List<CompanyDTO> models = allCompany.stream().map(entity -> {
			CompanyDTO model = new CompanyDTO();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}
}


