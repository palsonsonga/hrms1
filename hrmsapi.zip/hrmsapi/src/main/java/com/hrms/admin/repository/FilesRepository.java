package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Files;


public interface FilesRepository  extends JpaRepository<Files, Long> {
	
List<Files> findByemployeeId(Long employeeId);
	
}
