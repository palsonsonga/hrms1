package com.hrms.admin.util;

import com.hrms.admin.dto.CompanyDTO;

public class CompanyUtil {
	public static void copyNonNullValues(CompanyDTO req, CompanyDTO db) {

		if (req.getName() != null) {
			db.setName((req.getName()));
		}
		

	}
}
