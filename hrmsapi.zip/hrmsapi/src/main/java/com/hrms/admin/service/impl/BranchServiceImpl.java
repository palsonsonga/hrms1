package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.AddressDTO;
import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.entity.Address;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService {


	private static final Logger logger = LoggerFactory.getLogger(BranchServiceImpl.class);


	@Autowired
	private BranchRepository repo;

	/**
	 * Returns true when new branch is store in database
	 * 
	 * @param model - new branch data
	 * @return - boolean
	 */

	@Override
	public boolean save(BranchDTO model) {
		boolean flag = Boolean.FALSE;
		//null check
		if(model.equals(null) || model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate name check Optional<Branch> findByName =
		 * repo.findByName(model.getName()); if(findByName.isPresent()) { Branch branch
		 * = findByName.get(); if(branch.getName().equals(model.getName())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		Branch entity = new Branch();
		entity.setName(model.getName());
		entity.setLocation(model.getLocation());
		entity.setContactNo(model.getContactNo());
		entity.setEmail(model.getEmail());
		entity.setFax(model.getFax());
		entity.setCompanyId(model.getCompanyId());
		Address address=new Address();
		address.setAddress(model.getAddress().getAddress());
		address.setLandmark(model.getAddress().getLandmark());
		address.setStreet(model.getAddress().getStreet());
		address.setVillage(model.getAddress().getVillage());
		address.setDistrict(model.getAddress().getDistrict());
		address.setState(model.getAddress().getState());
		address.setCountry(model.getAddress().getCountry());
		address.setPinCode(model.getAddress().getPincode());
		entity.setAddress(address);
		Branch d=repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Branch Added into database :: " + entity);
		return flag;
	}


	/**
	 * Returns true when existing branch data is store in database
	 * 
	 * @param model - new branch data
	 * @param id - branch Id
	 * @return - boolean
	 */

	/**
	 * Returns All Branch data when branch data is available in database
	 * @return - List of Branchresponse
	 */
	@Override																			   
	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<Branch> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	/**
	 * Returns Branch data when branch data is available in database by id
	 * @param id - branch Id
	 * @return - BranchResponse
	 */
	@Override
	public BranchDTO getById(Long id) {
		Optional<Branch> optionalEntity = repo.findById(id);
		Branch entity = optionalEntity.get();
		BranchDTO model = new BranchDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setLocation(entity.getLocation());
		model.setContactNo(entity.getContactNo());
		model.setEmail(entity.getEmail());
		model.setFax(entity.getFax());
		model.setCompanyId(entity.getCompanyId());
		AddressDTO address=new AddressDTO();
		address.setId(entity.getAddress().getId());
		address.setAddress(entity.getAddress().getAddress());
		address.setLandmark(entity.getAddress().getLandmark());
		address.setStreet(entity.getAddress().getStreet());
		address.setVillage(entity.getAddress().getVillage());
		address.setDistrict(entity.getAddress().getDistrict());
		address.setState(entity.getAddress().getState());
		address.setCountry(entity.getAddress().getCountry());
		address.setPincode(entity.getAddress().getPinCode());

		model.setAddress(address);

		//BeanUtils.copyProperties(branchEntity, model);
		logger.debug("Branch found with ID = " + id + " " + entity);
		return model;
	}

	/**
	 * Returns true when branch data is deleted from database by id
	 * @param id - branch id
	 * @return - boolean
	 */
	@Override
	public boolean deleteBranch(Long id) {
		repo.deleteById(id);
		logger.debug(" Branch record is deleted from database ");
		return true;

	}

	/**
	 * Returns true when existing Branch data is store in database
	 * 
	 * @param model - new branch data
	 * @param id - branch Id
	 * @return - boolean
	 */
	@Override
	public boolean updateBranch(BranchDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		//null check
		if(model.equals(null) || model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate name check Optional<Branch> findByName =
		 * repo.findByName(model.getName()); if(findByName.isPresent()) { Branch branch
		 * = findByName.get(); if(branch.getName().equals(model.getName())) { flag =
		 * Boolean.FALSE; return flag; } }
		 */
		Optional<Branch> findById = repo.findById(id);
		if (findById.isPresent()) {
			Branch oldBranch = findById.get();
			oldBranch.setName(model.getName());
			oldBranch.setLocation(model.getLocation());
			oldBranch.setContactNo(model.getContactNo());
			oldBranch.setEmail(model.getEmail());
			oldBranch.setFax(model.getFax());
			oldBranch.setCompanyId(model.getCompanyId());
			Address address=new Address();
			address.setId(model.getAddress().getId());
			address.setAddress(model.getAddress().getAddress());
			address.setLandmark(model.getAddress().getLandmark());
			address.setStreet(model.getAddress().getStreet());
			address.setVillage(model.getAddress().getVillage());
			address.setDistrict(model.getAddress().getDistrict());
			address.setState(model.getAddress().getState());
			address.setCountry(model.getAddress().getCountry());
			address.setPinCode(model.getAddress().getPincode());
			oldBranch.setAddress(address);
			Branch d =repo.save(oldBranch);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Branch ID = " + id + " is updated in to database :: " + oldBranch);
			return flag;
		} else {
			logger.error("Branch is not available in to database with ID= " + id);
			return flag;
		}
	}

	public static Map<String, Object> mapData(Page<Branch> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<BranchDTO> branchModels = pagedResult.stream().map(branchEntity -> { 
			BranchDTO model =	new BranchDTO();
			BeanUtils.copyProperties(branchEntity, model);
			return	model;}).collect(Collectors.toList());

		response.put("data", branchModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override
	public List<BranchDTO> listOfBranch(Long id) {
		List<Branch> allBranch = repo.findByCompanyId(id);
		List<BranchDTO> models = allBranch.stream().map(entity -> {
			BranchDTO model = new BranchDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			return model;
		}).collect(Collectors.toList());

		return models;
	}
}