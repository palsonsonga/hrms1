package com.hrms.admin.dto;


public class MailDTO {

	private String name;
	private String to;
	private String subject;
	private String template;
	private String from;
	public MailDTO() {
		super();
	}

	public MailDTO(String name, String to, String subject, String template, String from) {
		super();
		this.name = name;
		this.to = to;
		this.subject = subject;
		this.template = template;
		this.from = from;
	}

	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}

	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	@Override
	public String toString() {
		return "MailRequest [name=" + name + ", to=" + to + ", subject=" + subject + ", template=" + template + "]";
	}
	
}
