package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.HolidayDTO;
import com.hrms.admin.entity.Holiday;
import com.hrms.admin.repository.HolidayRepository;
import com.hrms.admin.service.HolidayService;

@Service
public class HolidayServiceImpl implements HolidayService {

	private static Logger logger = LoggerFactory.getLogger(HolidayServiceImpl.class);

	@Autowired
	private HolidayRepository repo;

	/**
	 * Returns true when new holiday is store in database
	 * 
	 * @param model - new holiday data
	 * @return - boolean
	 */
	@Override
	public boolean save(HolidayDTO model) {
		boolean flag = Boolean.FALSE;
		// null check
		if (model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate checking for Holiday Name Optional<Holiday> findByName =
		 * repo.findByName(model.getName()); if (findByName.isPresent()) { Holiday
		 * holiday = findByName.get(); if (holiday.getName().equals(model.getName())) {
		 * flag = Boolean.FALSE; return flag; } }
		 */
		Holiday entity = new Holiday();
		entity.setName(model.getName());
		entity.setDate(model.getDate());
		entity.setCompanyId(model.getCompanyId());
		entity.setBranchId(model.getBranchId());
		Holiday h = repo.save(entity);
		if (!Objects.isNull(h)) {
			flag = Boolean.TRUE;
			logger.debug("holiday Added into database :: " + entity);
		} else {
			flag = Boolean.FALSE;
		}
		return flag;
	}

	/**
	 * Returns true when existing holiday data is store in database
	 * 
	 * @param model - new holiday data
	 * @param id    - holiday Id
	 * @return - boolean
	 */
	@Override
	public boolean updateHoliday(HolidayDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		logger.info("insert into updateDesignationById method in HolidayServiceImpl class ");
		// null check
		if (model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate checking for Project Name Optional<Holiday> findByName =
		 * repo.findByName(model.getName()); if (findByName.isPresent()) { Holiday
		 * holiday = findByName.get(); if (holiday.getName().equals(model.getName())) {
		 * flag = Boolean.FALSE; return flag; } }
		 */
		Optional<Holiday> findById = repo.findById(id);
		if (findById.isPresent()) {
			Holiday oldHoliday = findById.get();
			oldHoliday.setId(model.getId());
			oldHoliday.setName(model.getName());
			oldHoliday.setDate(model.getDate());
			oldHoliday.setCompanyId(model.getCompanyId());
			oldHoliday.setBranchId(model.getBranchId()); 
			Holiday h = repo.save(oldHoliday);
			if (!Objects.isNull(h))
				flag = Boolean.TRUE;
			logger.debug("Holiday ID = " + id + " is updated in to database :: " + oldHoliday);
			return flag;
		} else {
			logger.error("Holiday is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns Holiday data when Holiday data is available in database by id
	 * 
	 * @param id - Holiday Id
	 * @return - HolidayModel
	 */
	@Override
	public HolidayDTO getById(Long id) {
		Optional<Holiday> optionalEntity = repo.findById(id);
		Holiday entity = optionalEntity.get();
		HolidayDTO model = new HolidayDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDate(entity.getDate());
		model.setCompanyId(entity.getCompanyId());
		model.setBranchId(entity.getBranchId());
		model.setCompanyName(entity.getCompany().getName());
		model.setBranchName(entity.getBranch().getName());
		logger.debug("Holiday found with ID = " + id + " " + entity);
		return model;
	}

	/**
	 * Returns Holiday data when Holiday data is available in database by name
	 * 
	 * @param name - Holiday name
	 * @return - HolidayModel
	 */

@Override
	public HolidayDTO getByName(String name) {
		Optional<Holiday> findByHolidayName = repo.findByName(name);
		HolidayDTO model = new HolidayDTO();
		BeanUtils.copyProperties(findByHolidayName, model);
		logger.debug("Holiday found with Name = " + name + " " + findByHolidayName);
		return model;
	}

	
	/**
	 * Returns true when Holiday data is deleted from database by id
	 * 
	 * @param id - Holiday id
	 * @return - boolean
	 */
	@Override
	public boolean deleteHoliday(Long id) {
		repo.deleteById(id);
		logger.debug(" Holiday record is deleted from database ");
		return true;
	}

	
	public static Map<String, Object> mapData(Page<Holiday> pagedResult) {
		HashMap<String, Object> response = new HashMap<>();
		List<HolidayDTO> holidayModels = pagedResult.stream().map(entity -> {
			HolidayDTO model = new HolidayDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDate(entity.getDate());
			return model;
		}).collect(Collectors.toList());
		response.put("data", holidayModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
	
	@Override																			   
	public Map<String, Object> getAllHoliday(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {
		Pageable paging = null;
		Page<Holiday> pagedResult = null;
		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
}
