package com.hrms.admin.util;

import com.hrms.admin.model.BranchRequest;

public class BranchUtil {
	public void copyNonNullValues(BranchRequest req, BranchRequest db) {

		if (req.getName() != null) {
			db.setName((req.getName()));
		}
		if (req.getDescription() != null) {
			db.setDescription((req.getDescription()));
		}

	}
}
