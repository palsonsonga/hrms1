package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Notification;



public interface NotificationRepository extends JpaRepository<Notification, Long> {

	public Notification findBysubject(String subject);

	Page<Notification> findAll(Pageable paging);

	@Query(value = "SELECT n FROM  Notification n WHERE  n.subject LIKE %?1%")
	Page<Notification> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Notification> findBySubject(String name);
}
