package com.hrms.admin.util;

import com.hrms.admin.entity.Policy;

public class PolicyUtil {

	public static void copyNonNullValues(Policy req, Policy db) {

		if (req.getName() != null) {
			db.setName((req.getName()));
		}
		if (req.getDescription() != null) {
			db.setDescription((req.getDescription()));
		}

	}
}