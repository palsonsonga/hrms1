package com.hrms.admin.entity;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "EMP_LEAVE")
public class EmpLeave extends AuditingEntity{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "ID",  nullable = true)
	private Long id;

	@Column(name = "EMP_ID")
	private Long employeeId;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "EMP_ID", insertable = false, updatable = false) private
	Employee employee;

	@Column(name = "LEAVETYPE_ID")
	private Long leaveTypeId;

	@Column(name = "Leave_TYPE")
	private String leaveType;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.PERSIST)
	@JoinColumn(name = "LEAVETYPE_ID", insertable = false, updatable = false)
	private LeaveType leaveType1;

	@Column(name = "EMAIL_ID")
	private String emailId;

	@Column(name = "START_DATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date startDate;

	@Column(name = "END_DATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date endDate;

	@Column(name = "LEAVE_APPLY_DATE")
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Temporal(TemporalType.DATE)
	private Date leaveApplyDate;

	@Column(name = "TOTAL_DAYS")
	private Long totalDays;

	@Column(name = "REASON")
	private String reason;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "MANAGER_MAIL_ID")
	private String managerMailId;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Long employeeId) {
		this.employeeId = employeeId;
	}

	public Long getLeaveTypeId() {
		return leaveTypeId;
	}

	public void setLeaveTypeId(Long leaveTypeId) {
		this.leaveTypeId = leaveTypeId;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public LeaveType getLeaveType1() {
		return leaveType1;
	}

	public void setLeaveType1(LeaveType leaveType1) {
		this.leaveType1 = leaveType1;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Date getLeaveApplyDate() {
		return leaveApplyDate;
	}

	public void setLeaveApplyDate(Date leaveApplyDate) {
		this.leaveApplyDate = leaveApplyDate;
	}

	public Long getTotalDays() {
		return totalDays;
	}

	public void setTotalDays(Long totalDays) {
		this.totalDays = totalDays;
	}

	public String getReason() {
		return reason;
	}
	
	

	public String getManagerMailId() {
		return managerMailId;
	}

	public void setManagerMailId(String managerMailId) {
		this.managerMailId = managerMailId;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}

}
