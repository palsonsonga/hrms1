package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.NotificationDTO;
import com.hrms.admin.entity.Notification;
import com.hrms.admin.repository.NotificationRepository;
import com.hrms.admin.service.NotificationService;
import com.hrms.admin.util.EmailServiceUtil;

@Service
public class NotificationServiceImpl implements NotificationService {

	private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Autowired
	private NotificationRepository repo;
	
	@Autowired
	private EmailServiceUtil emailServiceUtil;

	/**
	 * Returns true when new notification is store in database
	 * 
	 * @param model - new notification data
	 * @return - boolean
	 */
	@Override
	public boolean save(NotificationDTO model) {
		boolean flag = Boolean.FALSE;
		Notification entity = new Notification();
		
		/*
		 * Optional<Notification> findBySubject =
		 * repo.findBySubject(model.getSubject()); if(findBySubject.isPresent()) {
		 * Notification subject = findBySubject.get();
		 * if(subject.getSubject()==model.getSubject()); flag = Boolean.FALSE; return
		 * flag; }
		 */
		BeanUtils.copyProperties(model, entity);
		// setting values
		entity.setSubject(model.getSubject());
		entity.setDescription(model.getDescription());
		entity.setCompanyId(model.getCompanyId()); 
		Notification d = repo.save(entity);
		if (!Objects.isNull(d))
			flag = Boolean.TRUE;
		logger.debug("Notification Added into database :: " + entity);
		MailDTO request = new MailDTO();
		request.setSubject("Event  :"+model.getSubject() +" Event date :"+ model.getEventDate());
		request.setTo(model.getToMail());
		request.setName(model.getSubject());
		request.setTemplate("NotoficationTemplate.ftl");
		request.setFrom(model.getFromMail()); 
		Map<String, Object> model1 = new HashMap<>();
		model1.put("name", model.getSubject());
		model1.put("description", model.getDescription());
		emailServiceUtil.sendEmail(request, model1);
		return flag;

	}


	/**
	 * Returns true when existing notification data is store in database
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - boolean
	 */
	@Override
	public boolean updateNotification(NotificationDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		/*
		 * Optional<Notification> findBySubject =
		 * repo.findBySubject(model.getSubject()); if(findBySubject.isPresent()) {
		 * Notification subject = findBySubject.get();
		 * if(subject.getSubject()==model.getSubject()); flag = Boolean.FALSE; return
		 * flag; }
		 */
		Optional<Notification> findById = repo.findById(id);
		if (findById.isPresent()) {
			Notification oldNotification = findById.get();
			oldNotification.setSubject(model.getSubject());
			oldNotification.setDescription(model.getDescription());
			oldNotification.setCompanyId(model.getCompanyId()); 
			oldNotification.setEventDate(model.getEventDate());
			Notification n = repo.save(oldNotification);
			if (!Objects.isNull(n))
				flag = Boolean.TRUE;
			logger.debug("Notification ID = " + id + " is updated in to database :: " + oldNotification);
			return flag;
		} else {
			logger.error("Notification is not available in to database with ID= " + id);
			return flag;
		}

	}

	/**
	 * Returns Notification data when notification data is available in database by
	 * id
	 * 
	 * @param id - notification Id
	 * @return - NotificationModel
	 */
	@Override
	public NotificationDTO getById(Long id) {
		Optional<Notification> optionalEntity = repo.findById(id);
		Notification entity = optionalEntity.get();
		NotificationDTO model = new NotificationDTO();
		model.setId(entity.getId());
		model.setSubject(entity.getSubject());
		model.setCompanyId(entity.getCompanyId());
		model.setDescription(entity.getDescription());
		model.setEventDate(entity.getEventDate());
		logger.debug("Skill found with ID = " + id + " " + entity);
		return model;
	}

	/**
	 * Returns Notification data when notification data is available in database by
	 * subject
	 * 
	 * @param subject - subject
	 * @return - NotificationModel
	 */
	@Override
	public NotificationDTO getBySubject(String subject) {
		Notification findBySubject = repo.findBysubject(subject);
		NotificationDTO model = new NotificationDTO();
		model.setId(findBySubject.getId());
		model.setSubject(findBySubject.getSubject());
		model.setDescription(findBySubject.getDescription());
		model.setCompanyId(findBySubject.getCompanyId());
		model.setCompanyName(findBySubject.getCompany().getName());
		model.setEventDate(findBySubject.getEventDate());
		logger.debug("Notification found with Subject = " + subject + " " + findBySubject);
		return model;
	}

	/**
	 * Returns All Notification data when notification data is available in database
	 * 
	 * @return - List of NotificationModel
	 */
	@Override
	public List<NotificationDTO> getAllNotificationList() {
		List<Notification> allNotifications = repo.findAll();
		List<NotificationDTO> models = allNotifications.stream().map(entity -> {
			NotificationDTO model = new NotificationDTO();
			model.setId(entity.getId());
			model.setSubject(entity.getSubject());
			model.setDescription(entity.getDescription());
			model.setCompanyId(entity.getCompanyId());
			model.setCompanyName(entity.getCompany().getName());
			model.setEventDate(entity.getEventDate());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns true when notification data is deleted from database by id
	 * 
	 * @param id - notification id
	 * @return - boolean
	 */
	@Override
	public boolean deleteNotification(Long id) {
		repo.deleteById(id);
		logger.debug(" Notification record is deleted from database ");
		return true;
	}

	//Paging

	@Override																			   
	public Map<String, Object> getAllNotification(Integer pageIndex, Integer pageSize, String sortBy,String searchKey,String orderBy) {

		Pageable paging = null;

		Page<Notification> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}		
	public static Map<String, Object> mapData(Page<Notification> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<NotificationDTO> notificationModels = pagedResult.stream().map(entity -> { 
			NotificationDTO model =	new NotificationDTO();
			model.setId(entity.getId());
			model.setSubject(entity.getSubject());
			model.setDescription(entity.getDescription());
			return	model;}).collect(Collectors.toList());

		response.put("data", notificationModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
}