package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.ItResource;

public interface ITResourcesRepository extends JpaRepository<ItResource, Long> {

	ItResource findByemployeeId(Long id);

}
