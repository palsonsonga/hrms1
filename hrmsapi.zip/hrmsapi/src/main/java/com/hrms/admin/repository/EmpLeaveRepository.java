package com.hrms.admin.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.EmpLeave;


public interface EmpLeaveRepository extends JpaRepository<EmpLeave, Long>{


	public List<EmpLeave> findByEmployeeId(Long empId);
	public List<EmpLeave> findByStartDate(Date date);

	@Query(value ="SELECT e FROM EmpLeave e WHERE    e.leaveType LIKE %?1%       OR e.emailId LIKE %?1%     OR e.startDate LIKE %?1%			OR e.endDate LIKE %?1%			OR e.leaveApplyDate LIKE %?1%			OR e.totalDays LIKE %?1%			OR e.reason LIKE %?1%        OR e.status LIKE %?1%")  
	Page<EmpLeave> findAllSearchWithPagination(String searchKey,Pageable paging);
}
