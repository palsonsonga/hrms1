package com.hrms.admin.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class DesignationRecordNotFoundException extends RuntimeException {

	//private static final long serialVersionUID = 1L;

	public DesignationRecordNotFoundException(String exception) {
		super(exception);
	}
}
