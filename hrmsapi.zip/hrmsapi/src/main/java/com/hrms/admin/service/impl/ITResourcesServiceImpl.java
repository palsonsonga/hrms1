package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.ItResourceDTO;
import com.hrms.admin.entity.ItResource;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.ITResourcesRepository;
import com.hrms.admin.service.ITResourcesService;

@Service
public class ITResourcesServiceImpl implements ITResourcesService {
	@Autowired
	private ITResourcesRepository repo;
	
	@Autowired
	private EmployeeRepository employeeRepo;

	@Override
	public boolean save(ItResourceDTO model,Long id) {
		boolean flag = Boolean.FALSE;
		ItResource entity = new ItResource();
		/*
		 * if (employeeobj.isPresent()) { Employee employee=employeeobj.get();
		 * entity.setIpAddress(model.getIpAddress()); entity.setPort(model.getPort());
		 * //entity.setItems(model.getItems());
		 * //entity.setEmployeeId(employee.getId()); }
		 */
		ItResource d = repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		//logger.debug("ITResource Added into database :: " + entity);
		return flag;
	}

	@Override
	public List<ItResourceDTO> getAll() {
		List<ItResource> allResources = repo.findAll();
		List<ItResourceDTO> models = allResources.stream().map(entity -> {
			ItResourceDTO model = new ItResourceDTO();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;

	}

	@Override
	public ItResourceDTO getById(Long id) {
		Optional<ItResource> optionalEntity = repo.findById(id);
		ItResource entity = optionalEntity.get();
		ItResourceDTO model = new ItResourceDTO();
		BeanUtils.copyProperties(entity, model);
		return model;
	}

	@Override
	public boolean delete(Long id) {
		repo.deleteById(id);
		return true;
	}

	@Override
	public boolean update(ItResourceDTO model, Long id) {
		return false;
		/*
		 * boolean flag = Boolean.FALSE; Optional<ItResource> findById =
		 * repo.findById(id); if (findById.isPresent()) { ItResource old =
		 * findById.get(); old.setIpAddress(model.getIpAddress());
		 * old.setPort(model.getPort()); //old.setItems(model.getItems());
		 * 
		 * ItResource it = repo.save(old); if (!Objects.isNull(it)) flag = Boolean.TRUE;
		 * return flag; } else { return flag; }
		 */
	}

	 @Override
	 	public boolean SaveOrupdateResource(ItResourceDTO model, Long empid) {
			return false;
			/*
			 * boolean flag = Boolean.FALSE; Employee emp = employeeRepo.findByid(empid);
			 * ItResource old=new ItResource(); if( model.getId()==null) {
			 * old.setEmployeeId(emp.getId()); old.setIpAddress(model.getIpAddress());
			 * old.setPort(model.getPort()); List<ResourceItems> resourceItemslist = new
			 * ArrayList<>(); for (ResourceItemsDTO resourceItemsDTO : model.getItems()) {
			 * ResourceItems resourceItems = new ResourceItems();
			 * 
			 * resourceItems.setAssetId(resourceItemsDTO.getAsset().getId());
			 * resourceItems.setValue(resourceItemsDTO.getValue());
			 * resourceItemslist.add(resourceItems); } old.setItems(resourceItemslist);
			 * 
			 * ItResource it = repo.save(old); if (!Objects.isNull(it)) flag = Boolean.TRUE;
			 * return flag; }else { old.setId(model.getId());
			 * old.setEmployeeId(emp.getId()); old.setIpAddress(model.getIpAddress());
			 * old.setPort(model.getPort()); List<ResourceItems> resourceItemslist = new
			 * ArrayList<>(); for (ResourceItemsDTO resourceItemsDTO : model.getItems()) {
			 * ResourceItems resourceItems = new ResourceItems();
			 * resourceItems.setId(resourceItemsDTO.getId());
			 * resourceItems.setAssetId(resourceItemsDTO.getAsset().getId());;
			 * resourceItems.setValue(resourceItemsDTO.getValue());
			 * resourceItemslist.add(resourceItems); } old.setItems(resourceItemslist);
			 * ItResource it = repo.save(old); if (!Objects.isNull(it)) flag = Boolean.TRUE;
			 * return flag; }
			 */
	}
}
