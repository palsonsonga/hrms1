package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.EmployeeComIDBranchID;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.MailDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.dto.ProfileImageDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.dto.ResourceItemsDTO;
import com.hrms.admin.entity.Branch;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Files;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.entity.ProfileImage;
import com.hrms.admin.entity.Project;
import com.hrms.admin.entity.ResourceItems;
import com.hrms.admin.entity.User;
import com.hrms.admin.repository.EmployeeRepository;
import com.hrms.admin.repository.FilesRepository;
import com.hrms.admin.repository.ProfileImageRepository;
import com.hrms.admin.repository.ResourceItemsRepository;
import com.hrms.admin.repository.UserRepository;
import com.hrms.admin.service.EmployeeService;
import com.hrms.admin.util.EmailServiceUtil;
import com.hrms.admin.util.EmployeeServiceUtil;
import com.hrms.admin.util.S3ServiceUtil;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private static final Logger logger = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Autowired
	private S3ServiceUtil s3serviceutil;
	@Autowired
	private EmployeeRepository employeeRepo;

	@Autowired
	private FilesRepository filerepo;

	@Autowired
	private EmployeeServiceUtil employeeServiceUtil;

	@Autowired
	private EmailServiceUtil emailServiceUtil;

	@Autowired
	private UserRepository userRepo;

	@Autowired
	private ResourceItemsRepository ResourceItemsRepo;

	@Autowired
	private ProfileImageRepository profileRepo;

	@Value("${aws.bucket.ProfileImagefolder}")
	private String imagefolder;

	@Value("${aws.bucket}")
	private String bucketName;

	@PostConstruct
	public void init() {
		String name = s3serviceutil.createFolder(imagefolder);
		logger.debug("folder created in s3 bucket ::" + "bucketName" + "foldername ::" + name);
	}

	@Override
	public Integer saveEmployee(EmployeeDTO employeedto, MultipartFile[] files, MultipartFile image) {

		int flag = 0;

		/*
		 * // for null checks if (employeedto.getEmail().equals(null) ||
		 * employeedto.getEmail().equals("") || employeedto.getUserName().equals(null)
		 * || employeedto.getUserName().equals("") ||
		 * employeedto.getContactNo().equals(null) ||
		 * employeedto.getContactNo().equals("") || employeedto.equals(null)) { flag =
		 * 0; return flag; } // for duplicate checks for Email Optional<Employee>
		 * findByEmail = employeeRepo.findByEmail(employeedto.getEmail()); if
		 * (findByEmail.isPresent()) { Employee employee = findByEmail.get(); if
		 * (employeedto.getEmail().equals(employee.getEmail())) { flag = 1; // 1 for
		 * Email return flag; }
		 * 
		 * } // for duplicate checks for userName Optional<Employee> findByUserName =
		 * employeeRepo.findByUserName(employeedto.getUserName()); if
		 * (findByUserName.isPresent()) { Employee employee = findByUserName.get(); if
		 * (employeedto.getUserName().equals(employee.getUserName())) { flag = 2; // 2
		 * for userName return flag; }
		 * 
		 * } // for duplicate checks for contactNo Optional<Employee> findByContactNo =
		 * employeeRepo.findByContactNo(employeedto.getContactNo()); if
		 * (findByContactNo.isPresent()) { Employee employee = findByContactNo.get(); if
		 * (employeedto.getContactNo().equals(employee.getContactNo())) { flag = 3; // 3
		 * for userName return flag; }
		 * 
		 * }
		 */

		Employee employee = employeeServiceUtil.saveEmployee(employeedto);
		String employeename = employee.getFirstName() + employee.getLastName();
		String foldername = employee.getId() + employeename;

		// adding foldername with empployee
		employee.setFolderName(foldername);
		employeeRepo.save(employee);
		// calling s3service save files in s3 bucket
		boolean flag1 = s3serviceutil.uploadFileInFolder(files, foldername);
		logger.debug("Employee Documents Added into S3bucket :: " + employeename);
		// storing files details in database
		if (flag1 == true) {
			for (MultipartFile file : files) {
				Files file1 = new Files();
				file1.setName(file.getOriginalFilename());
				file1.setEmployeeId(employee.getId());
				file1.setFolderName(foldername);
				file1.setFilePath(s3serviceutil.generateFileUrl(file.getOriginalFilename(), foldername));
				// add create and updated by

				filerepo.save(file1);
			}
			logger.debug("Employee Documents details Added into database :: " + employeename);
		}
		// image uploading
		boolean flag2 = s3serviceutil.uploadFileInFolder(image, imagefolder, employeename);
		logger.debug("Employee ProfileImage Added into S3bucket :: " + employeename);
		ProfileImage profileImage = new ProfileImage();
		if (flag2 == true) {
			profileImage.setImageName(employeename);
			profileImage.setImageurl(s3serviceutil.generateFileUrl(employeename, imagefolder));
			// add create and updated by

		}
		ProfileImage pi = profileRepo.save(profileImage);
		employee.setProfileImageId(pi.getId());
		employeeRepo.save(employee);
		logger.debug("Employee ProfileImage details Added into database :: " + employeename);

		if (!Objects.isNull(employee))
			flag = 0; // 4 for not added in to db
		logger.debug("Employee Added into database :: " + employee);
		return flag;
	}

	@Override
	public EmployeeDTO getEmployeeById(Long id) {
		Optional<Employee> optionalEntity = employeeRepo.findById(id);
		Employee employee = optionalEntity.get();

		EmployeeDTO employeedto = employeeServiceUtil.getEmployee(employee);

		logger.debug("Employee found with ID = " + id + " " + employee);
		return employeedto;

	}

	@Override // extra
	public EmployeeDTO getFilesByEmployeeId(Long id) {
		/* EmployeeDTO employee =employeeServiceUtil.getFilesByEmployeeId(id); */
		return null;
	}

	@Override
	public EmployeeDTO getById(Long id) {
		Optional<Employee> optionalEntity = employeeRepo.findById(id);
		Employee Entity = optionalEntity.get();
		EmployeeDTO model = new EmployeeDTO();
		BeanUtils.copyProperties(Entity, model);
		logger.debug("Branch found with ID = " + id + " " + Entity);
		return model;
	}

	public boolean updateEmployeeByStatus(Long id, String status) {
		boolean flag = Boolean.FALSE;
		Optional<Employee> findById = employeeRepo.findById(id);
		Employee emp = findById.get();
		if (status.equalsIgnoreCase("ACTIVATE")) {
			emp.setIsActive(Boolean.TRUE);
			Employee e = employeeRepo.save(emp);
			if (!Objects.isNull(e))
				flag = Boolean.TRUE;
			logger.debug("Employee ID = " + id + " is activated in to database :: " + emp);
			return flag;
		} else if (status.equalsIgnoreCase("DEACTIVATE")) {
			emp.setIsActive(Boolean.FALSE);
			Employee e = employeeRepo.save(emp);
			if (!Objects.isNull(e))
				flag = Boolean.TRUE;
			logger.debug("Employee ID = " + id + " is deactivated in to database :: " + emp);
			return flag;
		} else
			logger.debug("EmpLeave ID = " + id + " is status is invalid " + status);
		return flag;
	}

	// list for who need to approve form admin
	public List<Employee> appliedList() {
		logger.debug("Employee List found::");
		return employeeRepo.findAllByIsApprove(Boolean.FALSE);
	}

	// approve employee by id
	public Employee approveById(Long id) {

		Optional<Employee> optional = employeeRepo.findById(id);
		Employee e = optional.get();
		Optional<User> optionalUser = userRepo.findByEmail(e.getEmail());
		User user = optionalUser.get();
		Employee e1 = new Employee();
		BeanUtils.copyProperties(e, e1);
		if (e.getIsApprove()) {
			logger.error("Employee" + e.getId() + "is already Approved");
		}
		e1.setIsApprove(Boolean.TRUE);
		employeeRepo.save(e1);
		MailDTO request = new MailDTO();
		request.setTo(e.getEmail());
		request.setSubject("Approval");
		request.setName(e1.getFirstName());
		request.setTemplate("IdActivation.ftl");
		request.setFrom("hrms@mail.onpassive.com");
		String url = ("https://onpassive.awsapps.com/mail");
		Map<String, Object> model = new HashMap<>();
		//String tempPass = emailServiceUtil.generateCommonLangPassword();
		//String userName = user.getUsername();
		String name = e.getFirstName();
		model.put("tempPass", emailServiceUtil.generateCommonLangPassword());
		model.put("userName", user.getUsername());
		model.put("url", url);
		model.put("name", name);
		emailServiceUtil.sendEmail(request, model);
		return e1;
	}
	/*
	 * @Override public List<EmployeeDTO> employeeList() { return
	 * employeeRepo.getAllEmployee(); }
	 */

	@Override
	public boolean updateEmplyee(Long id, EmployeeDTO model, MultipartFile[] files, MultipartFile image) {
		boolean flag = Boolean.FALSE;
		Employee employee = employeeServiceUtil.updateEmplyee(model, id);
		// calling s3service save files in s3 bucket
		if(!Objects.isNull(files)) {
		s3serviceutil.uploadFileInFolder(files, employee.getFolderName());
		// storing files details in database
		for (MultipartFile file : files) {
			Files file1 = new Files();
			file1.setName(file.getOriginalFilename());
			file1.setEmployeeId(employee.getId());
			file1.setFolderName(employee.getFolderName());
			file1.setFilePath(s3serviceutil.generateFileUrl(file.getOriginalFilename(), employee.getFolderName()));
			filerepo.save(file1);
		}
		}
		if(!Objects.isNull(files)) {
		String employeename = employee.getFirstName() + employee.getLastName();
		flag = s3serviceutil.deleteFileFromFolder(employee.getProfileImage().getImageName(), imagefolder);
		if (flag == true) {
			profileRepo.deleteById(employee.getProfileImageId());
		}
		flag = s3serviceutil.uploadFileInFolder(image, imagefolder, employeename);
		logger.debug("Employee ProfileImage updated into S3bucket :: " + employeename);
		ProfileImage profileImage = new ProfileImage();
		if (flag == true) {
			profileImage.setImageName(employeename);
			profileImage.setImageurl(s3serviceutil.generateFileUrl(employeename, imagefolder));
		}
		ProfileImage pi = profileRepo.save(profileImage);
		employee.setProfileImageId(pi.getId());
		employeeRepo.save(employee);
		logger.debug("Employee ProfileImage details updated into database :: " + employeename);
		}
		logger.debug("Employee Added into database :: " + employee);
		if (!Objects.isNull(employee))
			flag = Boolean.TRUE;
		return flag;
	}

	@Override
	public boolean deleteEmployeeFile(Long id, Long fileId) {
		boolean flag = Boolean.FALSE;
		Employee employee = employeeRepo.findByid(id);
		Files file = filerepo.findById(fileId).get();
		flag = s3serviceutil.deleteFileFromFolder(file.getName(), employee.getFolderName());
		if (flag == true) {
			filerepo.deleteById(fileId);
		}
		logger.debug("File Deleted in Data Base and AWS S3 Bucket with filename ::" + file.getName() + "and File ID ::"
				+ fileId);
		return flag;
	}

	@Override
	public boolean deleteEmployeeProfileImage(Long imageid) {
		boolean flag = Boolean.FALSE;
		ProfileImage image = profileRepo.findById(imageid).get();
		flag = s3serviceutil.deleteFileFromFolder(image.getImageName(), imagefolder);
		if (flag == true) {
			profileRepo.deleteById(imageid);
		}
		logger.debug(
				"Image Deleted in AWS S3 Bucket with filename ::" + image.getImageName() + "and image ID ::" + imageid);
		return flag;
	}

	@Override
	public boolean AddResourcetoEmployee(EmployeeDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		Employee emp = employeeRepo.findByid(id);
		
		for (ResourceItemsDTO dto : model.getResourceItems()) {
			ResourceItems ri = ResourceItemsRepo.findByid(dto.getId());
			if (!Objects.isNull(ri)) {
					ri.setId(dto.getId());
					ri.setAssetId(dto.getAssetId());
					ri.setValue(dto.getValue());
					ri.setEmployeeId(emp.getId());
						ResourceItemsRepo.save(ri);
			} else {
				ResourceItems resourceItems = new ResourceItems();
					resourceItems.setAssetId(dto.getAssetId());
					resourceItems.setValue(dto.getValue());
					resourceItems.setEmployeeId(emp.getId());
						ResourceItemsRepo.save(resourceItems);
			}
		}
		emp.setPort(model.getPort());
		emp.setIpAddress(model.getIpAddress());
		employeeRepo.save(emp);
		return flag;
	}
	
	/** Update an Existing Employee with projects */
	@Transactional
	public boolean updateEmployeeProject(EmployeeDTO employeedto, Long id) {
		boolean flag = Boolean.FALSE;
		List<Project> projectlist = new ArrayList<>();
		if (employeeRepo.findById(id).isPresent()) {
			Employee employee = employeeRepo.findById(id).get();
			for (ProjectDTO projectdto : employeedto.getProjects()) {
				Project project = new Project();
				project.setId(projectdto.getId());
				project.setName(projectdto.getName());
				project.setDescription(projectdto.getDescription());
				// BeanUtils.copyProperties(projectdto, project);
				projectlist.add(project);
			}
			employee.setProjects(projectlist);
			Employee savedEmployee = employeeRepo.save(employee);
			if (!Objects.isNull(savedEmployee))
				flag = Boolean.TRUE;
			logger.debug("Employee ID = " + id + " is updated with projects :: " + savedEmployee);
			return flag;
		} else {
			logger.error("Employee is not updated with projects:: " + id);
			return flag;
		}
	}

	@Override
	public Map<String, Object> getAllEmployeePage(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {
		Pageable paging = null;
		Page<Employee> pagedResult = null;
		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			// Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = employeeRepo.findAllSearchWithPagination(searchKey, paging);
		} else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = employeeRepo.findAllSearchWithPagination(searchKey, paging);
		}
		if (pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	public static Map<String, Object> mapData(Page<Employee> pagedResult) {

		HashMap<String, Object> response = new HashMap<>();
		List<EmployeeDTO> employeeModels = pagedResult.stream().map(EmployeeEntity -> {
			EmployeeDTO model = new EmployeeDTO();
			model.setId(EmployeeEntity.getId());
			model.setDesignationName(EmployeeEntity.getDesignation().getDesignation());
			model.setFirstName(EmployeeEntity.getFirstName());
			model.setLastName(EmployeeEntity.getLastName());
			model.setEmail(EmployeeEntity.getEmail());
			model.setContactNo(EmployeeEntity.getContactNo());
			model.setDesignationName(EmployeeEntity.getDesignation().getDesignation());
			model.setIsActive(EmployeeEntity.getIsActive());
			model.setIsApprove(EmployeeEntity.getIsApprove());
			if (!Objects.isNull(EmployeeEntity.getProfileImage())) {
				ProfileImageDTO profileImageDTO = new ProfileImageDTO();
				profileImageDTO.setId(EmployeeEntity.getProfileImage().getId());
				profileImageDTO.setImageName(EmployeeEntity.getProfileImage().getImageName());
				profileImageDTO.setImageurl(EmployeeEntity.getProfileImage().getImageurl());
				model.setProfileiamge(profileImageDTO);
			}
			return model;
		}).collect(Collectors.toList());

		response.put("data", employeeModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Transactional
	public boolean updateEmployeePolicies(EmployeeDTO employeedto, Long id) {
		boolean flag = Boolean.FALSE;
		List<Policy> plocylist = new ArrayList<>();
		if (employeeRepo.findById(id).isPresent()) {
			Employee employee = employeeRepo.findById(id).get();
			for (PolicyDTO policydto : employeedto.getPolicies()) {
				Policy policy = new Policy();
				policy.setId(policydto.getId());
				policy.setName(policydto.getName());
				policy.setDescription(policydto.getDescription());
				// BeanUtils.copyProperties(projectdto, project);
				plocylist.add(policy);
			}
			employee.setPolicies(plocylist);
			Employee savedEmployee = employeeRepo.save(employee);
			if (!Objects.isNull(savedEmployee))
				flag = Boolean.TRUE;
			logger.debug("Employee ID = " + id + " is updated with policies :: " + savedEmployee);
			return flag;
		} else {
			logger.error("Employee is not updated with policies:: " + id);
			return flag;
		}
	}

	@Override
	public boolean updateEmployeeProfileImage(Long id, MultipartFile image) {
		Optional<Employee> employeeobj = employeeRepo.findById(id);
		Employee employee = employeeobj.get();
		String employeename = employee.getFirstName() + employee.getLastName();
		boolean flag = s3serviceutil.deleteFileFromFolder(employee.getProfileImage().getImageName(), imagefolder);
		if (flag == true) {
			profileRepo.deleteById(employee.getProfileImageId());
		}
		flag = s3serviceutil.uploadFileInFolder(image, imagefolder, employeename);
		logger.debug("Employee ProfileImage updated into S3bucket :: " + employeename);
		ProfileImage profileImage = new ProfileImage();
		if (flag == true) {
			profileImage.setImageName(employeename);
			profileImage.setImageurl(s3serviceutil.generateFileUrl(employeename, imagefolder));
			// add create and updated by

		}
		ProfileImage pi = profileRepo.save(profileImage);
		employee.setProfileImageId(pi.getId());
		employeeRepo.save(employee);
		logger.debug("Employee ProfileImage details updated into database :: " + employeename);
		return true;

	}

	@Override
	public List<EmployeeComIDBranchID> getEmployeeDetails(Long companyId, Long branchId) {
		List<Employee> findByCompanyIdAndBranchId = employeeRepo.findByCompanyIdAndBranchId(companyId, branchId);
		List<EmployeeComIDBranchID> lis1 = new ArrayList<EmployeeComIDBranchID>();
		EmployeeComIDBranchID emp = new EmployeeComIDBranchID();
		for (Employee employee : findByCompanyIdAndBranchId) {
			emp.setId(employee.getId());
			emp.setFirstName(employee.getFirstName());
			emp.setLastName(employee.getLastName());
			emp.setEmail(employee.getEmail());
			emp.setContactNo(employee.getContactNo());
			lis1.add(emp);
		}
		return lis1;

	}
	
	@Override
	public List<EmployeeDTO> listOfEmployee() {
		List<Employee> allBranch = employeeRepo.findAll();
		List<EmployeeDTO> models = allBranch.stream().map(entity -> {
			EmployeeDTO model = new EmployeeDTO();
			model.setId(entity.getId());
			model.setFirstName(entity.getFirstName());
			model.setLastName(entity.getLastName());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

}
