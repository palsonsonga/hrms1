package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.EmployeeComIDBranchID;
import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.entity.Employee;



public interface EmployeeService {


	public EmployeeDTO getById(Long id);

	//deactivate and approval
	public boolean updateEmployeeByStatus(Long id , String status);

	public List<Employee> appliedList();

	public Integer saveEmployee(EmployeeDTO employee, MultipartFile[] files, MultipartFile image);

	public EmployeeDTO getFilesByEmployeeId(Long id);

	public EmployeeDTO getEmployeeById(Long id);

	/* public List<EmployeeDTO> employeeList(); */

	public boolean updateEmplyee(Long id,EmployeeDTO model, MultipartFile[] files,MultipartFile image);

	public Employee approveById(Long id);

	public boolean updateEmployeeProject(EmployeeDTO model, Long id);

	public boolean deleteEmployeeFile(Long id, Long fileId);

	public boolean AddResourcetoEmployee(EmployeeDTO model, Long id);

	public Map<String, Object> getAllEmployeePage(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public boolean updateEmployeePolicies(EmployeeDTO model, Long id);

	public boolean deleteEmployeeProfileImage(Long fileId);

	public boolean updateEmployeeProfileImage(Long id, MultipartFile image);
	
	public List<EmployeeComIDBranchID> getEmployeeDetails(Long companyId,Long branchId);

	public List<EmployeeDTO> listOfEmployee();
}
