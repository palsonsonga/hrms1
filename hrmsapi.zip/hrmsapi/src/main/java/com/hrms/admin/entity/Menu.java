package com.hrms.admin.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="MENU")
public class Menu {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "MENU_ID")
	private Long menuId;
	
	@Column(name = "MENU_TITLE")
	private String menuTitle;
	
	@Column(name = "MENU_PATH")
	private String menuPath;
	
	@Column(name = "MENU_ICON")
	private String menuIcon;
	
	@Column(name = "IS_PARENT")
	private Long isParent;
	
	@Column(name = "PARENT_ID")
	private Long parentId;

	public Long getMenuId() {
		return menuId;
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getMenuTitle() {
		return menuTitle;
	}

	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public String getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}

	public Long getIsParent() {
		return isParent;
	}

	public void setIsParent(Long isParent) {
		this.isParent = isParent;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public Menu(Long menuId, String menuTitle, String menuPath, String menuIcon, Long isParent, Long parentId) {
		super();
		this.menuId = menuId;
		this.menuTitle = menuTitle;
		this.menuPath = menuPath;
		this.menuIcon = menuIcon;
		this.isParent = isParent;
		this.parentId = parentId;
	}

	public Menu() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Menu [menuId=" + menuId + ", menuTitle=" + menuTitle + ", menuPath=" + menuPath + ", menuIcon="
				+ menuIcon + ", isParent=" + isParent + ", parentId=" + parentId + "]";
	}
	
	

}
