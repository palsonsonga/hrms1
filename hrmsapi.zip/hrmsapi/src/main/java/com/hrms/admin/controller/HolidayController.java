package com.hrms.admin.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.HolidayDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.HolidayNotFoundExceptions;
import com.hrms.admin.service.HolidayService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for Holiday Record
 * 
 * @author {Praveen Kumar}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/holiday")
public class HolidayController {

	private static final Logger logger = LoggerFactory.getLogger(HolidayController.class);

	@Autowired
	private HolidayService service;

	/**
	 * Returns status code when new Holiday is created
	 * 
	 * @param model - New Holiday data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody HolidayDTO model) {
		try {
		 service.save(model);
			logger.debug("Holiday Added :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Holiday :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns status code when existing Holiday data is updated
	 * 
	 * @param model - new Holiday data
	 * @param id    - Holiday Id
	 * @return - ResponseEntity
	 */

@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody HolidayDTO model, @PathVariable Long id) {
		try {
			service.updateHoliday(model, id);
			logger.debug("Holiday ID = " + id + " is updated :: " + model);
			
				return new ResponseEntity<Response>(
						new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			
		} catch (Exception e) {
			logger.error("Error while updating Holiday :: ");
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns Holiday and status code when Holiday data is available by id
	 * 
	 * @param id - Holiday Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<HolidayDTO> getById(@PathVariable Long id) {

		try {
			HolidayDTO holidayById = service.getById(id);
			logger.debug("Holiday fond with ID = " + id + " " + holidayById);
			return new ResponseEntity<HolidayDTO>(holidayById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Holiday by Id :: " + id);
			throw new HolidayNotFoundExceptions("Holiday");
		}
	}

	/**
	 * Returns Holiday data and status code when Holiday data is available by name
	 * 
	 * @param name - Holiday name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<HolidayDTO> getByName(@PathVariable String name) {

		try {
			HolidayDTO holidayByName = service.getByName(name);
			logger.debug("Holiday fond with Name = " + name + " " + holidayByName);
			return new ResponseEntity<HolidayDTO>(holidayByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Holiday by name :: " + name);
			throw new HolidayNotFoundExceptions(name + " not found");
		}

	}

	/**
	 * Returns status code when Holiday data is deleted
	 * 
	 * @param id - Holiday id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			HolidayDTO holiday = service.getById(id);

			service.deleteHoliday(id);
			logger.debug("Holiday record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(holiday.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Holiday not exist ");
			System.out.println(e);
			return new ResponseEntity<Response>(
					new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	
	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
	    return service.getAllHoliday(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
}