package com.hrms.admin.service.impl;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.dto.EmployeeDTO;
import com.hrms.admin.dto.ProjectDTO;
import com.hrms.admin.entity.Employee;
import com.hrms.admin.entity.Project;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.service.ProjectService;



/**
 * Contains method to perform DB operation on Project Record
 * @author {MD Atif}
 *
 */


@Service
public class ProjectServiceImpl implements ProjectService {

	private static Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

	@Autowired
	private ProjectRepository repo;


	/**
	 * Returns true when new Project is store in database
	 * 
	 * @param model - new project data
	 * @return - boolean
	 */

	@Override
	public boolean save(ProjectDTO model) {
		boolean flag = Boolean.FALSE;
		// null check
		if (model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate checking for Project Name Optional<Project> findByName =
		 * repo.findByName(model.getName()); if(findByName.isPresent()) { Project
		 * project = findByName.get(); if(project.getName().equals(model.getName())) {
		 * flag = Boolean.FALSE; return flag; } }
		 */

		Project entity = new Project();
		BeanUtils.copyProperties(model, entity);
		// setting values
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setCompanyId(model.getCompanyId());
		Project d = repo.save(entity);
		if (!Objects.isNull(d)) {
			flag = Boolean.TRUE;
			logger.debug("Project Added into database :: " + entity);
		}else {
			flag = Boolean.FALSE;
		}
		return flag;
	}

	/**
	 * Returns All Project data when project data is available in database
	 * @return - List of Project
	 */
	@Override
	public List<ProjectDTO> getAllProject() {

		List<Project> allProject = repo.findAll();
		List<ProjectDTO> models = allProject.stream().map(entity -> {
			ProjectDTO model = new ProjectDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			model.setDescription(entity.getDescription());
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns Project data when project data is available in database by id
	 * @param id - project Id
	 * @return - ProjectResponse
	 */
	@Override
	public ProjectDTO getById(Long id) {
		Optional<Project> optionalEntity = repo.findById(id);
		Project entity = optionalEntity.get();
		ProjectDTO model = new ProjectDTO();
		model.setId(entity.getId());
		model.setName(entity.getName());
		model.setDescription(entity.getDescription());
		model.setCompanyId(entity.getCompanyId());
		model.setCompanyName(entity.getCompany().getName());
		//BeanUtils.copyProperties(projectEntity, model);
		logger.debug("Project found with ID = " + id + " " + entity);
		return model;
	}


	/**
	 * Returns true when project data is deleted from database by id
	 * @param id - project id
	 * @return - boolean
	 */
	@Override
	public boolean deleteProject(Long id) {
		repo.deleteById(id);
		logger.debug(" project record is deleted from database ");
		return true;

	}

	/**
	 * Returns project data when Project data is available in database by name
	 * @param name - project name
	 * @return - Project
	 */

	@Override
	public ProjectDTO getByName(String name) {
		Optional<Project> findByname = repo.findByName(name);
		Project project = findByname.get();
		ProjectDTO model = new ProjectDTO();
		BeanUtils.copyProperties(project, model);
		logger.debug("Project found with Name = " + name + " " + project);
		return model;
	}


	/**
	 * Returns true when existing project data is store in database
	 * 
	 * @param model - new project data
	 * @param id - project Id
	 * @return - boolean
	 */

	@Override
	public boolean updateProject(ProjectDTO model, Long id) {
		boolean flag = Boolean.FALSE;
		logger.info("insert into updateDesignationById method in ProjectServiceImpl class ");

		// null check
		if (model.getName().equals(null)) {
			flag = Boolean.FALSE;
			return flag;
		}
		/*
		 * // duplicate checking for Project Name Optional<Project> findByName =
		 * repo.findByName(model.getName()); if(findByName.isPresent()) { Project
		 * project = findByName.get(); if(project.getName().equals(model.getName())) {
		 * flag = Boolean.FALSE; return flag; } }
		 */

		Optional<Project> findById = repo.findById(id);
		if (findById.isPresent()) {
			Project oldProject = findById.get();
			oldProject.setId(id);
			oldProject.setName(model.getName());
			oldProject.setDescription(model.getDescription());
			oldProject.setCompanyId(model.getCompanyId());
			Project d = repo.save(oldProject);
			if (!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Project ID = " + id + " is updated in to database :: " + oldProject);
			return flag;
		} else {
			logger.error("Project is not available in to database with ID= " + id);
			return flag;
		}
	}
	

	public static Map<String, Object> mapData(Page<Project> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<ProjectDTO> projectModels = pagedResult.stream().map(entity -> { 
			ProjectDTO model =	new ProjectDTO();
			model.setId(entity.getId());
			model.setName(entity.getName());
			return	model;}).collect(Collectors.toList());

		response.put("data", projectModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override
	public ProjectDTO findAllEmployeeByProjId(Long id) {
		if(repo.findById(id).isPresent()) {
			Project project = repo.findById(id).get();
			ProjectDTO projectDTO = new ProjectDTO();
			projectDTO.setId(project.getId());
			projectDTO.setDescription(project.getDescription());
			projectDTO.setName(project.getName());
			List<EmployeeDTO> list=new ArrayList<>();
			for(Employee employee : project.getEmployee()) {
				EmployeeDTO employeedto = new EmployeeDTO();
				employeedto.setId(employee.getId());
				employeedto.setFirstName(employee.getFirstName());
				employeedto.setLastName(employee.getLastName());
				list.add(employeedto);
			}		   
			projectDTO.setEmployeeDtoList(list);
			return projectDTO;	
		}
		return null;
	}

	@Override
	public Map<String, Object> getAllProject(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {


		Pageable paging = null;

		Page<Project> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = repo.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
}


