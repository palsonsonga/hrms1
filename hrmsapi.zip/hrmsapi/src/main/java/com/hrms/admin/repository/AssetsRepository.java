package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Assets;

public interface AssetsRepository extends JpaRepository<Assets, Long> {

	Assets findByname(String name);

}
