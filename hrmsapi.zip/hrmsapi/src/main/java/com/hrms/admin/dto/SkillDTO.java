package com.hrms.admin.dto;

public class SkillDTO {
	
	private Long id;
	private String skillSet;
	private String description;
	private Long companyId;
	private String companyName;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public SkillDTO() {
		
	}
	public SkillDTO(Long id, String skillSet, String description) {
		super();
		this.id = id;
		this.skillSet = skillSet;
		this.description = description;
	}
	public Long getCompanyId() {
		return companyId;
	}
	public void setCompanyId(Long companyId) {
		this.companyId = companyId;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	

}
