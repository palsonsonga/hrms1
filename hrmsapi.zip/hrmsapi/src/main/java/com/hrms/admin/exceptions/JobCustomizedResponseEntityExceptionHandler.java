package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hrms.admin.dto.Response;
import com.hrms.admin.util.Constants;

@ControllerAdvice
@RestController
public class JobCustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(Exception.class)
  public final ResponseEntity<Response> handleAllExceptions(Exception ex, WebRequest request) {
	  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(JobNotCreatedExceptions.class)
  public final ResponseEntity<JobExceptionResponse> handleDepartmentNotFoundException(JobNotFoundException ex, WebRequest request) {
    JobExceptionResponse jobExceptionResponse = new JobExceptionResponse(new Date(), ex.getMessage(),
        request.getDescription(false));
    return new ResponseEntity<>(jobExceptionResponse, HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(JobNotFoundException.class)
  public final ResponseEntity<Response> handleDepartmentNotCreatedException(JobNotCreatedExceptions ex) {
	  return new ResponseEntity<Response>(new Response(
			  ex.getMessage()+" "+Constants.INSERT_FAIL,
			  Constants.FALSE),
			  HttpStatus.BAD_REQUEST);
  }
}