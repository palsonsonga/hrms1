package com.hrms.admin.exceptions;

public class EmpLeaveIdNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public EmpLeaveIdNotFoundException(String message) {
		super(message);
	}

}
