package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.exceptions.PolicyNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.PolicyService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Policy Record
 * 
 * @author {Suresh}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/policy")
public class PolicyController {

	private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);

	@Autowired
	PolicyService policyService;

	/**
	 * Returns status code when new Policy is created
	 * 
	 * @param model - new policy data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestPart String policy,@RequestPart MultipartFile file) {
		try {
			ObjectMapper mapper = new ObjectMapper();
			PolicyDTO policydto = mapper.readValue(policy, PolicyDTO.class);
			boolean save = policyService.save(policydto,file);
			if(save==false) {
				logger.error("Duplicate policy added");
				return new ResponseEntity<Response>(new Response("Policy " + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}else {
				logger.info("Policy Added :: " + policydto);
				return new ResponseEntity<Response>(
						new Response("Policy " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error(" new Policy not created");
			return new ResponseEntity<Response>(new Response("Policy " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.CREATED);
		}
	}


	/**
	 * Returns All Policy data when policy data is available
	 * 
	 * @return - List of Policy
	 */
	
	/*
	 * @GetMapping public Map<String, Object> getAll(@RequestParam(defaultValue =
	 * "0") Integer pageIndex,
	 * 
	 * @RequestParam(defaultValue = "5") Integer pageSize) { // public
	 * List<PolicyResponse> getAll() { // // List<PolicyResponse> allPolicy =
	 * policyService.getAllPolicy(); // if (allPolicy != null) { //
	 * logger.debug("Found " + allPolicy.size() + " Policy"); // return allPolicy;
	 * // } // logger.error("error while getting all Policy Record"); // throw new
	 * PolicyNotFoundException("Policy Not Found"); return
	 * policyService.getAllPolicy(pageIndex, pageSize, "name");
	 * 
	 * }
	 */

	/**
	 * Returns Policy and status code when policy data is available by id
	 * 
	 * @param id - Policy Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<PolicyDTO> getById(@PathVariable Long id) {
		try {
			PolicyDTO policyById = policyService.getPolicyById(id);
			logger.debug("Policy fond with ID = " + id + " " + policyById);
			return new ResponseEntity<PolicyDTO>(policyById, HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while getting Policy by Id :: " + id);
			throw new PolicyNotFoundException("Policy");
		}

	}

	/**
	 * Returns status code when existing Policy data is updated
	 * 
	 * @param model - new Policy data
	 * @param id    - Policy Id
	 * @return - ResponseEntity
	 * @throws JsonProcessingException 
	 * @throws JsonMappingException 
	 */
	@PutMapping(path = "/{id}")
	public ResponseEntity<Response> update( @PathVariable Long id,@RequestPart String policy,@RequestPart MultipartFile file) throws JsonMappingException, JsonProcessingException {
		try {
			ObjectMapper mapper = new ObjectMapper();
			PolicyDTO policydto = mapper.readValue(policy, PolicyDTO.class);
			boolean updatePolicy = policyService.update(id,policydto,file);
			if (updatePolicy==false) {
				logger.error("duplicate updating Policy :: " + policydto);
				return new ResponseEntity<Response>(
						new Response("Policy " + " " + Constants.ALREADY_EXIST, Constants.FALSE), HttpStatus.BAD_REQUEST);
				
			} else {
				logger.debug("Policy is updated ");
				return new ResponseEntity<Response>(
						new Response(policydto.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
			}
		} catch (Exception e) {
			logger.error("Error while updating Policy");
			return new ResponseEntity<Response>(
					new Response("Policy " + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
	}


	/**
	 * Returns Policy data and status code when policy data is available by name
	 * 
	 * @param name - policy name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<PolicyDTO> getByName(@PathVariable String name) {
		try {
			PolicyDTO policyByName = policyService.getPolicyByName(name);
			logger.debug("Policy fond with Name = " + name + " " + policyByName);
			return new ResponseEntity<PolicyDTO>(policyByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Policy by name :: " + name);
			throw new PolicyNotFoundException("policy not found");
		}
	}

	/**
	 * Returns status code when policy data is deleted
	 * 
	 * @param id - policy id
	 * @return - ResponseEntity
	 */

@DeleteMapping(path = "/{id}")
	public ResponseEntity<Response> deletePolicy(@PathVariable Long id) {
		try {
		PolicyDTO policy = policyService.getPolicyById(id);
	
			policyService.deletePolicy(id);
			logger.debug("Policy record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(policy.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Policy not exist ");
			return new ResponseEntity<Response>(new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
	    return policyService.getAllPolicy(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
	
	@GetMapping("/list")
	public ResponseEntity<List<PolicyDTO>> allPolicy() {

		List<PolicyDTO> allPolicys = policyService.getAllPolicy();
		if (allPolicys != null) {
			logger.debug("Found " + allPolicys.size() + " Policy");
			return new ResponseEntity<List<PolicyDTO>>(allPolicys, HttpStatus.OK);
		}
		logger.error("error while getting all Policys Record");
		throw new PolicyNotFoundException("Policys");

	}
}
