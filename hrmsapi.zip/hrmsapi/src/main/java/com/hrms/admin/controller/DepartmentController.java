package com.hrms.admin.controller;


import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.DepartmentDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.CompanyNotFoundExceptions;
import com.hrms.admin.exceptions.DepartmentNotFoundExceptions;
import com.hrms.admin.service.DepartmentService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Department Record
 * 
 * @author {Prabhat}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/department")
public class DepartmentController {

	private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	@Autowired
	private DepartmentService service;

	/**
	 * Returns status code when new department is created
	 * 
	 * @param model - new department data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody DepartmentDTO model) {
		try {
			service.save(model);
			logger.debug("Department Added :: " + model);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);

		}catch (Exception e) {
			logger.error("Error while adding Department :: ", e);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}

	/**
	 * Returns status code when existing department data is updated
	 * 
	 * @param model - new department data
	 * @param id    - depatment Id
	 * @return - ResponseEntity
	 */

	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody DepartmentDTO model, @PathVariable Long id) {

		try{
			service.updateDepartment(model, id);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		}		catch (Exception e) {
			logger.error("Error while updating Designation :: " + id);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);

		}
	}

	/**
	 * Returns Department and status code when department data is available by id
	 * 
	 * @param id - depatment Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<DepartmentDTO> getById(@PathVariable Long id) {
		try {
			DepartmentDTO departmentById = service.getById(id);
			logger.debug("Department fond with ID = " + id + " " + departmentById);
			return new ResponseEntity<DepartmentDTO>(departmentById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Department by Id :: " + id);
			throw new DepartmentNotFoundExceptions("Department");
		}
	}

	/**
	 * Returns Department data and status code when department data is available by
	 * name
	 * 
	 * @param name - depatment name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<DepartmentDTO> getByName(@PathVariable String name) {

		try {
			DepartmentDTO departmentByName = service.getByName(name);
			logger.debug("Department fond with Name = " + name + " " + departmentByName);
			return new ResponseEntity<DepartmentDTO>(departmentByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Department by name :: " + name);
			throw new DepartmentNotFoundExceptions("Department not found");
		}

	}


	/**
	 * Returns status code when department data is deleted
	 * 
	 * @param id - depatment id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
		DepartmentDTO department = service.getById(id);
		
				service.deleteDepartment(id);
				logger.debug("Department record is Deleted with id " + id);
				return new ResponseEntity<Response>(new Response(department.getName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
				logger.debug("Department not exist ");
				return new ResponseEntity<Response>(new Response("No value present " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
			}
	}

	@GetMapping("/list")
	public ResponseEntity<List<DepartmentDTO>> departments() {

		List<DepartmentDTO> allDepartment = service.AllDepartment();
		if (allDepartment != null) {
			logger.debug("Found " + allDepartment.size() + " Company");
			return new ResponseEntity<List<DepartmentDTO>>(allDepartment,HttpStatus.OK);
		}
		logger.error("error while getting all Company Record");
		throw new CompanyNotFoundExceptions("Company");
	}

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllDepartment(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
	
	@GetMapping("/list/{id}")
	public ResponseEntity<List<DepartmentDTO>> allDepartments(@PathVariable long id) {
		List<DepartmentDTO> allBranchs = service.getBranchById(id);
		if (allBranchs != null) {
			logger.debug("Found " + allBranchs.size() + " Branch");
			return new ResponseEntity<List<DepartmentDTO>>(allBranchs, HttpStatus.OK);
		}
		throw new DepartmentNotFoundExceptions("Departments not found");

	}
}