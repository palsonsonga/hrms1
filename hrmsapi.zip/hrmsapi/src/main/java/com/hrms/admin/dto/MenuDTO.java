package com.hrms.admin.dto;

import java.util.ArrayList;
import java.util.List;

public class MenuDTO {

	private Long menuId;

	private String menuTitle;
	
	List<String> menuTtle=new ArrayList<String>();

	private String menuPath;

	private String menuIcon;

	private Long isParent;

	private Long parentId;

	public Long getMenuId() {
		return menuId;
	}

	public MenuDTO() {
		super();
		
	}

	public void setMenuId(Long menuId) {
		this.menuId = menuId;
	}

	public String getMenuTitle() {
		return menuTitle;
	}

	public void setMenuTitle(String menuTitle) {
		this.menuTitle = menuTitle;
	}

	public String getMenuPath() {
		return menuPath;
	}

	public void setMenuPath(String menuPath) {
		this.menuPath = menuPath;
	}

	public String getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}

	public Long getIsParent() {
		return isParent;
	}

	public void setIsParent(Long isParent) {
		this.isParent = isParent;
	}

	public Long getParentId() {
		return parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public MenuDTO(Long menuId, String menuTitle, List<String> menuTtle, String menuPath, String menuIcon,
			Long isParent, Long parentId) {
		super();
		this.menuId = menuId;
		this.menuTitle = menuTitle;
		this.menuTtle = menuTtle;
		this.menuPath = menuPath;
		this.menuIcon = menuIcon;
		this.isParent = isParent;
		this.parentId = parentId;
	}
	
	


}
