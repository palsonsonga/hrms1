package com.hrms.admin.controller;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.BranchDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.exceptions.BranchNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.service.BranchService;
import com.hrms.admin.util.Constants;

@RestController
@CrossOrigin
@RequestMapping("/admin/branch")
public class BranchController {

	private static final Logger logger = LoggerFactory.getLogger(BranchController.class);

	@Autowired
	private BranchService service;

	//	@Autowired
	//	private  BranchUtil util;
	//	

	/**
	 * Returns status code when new branch is created
	 * 
	 * @param model - new branch data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody BranchDTO model) {
		try {
			boolean save = service.save(model);
			if(save==false) {
				logger.error("Duplicate  branch name");
				return new ResponseEntity<Response>(new Response("Branch " + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			}else {
				
				logger.debug("Branch Added :: " + model);
				return new ResponseEntity<Response>(
						new Response("Branch " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
			}

		} catch (Exception e) {
			logger.error("Error while adding branch :: ", e);
			return new ResponseEntity<Response>(new Response("Branch " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}


	/**
	 * Returns All Branch data when branch data is available
	 * 
	 * @return - List of BranchResponse
	 */

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllAttendnace(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}

	/**
	 * Returns branch and status code when branch data is available by id
	 * 
	 * @param id - branch Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<BranchDTO> getById(@PathVariable Long id) {

		try {
			BranchDTO branchById = service.getById((id));
			logger.debug("Branch fond with ID = " + id + " " + branchById);
			return new ResponseEntity<BranchDTO>(branchById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Branch by Id :: " + id);
			throw new BranchNotFoundException("Branch");
		}
	}

	/**
	 * Returns status code when existing branch data is updated
	 * 
	 * @param model - new branch data
	 * @param id    - branch Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody BranchDTO model, @PathVariable Long id) {

		try {
			boolean updateDepartment = service.updateBranch(model, id);
			if (updateDepartment==false) {
				logger.error("Duplicate Data" + model);
				return new ResponseEntity<Response>(
						new Response(model.getName() + " " + Constants.ALREADY_EXIST, Constants.FALSE),
						HttpStatus.BAD_REQUEST);
			} else {
				logger.error("Branch Updated");
				return new ResponseEntity<Response>(
						new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
						HttpStatus.OK);
			}
		} catch (Exception e) {
			{
				logger.error("Error while updating Branch :: ");
				return new ResponseEntity<Response>(
						new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
	}

	/**
	 * Returns status code when branch data is deleted
	 * 
	 * @param id - branch id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			BranchDTO branch = service.getById(id);

			service.deleteBranch(id);
			logger.debug("Branch record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(branch.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Branch not exist ");
			return new ResponseEntity<Response>(new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}
		
	@GetMapping("/list/{id}")
	public ResponseEntity<List<BranchDTO>> allBranch(@PathVariable long id) {
		List<BranchDTO> allBranchs = service.listOfBranch(id);
		if (allBranchs != null) {
			logger.debug("Found " + allBranchs.size() + " Branch");
			return new ResponseEntity<List<BranchDTO>>(allBranchs, HttpStatus.OK);
		}
		throw new BranchNotFoundException("Branch is not available for Id :");

	}
}
