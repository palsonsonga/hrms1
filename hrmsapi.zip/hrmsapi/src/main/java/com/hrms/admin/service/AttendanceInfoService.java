package com.hrms.admin.service;

import java.text.ParseException;
import java.util.List;

import com.hrms.admin.dto.AttPercentageBarChartDTO;
import com.hrms.admin.dto.AttPercentagePieChartDto;
import com.hrms.admin.entity.AttendanceInfo;

public interface AttendanceInfoService {

	public Long getAttendancePercentageDayBase(Long emp_id, String date);

	public Long getAttendancePercentageDateBase(Long emp_id, String fromDate, String toDate);

	public Long getAllEmpAttendancePercentageDayBase(String date);

	public Long getAllAttendancePercentageDateBase(String fromDate, String toDate);

	public boolean save(AttendanceInfo model) throws ParseException;

	public List<AttendanceInfo> getAllAttendancePercentage();

	public List<AttendanceInfo> getAllAttendenceDetails();

	public List<AttendanceInfo> getAllAttendenceByEmpId(Long empid);

	public List<AttendanceInfo> getAllPresentEmployeeList();

	public List<AttendanceInfo> getAllAbsentEmployeeList();

	public  AttPercentagePieChartDto AttendancePercentagePieChart();

	public AttPercentageBarChartDTO AttendancePercentageBarChart();
}
