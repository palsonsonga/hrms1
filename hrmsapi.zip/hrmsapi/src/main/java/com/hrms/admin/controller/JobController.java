package com.hrms.admin.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.dto.JobDTO;
import com.hrms.admin.dto.PaginationDTO;
import com.hrms.admin.dto.Response;
import com.hrms.admin.exceptions.JobNotFoundException;
import com.hrms.admin.service.impl.JobServiceImpl;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for Department Record
 * 
 * @author {Nikhil}
 *
 */
@RestController
@RequestMapping("/admin/job")
@CrossOrigin
public class JobController {

	private static final Logger logger = LoggerFactory.getLogger(JobController.class);

	@Autowired
	JobServiceImpl service;

	/**
	 * Returns status code when new job is created
	 * 
	 * @param model - new job data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody JobDTO model) {
		try {
			service.save(model);

			logger.debug("Job Added :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_SUCCESS, Constants.TRUE),
					HttpStatus.CREATED);

		}catch (Exception e) {
			logger.error("Error while adding Job :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}


	/**
	 * Returns status code when existing job data is updated
	 * 
	 * @param model - new job data
	 * @param id    - job Id
	 * @return - ResponseEntity
	 */

	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody JobDTO model, @PathVariable Long id) {
		try{
			service.updateJob(model, id);
			logger.debug("Job ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}  catch(Exception e){
			logger.error("Error while updating Job :: ");
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns Department and status code when job data is available by id
	 * 
	 * @param id - job Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<JobDTO> getById(@PathVariable Long id) {

		try {
			JobDTO jobById = service.getById(id);
			logger.debug("Job fond with ID = " + id + " " + jobById);
			return new ResponseEntity<JobDTO>(jobById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Job by Id :: " + id);
			throw new JobNotFoundException("Job not found");
		}
	}

	/**
	 * Returns All Job data when job data is available
	 * 
	 * @return - List of JobtModel
	 */


	/**
	 * Returns status code when department data is deleted
	 * 
	 * @param id - job id
	 * @return - ResponseEntity
	 */

	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		try {
			JobDTO job = service.getById(id);

			service.deleteJob(id);
			logger.debug("Job record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(job.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} catch (Exception e) {
			logger.debug("Job not exist ");
			return new ResponseEntity<Response>(new Response("No value present " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}
	//paging

	@PostMapping("/page")
	public Map<String, Object> getAll(@RequestBody PaginationDTO pagingDto) {
		return service.getAllJob(pagingDto.getPageIndex(), pagingDto.getPageSize(), pagingDto.getSortBy(),pagingDto.getSearchKey(),pagingDto.getOrderBy());
	}
}
