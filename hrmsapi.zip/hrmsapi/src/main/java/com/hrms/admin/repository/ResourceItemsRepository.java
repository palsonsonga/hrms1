package com.hrms.admin.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.ResourceItems;

public interface ResourceItemsRepository extends JpaRepository<ResourceItems, Long> {
	//public ResourceItems findByType(String type);
	public ResourceItems findByid(Long id);
	public List<ResourceItems> findByEmployeeId(Long id);
}
