package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.BranchDTO;

public interface BranchService {

	public boolean save(BranchDTO branch);

	/* public List<BranchResponse> getAllBranch(); */

	public BranchDTO getById(Long id);

	public boolean deleteBranch(Long id);

	public boolean updateBranch(BranchDTO model, Long id);

	public Map<String, Object> getAllAttendnace(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	public List<BranchDTO> listOfBranch(Long id);
}
