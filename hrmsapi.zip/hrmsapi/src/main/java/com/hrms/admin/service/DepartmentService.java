package com.hrms.admin.service;

import java.util.List;
import java.util.Map;

import com.hrms.admin.dto.DepartmentDTO;

public interface DepartmentService {

	public boolean save(DepartmentDTO model);

//	public Map<String, Object> getAllDepartment(Integer pageIndex, Integer pageSize, String sortBy);
	
//	 Map<String, Object> getAllDepartment(Integer pageNo, Integer pageSize, String sortBy);

	public DepartmentDTO getById(Long id);
	
	public DepartmentDTO getByName(String name);

	public boolean deleteDepartment(Long id);

	public boolean updateDepartment(DepartmentDTO model, Long id);

	 public List<DepartmentDTO> AllDepartment();
	 
	 public Map<String, Object> getAllDepartment(Integer pageIndex, Integer pageSize, String sortBy,String searchKey, String orderBy);

	 public List<DepartmentDTO> getBranchById(Long id);
}
