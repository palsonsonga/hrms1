package com.hrms.admin.configuration;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.ItemProcessor;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.LineMapper;
import org.springframework.batch.item.file.mapping.BeanWrapperFieldSetMapper;
import org.springframework.batch.item.file.mapping.DefaultLineMapper;
import org.springframework.batch.item.file.transform.DelimitedLineTokenizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.FileSystemResource;

import com.hrms.admin.entity.AttendanceInfo;
@Configuration
@EnableBatchProcessing
public class BatchConfiguration {
	@Bean
    public Job job(JobBuilderFactory jobBuilderFactory,
                   StepBuilderFactory stepBuilderFactory,
                   ItemReader<AttendanceInfo> itemReader,
                   ItemProcessor<AttendanceInfo, AttendanceInfo> itemProcessor,
                   ItemWriter<AttendanceInfo> itemWriter,TaskletStep taskletStep
    ) {

        Step step = stepBuilderFactory.get("ATTENDANCE-file-load")
                .<AttendanceInfo, AttendanceInfo>chunk(100)
                .reader(itemReader)
                .processor(itemProcessor)
                .writer(itemWriter)
                .build();
        Step step2 = stepBuilderFactory.get("step2")
				.tasklet(taskletStep)
				.build();


        return jobBuilderFactory.get("ATTENDANCE-Load")
                .incrementer(new RunIdIncrementer())
                .start(step)
                .next(step2)
                .build();
    }

    @Bean
    public FlatFileItemReader<AttendanceInfo> itemReader() {
        FlatFileItemReader<AttendanceInfo> flatFileItemReader = new FlatFileItemReader<>();
        flatFileItemReader.setResource(new FileSystemResource("uploads/Attendance.csv"));
        flatFileItemReader.setName("CSV-Reader");
        flatFileItemReader.setLinesToSkip(1);
        flatFileItemReader.setLineMapper(lineMapper());
        return flatFileItemReader;
    }

    @Bean
    public LineMapper<AttendanceInfo> lineMapper() {

        DefaultLineMapper<AttendanceInfo> defaultLineMapper = new DefaultLineMapper<>();
        DelimitedLineTokenizer lineTokenizer = new DelimitedLineTokenizer();

        lineTokenizer.setDelimiter(",");
        lineTokenizer.setStrict(false);
        lineTokenizer.setNames(new String[]{"empId", "companyName", "branch", "inTime","outTime","date"});

        BeanWrapperFieldSetMapper<AttendanceInfo> fieldSetMapper = new BeanWrapperFieldSetMapper<>();
        fieldSetMapper.setTargetType(AttendanceInfo.class);

        defaultLineMapper.setLineTokenizer(lineTokenizer);
        defaultLineMapper.setFieldSetMapper(fieldSetMapper);

        return defaultLineMapper;
    }
}
