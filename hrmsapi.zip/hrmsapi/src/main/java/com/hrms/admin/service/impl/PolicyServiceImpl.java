package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.hrms.admin.dto.PolicyDTO;
import com.hrms.admin.entity.Policy;
import com.hrms.admin.repository.PolicyRepository;
import com.hrms.admin.service.PolicyService;
import com.hrms.admin.util.S3ServiceUtil;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Suresh}
 *
 */
@Service
public class PolicyServiceImpl implements PolicyService {

	private static final Logger logger = LoggerFactory.getLogger(PolicyServiceImpl.class);

	@Autowired
	PolicyRepository policyRepository;

	@Autowired
	S3ServiceUtil s3ServiceUtil;

	@Value("${aws.bucket.policyfolder}")
	private String foldername;

	@Value("${aws.bucket}")
	private String bucketName;

	@PostConstruct
	public void init(){
		String name=s3ServiceUtil.createFolder(foldername);
		logger.debug("folder created in s3 bucket ::"+"bucketName"+ "foldername ::"+name);
	}


	/**
	 * Returns All Policy data when Policy data is available in database
	 * 
	 * @return - List of PolicyResponse
	 */
	@Override
	public List<PolicyDTO> getAllPolicy() {

		List<Policy> allPolicy = policyRepository.findAll();
		List<PolicyDTO> models = allPolicy.stream().map(entity -> {
			PolicyDTO model = new PolicyDTO();
			
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;

	}

	/**
	 * Returns true when new Policy is store in database
	 * 
	 * @param model - new Policy data
	 * @return - boolean
	 */
	@Override
	public boolean save(PolicyDTO model,MultipartFile file) {
		boolean flag = Boolean.FALSE;
		// null check
				if(model.getName().equals(null) || model.equals(null)){
					flag = Boolean.FALSE;
					return flag;
				}
				
				/*
				 * //duplicate name check Optional<Policy> findByName =
				 * policyRepository.findByName(model.getName()); if(findByName.isPresent()) {
				 * Policy policy = findByName.get();
				 * if(policy.getName().equals(model.getName())) { flag = Boolean.FALSE; return
				 * flag; } }
				 */
		Policy entity = new Policy();
		flag=s3ServiceUtil.uploadFileInFolder(file, foldername,model.getName());
		if(flag==true) {
			entity.setName(model.getName());
			entity.setDescription(model.getDescription());
			entity.setCompanyId(model.getCompanyId());
			entity.setAttachmentLink(s3ServiceUtil.generateFileUrl(model.getName(), foldername));
		}
		Policy p = policyRepository.save(entity);
		if (!Objects.isNull(p))
			flag = Boolean.TRUE;
		logger.debug("Policy Added into database :: " + p);
		return flag;

	}

	/**
	 * Returns Policy data when Policy data is available in database by id
	 * 
	 * @param id - Id
	 * @return - PolicyResponse
	 */
	@Override
	public PolicyDTO getPolicyById(Long id) {
		Optional<Policy> optionalEntity = policyRepository.findById(id);
		Policy policyEntity = optionalEntity.get();
		PolicyDTO model = new PolicyDTO();
		model.setName(policyEntity.getName());
		model.setDescription(policyEntity.getDescription());
		model.setAttachmentLink(policyEntity.getAttachmentLink());
		model.setCompanyId(policyEntity.getCompanyId());
		model.setCompanyName(policyEntity.getCompany().getName());
		logger.debug("Policy found with ID = " + id + " " + policyEntity);
		return model;

	}

	/**
	 * Returns true when existing Policy data is store in database
	 * 
	 * @param model - new policy data
	 * @param id    - Policy Id
	 * @return - boolean
	 */
	@Override
	public boolean update(Long id, PolicyDTO policydto, MultipartFile file) {
		boolean flag = Boolean.FALSE;
		// null check
				if(policydto.getName().equals(null) || policydto.equals(null)){
					flag = Boolean.FALSE;
					return flag;
				}
				/*
				 * //duplicate name check Optional<Policy> findByName =
				 * policyRepository.findByName(policydto.getName()); if(findByName.isPresent())
				 * { Policy policy = findByName.get();
				 * if(policy.getName().equals(policydto.getName())) { flag = Boolean.FALSE;
				 * return flag; } }
				 */
		Optional<Policy> policy = policyRepository.findById(id);
		Policy oldPolicy = policy.get();
		if (policy.isPresent()) {
			flag=s3ServiceUtil.deleteFileFromFolder(oldPolicy.getName(), foldername);
			if(flag==true) {
				flag=s3ServiceUtil.uploadFileInFolder(file, foldername,policydto.getName());
			}
			if(flag==true) {
				oldPolicy.setId(id);
				oldPolicy.setName(policydto.getName());
				oldPolicy.setDescription(policydto.getName());
				oldPolicy.setAttachmentLink(s3ServiceUtil.generateFileUrl(policydto.getName(), foldername));
				oldPolicy.setCompanyId(policydto.getCompanyId());
			}
			Policy p = policyRepository.save(oldPolicy);
			if (!Objects.isNull(p))
				flag = Boolean.TRUE;
			logger.debug("Policy ID = " + id + " is updated in to database :: " + p);
			return flag;
		} else {
			logger.error("Policy is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns true when department data is deleted from database by id
	 * 
	 * @param id - depatment id
	 * @return - boolean
	 */
	@Override
	public boolean deletePolicy(Long id) {
		Optional<Policy> policyobj=policyRepository.findById(id);
		Policy policy=policyobj.get();
		boolean flag=s3ServiceUtil.deleteFileFromFolder(policy.getName(), foldername);
		if(flag==true) {
			policyRepository.deleteById(id);
		}
		logger.debug(" Policy record is deleted from database ");
		return true;
	}

	/**
	 * Returns Policy data when Policy data is available in database by name
	 * 
	 * @param name - Policy name
	 * @return - PolicyResponse
	 */
	@Override
	public PolicyDTO getPolicyByName(String name) {
		/*
		 * Policy findByPolicyName = policyRepository.findByName(name); PolicyDTO model
		 * = new PolicyDTO(); BeanUtils.copyProperties(findByPolicyName, model);
		 * logger.debug("Policy found with Name = " + name + " " + findByPolicyName);
		 */
		return null;
	}


	//paging

	/*
	 * @Override public Map<String, Object> getAllPolicy(Integer pageIndex, Integer
	 * pageSize, String sortBy) {
	 * 
	 * Pageable paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy));
	 * Page<Policy> pagedResult = policyRepository.findAll(paging);
	 * 
	 * if(pagedResult.hasContent()) { return mapData(pagedResult); } else { return
	 * new HashMap<String, Object>(); } }
	 */

	public static Map<String, Object> mapData(Page<Policy> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<PolicyDTO> policyModels = pagedResult.stream().map(policyEntity -> { 
			PolicyDTO model =	new PolicyDTO();
			model.setName(policyEntity.getName());
			model.setDescription(policyEntity.getDescription());
			model.setAttachmentLink(policyEntity.getAttachmentLink());
			return	model;}).collect(Collectors.toList());

		response.put("data", policyModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}

	@Override
	public Map<String, Object> getAllPolicy(Integer pageIndex, Integer pageSize, String sortBy, String searchKey,
			String orderBy) {
		Pageable paging = null;

		Page<Policy> pagedResult = null;

		if (orderBy.equalsIgnoreCase("asc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).ascending());
			//Page<Attendance> pagedResult = attRepo.findAll(paging);
			pagedResult = policyRepository.findAllSearchWithPagination(searchKey, paging);

		}else if (orderBy.equalsIgnoreCase("desc")) {
			paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy).descending());
			pagedResult = policyRepository.findAllSearchWithPagination(searchKey, paging);
		}
		if(pagedResult.hasContent()) {
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
}