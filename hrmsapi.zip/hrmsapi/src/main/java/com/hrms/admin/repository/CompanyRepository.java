package com.hrms.admin.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hrms.admin.entity.Company;


public interface CompanyRepository extends JpaRepository<Company, Long> {

	Page<Company> findAll(Pageable paging);
	
	@Query(value = "SELECT a FROM Company a WHERE  a.name LIKE %?1%")
	Page<Company> findAllSearchWithPagination(String searchKey,Pageable paging);
	
	public Optional<Company> findByEmail(String email);
	
	public Optional<Company> findByWebsite(String website);
}
