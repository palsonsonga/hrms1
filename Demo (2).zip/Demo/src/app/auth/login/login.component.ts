import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm = this.fb.group({
    username: ['', [Validators.required]],
    password: ['', [Validators.required, Validators.pattern('^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$')]]
  });

  constructor(private fb: FormBuilder,
    private _router: Router) {

    if (sessionStorage.getItem('user')) {
      alert("you have already logged in,  please logout if you want to login again")
      this._router.navigate([''])
    }
  }
  ngOnInit(): void {

  }

  gotolist() {
    if (this.loginForm.valid) {
      sessionStorage.setItem('user', this.loginForm.value.username)
      this._router.navigate(['']);
    }
  }
}
