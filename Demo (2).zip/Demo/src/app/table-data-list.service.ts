import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';

@Injectable({
  providedIn: 'root'
})
export class TableDataListService implements InMemoryDbService {

  constructor() { }
  createDb() {
    let tableData = [
      { id: 1, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 90 },
      {id:2, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:3, project: 'pro', budget: '$1255', status: 'pending', users:"arjun, john , sam", completion: 40 },
      {id:4, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:5, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
      {id:6, project: 'pro', budget: '$1255', status: 'pending', users: "arjun, john, sam", completion: 60 },
    ]

    return { tableData };
  }
}
