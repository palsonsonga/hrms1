import { Component, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';
import * as EventEmitter from 'events';

@Component({
  selector: 'app-top-nav',
  templateUrl: './top-nav.component.html',
  styleUrls: ['./top-nav.component.css']
})
export class TopNavComponent implements OnInit {
currentUser
  constructor(private router:Router) { }

  ngOnInit(): void {
   this.currentUser=sessionStorage.getItem('user')
  }

   
  logout(){ 
    sessionStorage.removeItem('user')
    this.router.navigate(['/login'])
  }
}
