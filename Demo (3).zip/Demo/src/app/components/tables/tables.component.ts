import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { TableService } from 'src/app/_services/table.service';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  action
  tableForm:FormGroup
  submitted
  data = new MatTableDataSource();
  currentUser
  pageIndex = 0;
  pageSize = 5;
  closeResult
  displayedColumns: string[] = ['Project', 'Budget', 'Status', 'Users', 'Completion', 'actions'];
  constructor(
    private _Service: TableService,
    private router:Router, private modalService: NgbModal,
  ) {}

  ngOnInit() {
this.tableForm = new FormGroup({
project: new FormControl('',[Validators.required]),
budget:new FormControl('',[Validators.required]),
status:new FormControl('',[Validators.required]),
users:new FormControl('',[Validators.required]),
completion:new FormControl('',[Validators.required]),
})
    this.loadAllData();
  }

  loadAllData() {
     this._Service.getTableDataList().subscribe(res =>{
       let list:any =res
    this.data = new MatTableDataSource(list)
    this.data.paginator = this.paginator;
    this.data.sort = this.sort;
     })
  }

  applyFilter(value) {
    this.data.filter = value.trim().toLowerCase()
  }
  getColor(val) {
    let num =parseInt(val)
    if (num >= 90) {
      return 'green'
    }
    else if (num >= 50) {
      return 'blue'
    }
    else return 'red'
  }

  onSubmit(){ 
    if(this.tableForm.valid){
      this.submitted = true;
      console.log(this.tableForm.value)
        this._Service.saveTableData(this.tableForm.value).subscribe(data => {
         // console.log(data);
        });
        this.loadAllData();
    }else{
      this.submitted = false;
    }
    this.tableForm.reset()
    this.modalService.dismissAll()
  }
  open(content ) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

}
