import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  subApiUrl = 'admin/company';
  
  constructor(private _http: HttpClientService) { }

  getCompanyList(params): Observable<any> {
    return this._http.post(this.subApiUrl+'/page',params);
  }

  saveCompany(params: any): Observable<any>{
    return this._http.post(this.subApiUrl , params);
  }

  getCompanyById(params:any): Observable<any>{
    return this._http.get(this.subApiUrl+'/'+params);
  }

  updateCompany(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl +'/'+ urlParams, params);
  }

  deleteCompany(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl +'/'+ params);
  }

  getCompaniesDropdown(): Observable<any>{
    return this._http.get(this.subApiUrl+'/list');
  }
}
