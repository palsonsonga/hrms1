import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class JobService {

  subApiUrl = 'admin/job';
  

  constructor(private _http: HttpClientService) { }

  getJobList(params: any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  getJobById(id: any): Observable<any>{
    return this._http.get(this.subApiUrl+'/'+id);
  }

  saveJob(params: any): Observable<any>{
    return this._http.post(this.subApiUrl , params);
  }

  updateJob(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + '/'+urlParams, params);
  }

  deleteJob(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params);
  }

}