import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveService {
  subApiUrl = 'employee/leave';
  constructor(private _http : HttpClientService) { }
  getAppliedLeaves(parmas:any) : Observable<any> {
    return this._http.post(this.subApiUrl+'/emp/page',parmas);
  }

  applyLeave(parmas:any) : Observable<any> {
    return this._http.post(this.subApiUrl,parmas);
  }

  getAllLeaves(): Observable<any> {
    return this._http.get(this.subApiUrl);
  }

  getTeamLeaves(parmas:any) : Observable<any> {
    return this._http.post(this.subApiUrl+'/team/page',parmas);
  }

  getManagersByEmployeeId(id:any): Observable<any> {
    return this._http.get(this.subApiUrl+'/mngr/'+id);
  }

  approveLeave(id:any,params:any): Observable<any> {
    return this._http.put(this.subApiUrl+"/approval/"+id,params);
  }
}
