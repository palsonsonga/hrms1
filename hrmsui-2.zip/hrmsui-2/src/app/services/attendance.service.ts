import { HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpClientService } from '../util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  subApiUrl = 'admin/attendance/uploadFile';
  subApiInfoUrl = 'admin/attendanceinfo';
  constructor(private _http : HttpClientService) { }

  getAttendanceSheet(parmas?:any){
    return this._http.post(this.subApiInfoUrl+'/page',parmas);
  }

  uploadAttendanceSheet(parmas?:any){
    return this._http.post(this.subApiUrl+'',parmas);
  }

  saveManualAttendance(parmas?:any){
    return this._http.post(this.subApiInfoUrl+'/save',parmas);
  }
}
