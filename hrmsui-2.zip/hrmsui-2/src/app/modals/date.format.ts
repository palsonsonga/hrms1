export const MY_FORMATS = {
  
    parse: {
      dateInput: ['l', 'll'],
    },
    display: {
      dateInput: 'll',
      monthYearLabel: 'MMM YYYY',
      dateA11yLabel: 'll',
      monthYearA11yLabel: 'MMMM YYYY',
    },
  };