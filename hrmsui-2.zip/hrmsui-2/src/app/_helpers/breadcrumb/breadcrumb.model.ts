import {Params} from '@angular/router';
export interface TBreadcrumb {
    label: string;
    params: Params;
    url: string;
}
