import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { Chart } from 'chart.js';
import * as Highcharts from 'highcharts';
import { MatTableDataSource } from '@angular/material/table';
import { AttendenceService } from 'src/app/services/hr-operations/attendence.service';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  // another pie chart complete
  ispieVisible: boolean;
  isdoughnutVisible: boolean;
  islineVisible: boolean;
  isbarVisible: boolean;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['empId', 'empName', 'date', 'inTime', 'outTime', 'noOfHrs'];
  barData: any = [
    {
      name: 'Abscent',
      data: [100, 200, 150, 45, 300, 350]
    },
    {
      name: 'Present',
      data: [1000, 900, 955, 1055, 800, 750]
    }
  ];
  pieData: any = [{
    name: 'Present',
    y: 11.84
  }, {
    name: 'Abscent',
    y: 4.67
  }];

  attendeeList = new MatTableDataSource();

  loading = true;
  chart: any
  doughnut
  pie
  pieChartOptions: any;
  barChartOptions: any;
  highcharts = Highcharts;
  constructor(private _toaster: ToasterService,
    private _service: AttendenceService) {

  }

  ngOnInit(): void {
    this._service.getPieChart({}).subscribe(data => {
      if(data.status)
        if(data.result)this.pieData = data.result.data;
      /*  Pie Chart Declarations  */
      this.pieChartOptions = {
        chart: {
          plotBackgroundColor: null,
          plotBorderWidth: null,
          plotShadow: false,
          type: 'pie'
        },
        title: {
          text: 'Employee Attendance Day Wise'
        },
        tooltip: {
          pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        accessibility: {
          point: {
            valueSuffix: '%'
          }
        },
        plotOptions: {
          pie: {
            allowPointSelect: true,
            cursor: 'pointer',
            dataLabels: {
              enabled: false
            },
            // point: { events: { click: this.getChartdata } },
            point: {
              events: {
                click: function (e) {
                  const p = e.point;
                  console.log("e----",e);
                  // console.log('HI' + 'Category: ', p.category, "--", p.series.name, "--", p.value);
                  this.getCategoryAttendanceList(p.name);
                }.bind(this)
              }
            },

            showInLegend: true
          }
        },
        colors: ['#ffbc75', '#90ed7d'],
        series: [{
          name: 'Employees',
          colorByPoint: true,
          data: this.pieData
        }]
      };
    });
    this._service.getBarChart({}).subscribe(data => {
      console.log(data);
      if(data.status)
        if(data.result)this.barData = data.result.Attendance;
      /*  Bar Chart Declarations  */
      this.barChartOptions = {
        chart: {
          type: 'column'
        },
        title: {
          text: 'Employees Attendance Week Wise'
        },
        legend: {
          align: 'right',
          x: -10,
          verticalAlign: 'top',
          y: 15,
          floating: true,
          layout: 'vertical',
          borderWidth: 1,
          backgroundColor: ((Highcharts.theme) || '#FFFFFF'),
          shadow: true
        },
        xAxis: {
          categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
          title: {
            text: null
          }
        },
        yAxis: {
          min: 0,
          title: {
            text: 'Employees'
          },
          labels: {
            overflow: 'justify'
          }
        },
        tooltip: {
          valueSuffix: ''
        },
        plotOptions: {
          series: {
            cursor: 'pointer',
            point: {
              events: {
                click: function () {
                  alert('Category: ' + this.category + ',Name: ' + this.series.name + ', value: ' + this.y);
                }
              }
            }
          },
          bar: {
            dataLabels: {
              enabled: true
            }
          },
          column: {
            stacking: 'normal',
            dataLabels: {
              enabled: true
            }
          }
        },
        credits: {
          enabled: false
        },
        colors: ['#ffbc75', '#90ed7d'],
        series: this.barData
        // [
        //   {
        //     name: 'Abscent',
        //     data: [100, 200, 150, 45, 300, 350]
        //   },
        //   {
        //     name: 'Present',
        //     data: [1000, 900, 955, 1055, 800, 750]
        //   }
        // ]
      };
    });
  }
  getCategoryAttendanceList(type) {
    var params = {};
    this.totalRecords=0;
    this.attendeeList=new MatTableDataSource();
    if(type.toLowerCase()=="abscent"){
      this._service.getAbscentAttendanceList(params).subscribe(
        data => {
          this.attendeeList = new MatTableDataSource(data.result);
          this.totalRecords = data.result.length;
        });
    }else{
      this._service.getCategoryAttendanceList(params).subscribe(
        data => {
          this.attendeeList = new MatTableDataSource(data.result);
          this.totalRecords = data.result.length;
        });
    }
  }
}
