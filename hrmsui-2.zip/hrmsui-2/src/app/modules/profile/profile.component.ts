import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { LocalStorageService } from 'src/app/util/local-storage.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {

  constructor(private _service : AuthenticationService,
              private _ls : LocalStorageService ) { }

  ngOnInit(): void {
  }

  getProfileInfo(){
    var userId = this._ls.getUserData("user").id;
    this._service.getUserInfo(userId).subscribe(data=>{
      console.log("user === ",data);
    });
  }
}
