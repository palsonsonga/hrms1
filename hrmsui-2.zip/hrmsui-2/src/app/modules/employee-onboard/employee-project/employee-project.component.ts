import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { DualListComponent } from 'angular-dual-listbox';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { ProjectService } from 'src/app/services/hr-operations/project.service';
@Component({
  selector: 'app-employee-project',
  templateUrl: './employee-project.component.html',
  styleUrls: ['./employee-project.component.scss']
})
export class EmployeeProjectComponent implements OnInit {
  empId: any;
  tab = 1;
  keepSorted = true;
  key: string;
  display: string;
  filter = false;
  source: Array<any>;
  confirmed: Array<any>;
  userAdd = '';
  disabled = false;
  sourceLeft = true;
  format: any = DualListComponent.DEFAULT_FORMAT;
  private sourceProjects: Array<any>;
  private confirmedProjects: Array<any>;
  private projects: Array<any> = [];

  constructor(private _service: EmployeeOnboardingService,
    private _pService: ProjectService,
    private _ar: ActivatedRoute,
    private _router: Router) {
    _ar.paramMap.subscribe(params => {
      console.log(params['params']['name']);
      this.empId = atob(params['params']['id']);
    });
    this.getEmployeeProjects();
  }

  ngOnInit() {
    this.doReset();
  }
  getEmployeeProjects() {
    this._service.getEmployee(this.empId).subscribe(data => {      
      if (data) {
        this.confirmedProjects = data.projects;
        this.confirmed = this.confirmedProjects;
      }
    });
  }
  private useProjects() {
    this.key = 'id';
    this.display = 'name';
    this.keepSorted = true;
    this.source = this.sourceProjects;
    this.confirmed = this.confirmedProjects;
  }
  doReset() {
    this._pService.getProjects({}).subscribe(data => {
      if (data) {
        this.projects = data;
        this.sourceProjects = JSON.parse(JSON.stringify(this.projects));
      }
      this.format.none = 'Reset';
      this.useProjects();
    });
  }

  filterBtn() {
    return (this.filter ? 'Hide Filter' : 'Show Filter');
  }

  doDisable() {
    this.disabled = !this.disabled;
  }

  disableBtn() {
    return (this.disabled ? 'Enable' : 'Disabled');
  }

  swapDirection() {
    this.sourceLeft = !this.sourceLeft;
    this.format.direction = this.sourceLeft ? DualListComponent.LTR : DualListComponent.RTL;
    this.format.none = 'Reset';
  }
  onSubmit() {
    console.log(this.confirmed);
    var params = {};
    params['projects'] = this.confirmed;
    this._service.updateEmployeeProjects(params, this.empId).subscribe(data => {
      if (data) {
        console.log(data);
      }
    });
  }
  goToList() {
    this._router.navigate(['employee-onboard']);
  }
}
