import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.scss']
})
export class EmployeesListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['firstName', 'contactNo', 'email','designationName','action'];
  employeesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  closeResult: any;
  deleteEmployee: any;
  modalHeader: string = '';
  loading: boolean = true;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service : EmployeeOnboardingService,
              public _toast: ToasterService,
              private _router : Router,
              private _ar : ActivatedRoute) { }

  ngOnInit(): void {
    this.getAllEmployees();
  }

  getAllEmployees(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    /*this.employeesList = new MatTableDataSource([
      {employeeId:101215,firstName:'john',lastName:'parker',mobile:7897897898,email:'john.parker@onpassive.cpm', designation:'HR'},
      {employeeId:101245,firstName:'James',lastName:'Bond',mobile:7845567855,email:'james.bond@onpassive.cpm', designation:'Team Lead'},
      {employeeId:101164,firstName:'Ron',lastName:'Chandra',mobile:9897897812,email:'ron.chandra@onpassive.cpm', designation:'Scrum Master'},
      {employeeId:101052,firstName:'Ram',lastName:'Kulkarni',mobile:6897897811,email:'ram.kulkarni@onpassive.cpm', designation:'Senior Software Engineer'},
      {employeeId:101124,firstName:'Jai',lastName:'Ram',mobile:4497897844,email:'manager@onpassive.cpm', designation:'HR Manager'},
      {employeeId:101277,firstName:'Sri',lastName:'Krishna',mobile:7797897833,email:'sri.krishna@onpassive.cpm', designation:'Branch Manager'},
      {employeeId:101345,firstName:'Lakshmi',lastName:'Mittal',mobile:8897897822,email:'lakshmi.mittal@onpassive.cpm', designation:'UI Designer'},
      {employeeId:101521,firstName:'Uhya Bhanu Prakash',lastName:'Reddy',mobile:8997897813,email:'bhanu.prakash@onpassive.cpm', designation:'UX Developer'}
  ]);*/
    this._service.getEmployeesList(params).subscribe(
      data => {
        this.employeesList = new MatTableDataSource(data.data);
        this.employeesList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        this.pageSize = params['pageSize'];
      });
  }
  applyFilter(event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.employeesList.filter = filterValue.trim();
   this.getAllEmployees();
  }
  open(content, type: boolean, employee?) {}
  
  goToCreateEmployee(){
    // this.location.replace('/edit');
    this._router.navigate(['register'],{relativeTo:this._ar});
  }
  goToUpdateForm(data:any){
    data['name'] = data.firstName+' '+data.lastName;
    this._router.navigate(['update',data.name,btoa(data.id)],{relativeTo:this._ar});
  }

  goToPolicy(data:any){
    data['name'] = data.firstName+' '+data.lastName;
    this._router.navigate(['policy',data.name,btoa(data.id)],{relativeTo:this._ar});
  }
  goToResources(data:any){
    data['name'] = data.firstName+' '+data.lastName;
    this._router.navigate(['resources',data.name,btoa(data.id)],{relativeTo:this._ar});
  }

  goToProjects(data:any){
    data['name'] = data.firstName+' '+data.lastName;
    this._router.navigate(['projects',data.name,btoa(data.id)],{relativeTo:this._ar});
  }
  onChange(element){
    console.log(element);
    var params ={
      'status' : (element.isActive)?'ACTIVATE':'DEACTIVATE'
    }
    this._service.updateEmployeeStatus(params,element.id).subscribe(data=>{
      if(data){
        console.log(data);
      }
    });
  }
  approveEmployee(element){
    console.log(element);    
    this._service.approveEmployee({},element.id).subscribe(data=>{
      if(data){
        console.log(data);
        this.getAllEmployees();
      }
    });
  }
  clearSearchText() {
    this.filter.searchKey = '';
    this.getAllEmployees();
  }
  
}
