import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { PolicyService } from 'src/app/services/hr-operations/policy.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-employee-policy',
  templateUrl: './employee-policy.component.html',
  styleUrls: ['./employee-policy.component.scss']
})
export class EmployeePolicyComponent implements OnInit {

  empName:any;
  empId:any;
  policyList:any=[
    {name: 'A full-time regular employee is one who works between 33 and 40 hours per week.', isSelected: true},
    {name: 'Part-time employees are staff members who work less than full-time in a regular job slot.', isSelected: false},
    {name: 'Employers communicate the value of the benefits poorly and infrequently.', isSelected: true},
    {name: 'Employees have little or no choice in selecting benefits packages or options.', isSelected: false},
    {name: 'Workplace flexibility benefits such as flexible hours, commuter benefits, or the ability to work remotely on a regular basis.', isSelected: false},
    {name: 'Employees have little or no choice in selecting benefits packages or options.', isSelected: true},
    {name: 'Employees have little or no choice in selecting benefits packages or options.', isSelected: false},

  ];
  constructor(private _service: EmployeeOnboardingService,
    private _router: Router,
    private _policy : PolicyService,
    private _ar : ActivatedRoute,
    private _toast: ToasterService,
    private modalService: NgbModal
  ) { 
    const currentYear = new Date().getFullYear();
    _ar.paramMap.subscribe(params => {
      console.log(params['params']['name']);
      this.empName = params['params']['name'];
      this.empId = atob(params['params']['id']);
    });
  }

  ngOnInit(): void {
    this._policy.getPolicies().subscribe(data=>{
      console.log(data);
      this.policyList = data;
      this.getEmployeeInfo();
    });
  }
  getEmployeeInfo(){
    this._service.getEmployee(this.empId).subscribe(data=>{
      if(data){
        console.log(data.policies);
        data.policies.forEach(ele => {
          this.policyList.forEach(element => {
            if(ele.id==element.id){
              element.isSelected = true;
            }
          });
        });
      }        
    });
  }
  onSubmit(){
    var selectedList=[];
    this.policyList.forEach(element => {
      if(element.isSelected){
        delete element.isSelected;
        selectedList.push(element);
      }
    });
    var params={
      'policies':selectedList
    };
    this._service.updateEmployeePolicy(params,this.empId).subscribe(data=>{
      this.goToList();
    });
  }

  goToList() {
    this._router.navigate(['employee-onboard']);
  }

  previewDoc(data){
    console.log(data);
  }
}
