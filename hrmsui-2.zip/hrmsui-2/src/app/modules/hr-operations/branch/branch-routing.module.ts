import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BranchListComponent } from './branch-list/branch-list.component';
import { CreateBranchComponent } from './create-branch/create-branch.component';
import { UpadteBranchComponent } from './upadte-branch/upadte-branch.component';

const routes: Routes = [
  {
    path:'',
    redirectTo: 'list'
  },
  {
    path:'list',
    component: BranchListComponent
  },
  {
    path:'create',
    component:CreateBranchComponent,
    data:{
      breadcrumb:'Create Location'
    }
  },
  {
    path:'update/:name/:id',
    component:UpadteBranchComponent,
    data:{
      breadcrumb:'Upadte Location'
    }
  }
  
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BranchRoutingModule { }
