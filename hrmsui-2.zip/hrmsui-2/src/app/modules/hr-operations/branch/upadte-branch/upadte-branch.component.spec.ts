import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpadteBranchComponent } from './upadte-branch.component';

describe('UpadteBranchComponent', () => {
  let component: UpadteBranchComponent;
  let fixture: ComponentFixture<UpadteBranchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpadteBranchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpadteBranchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
