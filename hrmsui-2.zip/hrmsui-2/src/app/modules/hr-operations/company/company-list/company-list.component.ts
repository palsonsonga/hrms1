import { HttpParams } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.scss']
})
export class CompanyListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name', 'contact', 'email', 'website', 'action'];
  companiesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  companyForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteCompany: any;
  modalHeader: string = '';
  constructor(private _service: CompanyService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal,
    private _ar: ActivatedRoute,
    private router: Router) { }

  ngOnInit() {
    this.getAllCompanies();
  }

  getAllCompanies(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order
    console.log(sorting);
    this._service.getCompanyList(params).subscribe(
      data => {
        this.companiesList = new MatTableDataSource(data.data);
        this.companiesList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        this.pageSize = params['pageSize'];
      });
  }
  getCompanyId() {
    if (this.companyForm.value.id)
      return this.companyForm.value.id;
    else return 0;
  }
  goToUpdate(data) {
    console.log(data);
    this.router.navigate(['../update','test',btoa(data.id)],{relativeTo:this._ar});
    // this.router.navigate(['.../update'],{queryParams:{name:data.name,id:btoa(data.id)},relativeTo:this._ar});
    // this.router.navigate(['hr-operations/company/update'],{queryParams:{name:data.name,id:btoa(data.id)}});
  }

  goToCreate() {
    this.router.navigate(['hr-operations/company/create'])
  }
  openDelete(deleteConfirm, company?) {
    this.deleteCompany = company;
    this.modalService
      .open(deleteConfirm, { 
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteCompany(this.deleteCompany.id).subscribe(
      (data: any) => {
        this.getAllCompanies();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
}
