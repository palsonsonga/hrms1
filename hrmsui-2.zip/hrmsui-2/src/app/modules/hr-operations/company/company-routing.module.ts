import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CompanyListComponent } from './company-list/company-list.component';
import { CreateCompnayComponent } from './create-compnay/create-compnay.component';
import { UpdateCompnayComponent } from './update-compnay/update-compnay.component';

const routes: Routes = [
  
  {
    path:'',
    redirectTo: 'list'
  },

  {
    path:'list',
    component: CompanyListComponent
  },
  {
    path:'create',
    component:CreateCompnayComponent,
    data:{
      breadcrumb : 'Create Company'
    }
  },
  {
    path:'update/:name/:id',
    component:UpdateCompnayComponent,
    data:{
      breadcrumb : 'Update Company'
    }
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class CompanyRoutingModule { }
