import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AssetsService } from 'src/app/services/hr-operations/assets.service';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';


@Component({
  selector: 'app-assets',
  templateUrl: './assets.component.html',
  styleUrls: ['./assets.component.scss']
})
export class AssetsComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name', 'action'];
  assetsList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  assetsForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  companies:any=[];
  closeResult: any;
  deleteAssets: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: AssetsService,
    public dialog: MatDialog,
    private _company : CompanyService,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.assetsForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required,
                                      Validators.minLength(3),
                                      Validators.pattern('[-a-zA-Z. ]*')]),
      description: new FormControl(''),
      companyId: new FormControl('',[Validators.required]),
    });
    this.getAllAssets();
    this.getCompanies();
  }
  getCompanies(){
    this._company.getCompaniesDropdown().subscribe(data=>{
      if(data){
        this.companies = data;
      }
    });
  }

  getAllAssets(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getAssetsList(params).subscribe(
      data => {
        this.assetsList = data;
        this.assetsList.sort = this.sort;
        this.totalRecords = data.length;
      });
  }
  getAssetsId() {
    if (this.assetsForm.value.id)
      return this.assetsForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update assets 
  */
  onSubmit() {    
    if (this.assetsForm.valid) {
      this.submitted = true;
      if (this.getAssetsId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getAssetsId());
        this._service.updateAssets(this.assetsForm.value, this.getAssetsId()).subscribe(data => {
          console.log(data);
          this.getAllAssets();
        });
      } else {
        // create API call
        delete this.assetsForm.value.id;
        this._service.saveAssets(this.assetsForm.value).subscribe(data => {
          this.getAllAssets();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, assets?) {
    this.modalHeader = type ? "Add": "Update";
    this.assetsForm.reset();
    if (!type) {
      console.log("assets--",assets);
      this._service.getAsset(assets.id).subscribe(data=>{
        if(data){
          this.assetsForm.setValue({
            id: data.id,
            name: data.name,
            description: data.description,
            companyId: data.companyId,
          });
        }
      });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, assets?) {
    this.deleteAssets = assets;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteAssets(this.deleteAssets.id).subscribe(
      (data: any) => {
        this.getAllAssets();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
  
  public hasError = (controlName: string, errorName: string) =>{
    return this.assetsForm.controls[controlName].hasError(errorName);
  }

  clearSearchText() {
    this.filter.searchKey = '';
    this.getAllAssets();
  }
  

}
