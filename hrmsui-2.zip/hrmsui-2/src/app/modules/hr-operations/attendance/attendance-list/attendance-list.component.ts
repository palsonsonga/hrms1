import { DatePipe } from '@angular/common';
import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AttendenceService } from 'src/app/services/hr-operations/attendence.service';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-attendance-list',
  templateUrl: './attendance-list.component.html',
  styleUrls: ['./attendance-list.component.scss'],
  providers: [DatePipe]
})
export class AttendanceListComponent implements OnInit {
  minTime: Date;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['companyName', 'branchName', 'inTime', 'outTime', 'action'];
  attendencesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  attendanceForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteCompany: any;
  modalHeader: string = '';
  submitted: boolean = false;
  companies:any=[];
  branches:any=[];

  constructor(private _service: AttendenceService,
              public dialog: MatDialog,
              private _company : CompanyService,
              private _branch : BranchService,
              public _toast: ToasterService,
              private datepipe: DatePipe,
              private modalService: NgbModal) {
    const currentTime = new Date();
    this.minTime = new Date();
  }

  ngOnInit(): void {
    this.attendanceForm = new FormGroup({
      id: new FormControl(''),
      companyId: new FormControl('',[Validators.required]),
      branchId: new FormControl('',[Validators.required]),
      inTime: new FormControl('', [Validators.required,Validators.pattern("^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$")]),
      outTime: new FormControl('', [Validators.required,Validators.pattern("^([0-1]?[0-9]|2[0-4]):([0-5][0-9])(:[0-5][0-9])?$")])
    });
    this.getAllAttendences();
    this.getCompanies();
  }

  getCompanies(){
    this._company.getCompaniesDropdown().subscribe(data=>{
      if(data){
        this.companies = data;
      }
    });
  }
  getBranches(id){
    this._branch.getBranchDropdown(id).subscribe(data=>{
      if(data){
        this.branches = data;
      }
    });
  }
  getAllAttendences(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getAttendenceList(params).subscribe(
      data => {
        this.attendencesList = new MatTableDataSource(data.data);
        this.totalRecords = data.totalRecords;
        this.attendencesList.sort = this.sort;
        this.pageSize = params['pageSize'];
      });
  }
  getAttendenceId() {
    if (this.attendanceForm.value.id)
      return this.attendanceForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update branch 
  */
  onSubmit() {
    this.submitted = true;
    if (this.attendanceForm.valid) {
      var params1 = JSON.parse(JSON.stringify(this.attendanceForm.value));
      params1.inTime = new Date(new Date().setHours(params1.inTime.split(":")[0],params1.inTime.split(":")[1]));
      params1.outTime = new Date(new Date().setHours(params1.outTime.split(":")[0],params1.outTime.split(":")[1]));      
      params1.inTime = this.datepipe.transform(params1.inTime, 'yyyy-MM-dd HH:mm:ss');
      params1.outTime = this.datepipe.transform(params1.outTime, 'yyyy-MM-dd HH:mm:ss');
      if (this.getAttendenceId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getAttendenceId());
        this._service.updateAttendence(params1, this.getAttendenceId()).subscribe(data => {
          console.log(data);
          this.getAllAttendences();
        });
      } else {
        // create API call
        delete params1['id'];
        this._service.saveAttendence(params1).subscribe(data => {
          console.log(data);
          this.getAllAttendences();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }
  }
  open(content, type: boolean, attendance?) {
    this.modalHeader = type ? "Create" : "Update";
    this.attendanceForm.reset();
    if (!type) {
      this._service.getAttendence(attendance.id).subscribe(data=>{
        this.getBranches(data.companyId);
        var inTimeHr = data.inTime.split(" ")[1].split(":")[0];
        var outTimeHr = data.outTime.split(" ")[1].split(":")[0];
        var inTimeMin = data.inTime.split(" ")[1].split(":")[1];
        var outTimeMin = data.outTime.split(" ")[1].split(":")[1];
        this.attendanceForm.setValue({
          id: data.id,
          companyId: data.companyId,
          branchId: data.branchId,
          inTime: inTimeHr+":"+inTimeMin,
          outTime: outTimeHr+":"+outTimeMin, 
        });
      });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, attendance?) {
    this.deleteCompany = attendance;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }
  onDeleteConfirmation() {
    this._service.deleteAttendence(this.deleteCompany.id).subscribe(
      (data: any) => {
        this.getAllAttendences();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }
  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
  public hasError = (controlName: string, errorName: string) =>{
    return this.attendanceForm.controls[controlName].hasError(errorName);
  }

  clearSearchText() {
    this.filter.searchKey = '';
    this.getAllAttendences();
  }
}






















//branch: new FormControl('', [Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z ]*')]),