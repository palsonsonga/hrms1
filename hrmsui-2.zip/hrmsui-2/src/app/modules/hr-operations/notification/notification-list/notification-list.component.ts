import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { NotificationService } from 'src/app/services/hr-operations/notification.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.scss']
})
export class NotificationListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['subject', 'action'];
  notificationList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  notificationForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  companies: any = [];
  closeResult: any;
  deleteNotification: any;
  modalHeader: string = '';
  submitted: boolean = false;
  isCreate: boolean = true;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;
  minDate: Date;
  constructor(private _service: NotificationService,
    public dialog: MatDialog,
    private _company: CompanyService,
    public _toast: ToasterService,
    private modalService: NgbModal) {
    this.minDate = new Date();
  }

  ngOnInit(): void {
    this.notificationForm = new FormGroup({
      id: new FormControl(''),
      subject: new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z ]{0,})'), Validators.maxLength(20), Validators.minLength(3)]),
      description: new FormControl(''),
      companyId: new FormControl('', [Validators.required]),
      toMail: new FormControl(''),
      fromMail: new FormControl('hrms@mail.onpassive.com'),
      eventDate: new FormControl('')
    });
    this.getAllNotifications();
    this.getCompanies();
  }
  getCompanies() {
    this._company.getCompaniesDropdown().subscribe(data => {
      if (data) {
        this.companies = data;
      }
    });
  }
  getAllNotifications(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc') : 'asc'; // be default sorting will be in Ascending order

    this._service.getNotificationList(params).subscribe(
      data => {
        this.notificationList = new MatTableDataSource(data.data);
        this.notificationList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        this.pageSize = params['pageSize'];
      });
  }
  getNotificationId() {
    if (this.notificationForm.value.id)
      return this.notificationForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update notification 
  */
  onSubmit() {
    if (this.notificationForm.valid) {
      this.submitted = true;
      if (this.getNotificationId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getNotificationId());
        this._service.updateNotification(this.notificationForm.value, this.getNotificationId()).subscribe(data => {
          this.getAllNotifications();
        });
      } else {
        // create API call
        delete this.notificationForm.value.id;
        this._service.saveNotification(this.notificationForm.value).subscribe(data => {
          this.getAllNotifications();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }
  }

  open(content, type: boolean, notification?) {
    this.modalHeader = type ? "Create" : "Update";
    this.notificationForm.reset();
    if (!type) {
      console.log("notification--", notification);
      this.isCreate=false;
      this._service.getNotificationById(notification.id).subscribe(data => {
        if (data) {
          this.notificationForm.setValue({
            id: data.id,
            subject: data.subject,
            description: data.description,
            companyId: data.companyId,
            toMail: data.toMail,
            fromMail: data.fromMail,
            eventDate: data.eventDate
          });
        }
      });
    }else
      this.isCreate = true;
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, notification?) {
    this.deleteNotification = notification;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteNotification(this.deleteNotification.id).subscribe(
      (data: any) => {
        this.getAllNotifications();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) => {
    return this.notificationForm.controls[controlName].hasError(errorName);
  }

  clearSearchText() {
    this.filter.searchKey = '';
    this.getAllNotifications();
  }

}
