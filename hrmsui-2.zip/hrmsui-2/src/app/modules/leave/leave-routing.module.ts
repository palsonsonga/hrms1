import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:'apply-leave'
  },
  {
    path:'apply-leave',
    component: ApplyLeaveComponent,
    data:{
      breadcrumb:'Apply Leave'
    }
  },
  {
    path:'leave-approval',
    component: LeaveApprovalComponent,
    data:{
      breadcrumb:'Leave Approval'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeaveRoutingModule { }
