import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LeaveRoutingModule } from './leave-routing.module';
import { ApplyLeaveComponent } from './apply-leave/apply-leave.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [ApplyLeaveComponent, LeaveApprovalComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgbModule,
    LeaveRoutingModule
  ]
})
export class LeaveModule { }
