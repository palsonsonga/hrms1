import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AttendanceService } from 'src/app/services/attendance.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MY_FORMATS } from 'src/app/modals/date.format';
import { DepartmentService } from 'src/app/services/hr-operations/department.service';
import { DesignationService } from 'src/app/services/hr-operations/designation.service';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
// Models
//import {  } from 'src/app/modals/Attendance-info/attendanceinfo';



@Component({
  selector: 'app-attendance-info',
  templateUrl: './attendance-info.component.html',
  styleUrls: ['./attendance-info.component.scss'],
  providers: [
    // {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
    
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class AttendanceInfoComponent implements OnInit {

  attendanceInfoForm: FormGroup;
  submitted: boolean = false;
  isUpdate:boolean=false;  
  minTime: Date;
  companies:any;
  branches:any;
  employees:any = [];
  empId:any = 114;
  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  };
  maxDate = new Date();
  constructor(private formBuilder: FormBuilder,
    private _service: AttendanceService,
    private _compService : CompanyService,
    private _branchService : BranchService,
    private _empService : EmployeeOnboardingService,
    private _router: Router,
    private _toast: ToasterService,
  ) {
    const currentTime = new Date();
    this.minTime = new Date();
   }

  ngOnInit(): void {
    this.attendanceInfoForm = this.formBuilder.group({
      
      // company related fields
      // companyName: new FormControl('',[Validators.required]),
      // branchName: new FormControl(''),
      id: new FormControl(''),
      empId: new FormControl(''),
      companyId: new FormControl('',[Validators.required]),
      branchId: new FormControl(''),
      companyName: new FormControl('',[Validators.required]),
      branch: new FormControl(''),
      date: new FormControl('', [Validators.required]),
      inTime: new FormControl('', [Validators.required]),
      outTime: new FormControl('', [Validators.required]),
      reason: new FormControl('')
    });
    this.getCompaniesList();
    
  }
  getCompaniesList(){
    this._compService.getCompaniesDropdown().subscribe(data=>{
      if(data){
        this.companies = data;
        this.getAllEmployees();
      }
    });
  }

  getAllEmployees(){
    
  }

  getCompany(event){
    console.log(event.value);
    if(event.value>0){
      this._branchService.getBranchDropdown(event.value).subscribe(data=>{
        if(data){
          this.branches  = data;
        }
      });
    }
  }
 
  onCancel(){
    
  }
  onSubmit(event?: any) {
    this.submitted = true;
    if (this.attendanceInfoForm.valid) {
        this._service.saveManualAttendance(this.attendanceInfoForm.value).subscribe(data => {
          console.log(data);
        });
    } else {
      this._toast.show('warn', 'Please enter mandatory fields');
    }
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.attendanceInfoForm.controls[controlName].hasError(errorName);
  }
  
}
