import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import {TooltipPosition} from '@angular/material/tooltip';
import { LocalStorageService } from 'src/app/util/local-storage.service';
/**
 * @author Swetha P
 * @created  06-10-2020
 * @description Compoent of Side Navigation for user (user side menu)
 */
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.scss']
})
export class SideNavComponent implements OnInit {

  @ViewChild('sidenav') sidenav: MatSidenav;

  isExpanded = false;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  public expandedIndex = -1;
  menuItems:any=[];
  constructor(private _ls : LocalStorageService) { }
 /* menuItems = [
    { title: 'Dashbaord', path: 'dashboard', icon: 'fa fa-tachometer', childs: [], showSubmenu: false, expand:false },
    // { title: 'Masters', path: 'masters', icon: 'fa fa-cogs', childs: [], showSubmenu: false },
    {
      title: 'HR Operations', path: 'hr-operations', icon: 'fa fa-cog',
      childs: [
        { title: 'Attendance', path: 'hr-operations/attendance', icon: 'language' },
        { title: 'Branch', path: 'hr-operations/branch', icon: 'language' },
        { title: 'Company', path: 'hr-operations/company', icon: 'language' },
        { title: 'Department', path: 'hr-operations/department', icon: 'language' },
        { title: 'Designation', path: 'hr-operations/designation', icon: 'language' },
        { title: 'Leave Plan', path: 'hr-operations/leave-plan', icon: 'language' },
        { title: 'Notification', path: 'hr-operations/notification', icon: 'language' },
        { title: 'Project', path: 'hr-operations/project', icon: 'language' },
        { title: 'Yearly Holidays', path: 'hr-operations/holidays', icon: 'language' },
        { title: 'Jobs', path: 'hr-operations/job', icon: 'language' },
        { title: 'Technology', path: 'hr-operations/technology', icon: 'language' },
        { title: 'Policy', path: 'hr-operations/policy', icon: 'language' },
        { title: 'Company Assets', path: 'hr-operations/assets', icon: 'language' }
        
      ], showFirst: true, expand:false
    },
    {title: 'Employee Onboarding', path: 'employee-onboard', icon: 'fa fa-users',childs: [],showFirst: false, expand:false},
    {title: 'Attendance', path: 'attendance', icon: 'fa fa-address-book-o',
      childs: [
        { title: 'Attendance Upload', path: 'attendance', icon: 'language' },
        { title: 'Attendance Info', path: 'attendance/attendance-info', icon: 'language' }
      ],showFirst: false, expand:false},
    
    {
      title: 'Leave Management', path: 'leave', icon: 'fa fa-sticky-note-o',
      childs: [
        { title: 'Apply Leave', path: 'leave/apply-leave', icon: 'language' },
        { title: 'Leave Approval', path: 'leave/leave-approval', icon: 'language' }
        
      ], showFirst: true, expand:false
    },
  ];*/
  ngOnInit() {
    this.menuItems = this._ls.getUserData("menus");
    console.log("*-*-----",this.menuItems)
  }
  navigatePage(routeURL: string) {
    // this.router.navigate(['/', routeURL]);
  }
}
