import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }
  storageKey = environment.storageKey;
  getLoggedInUser(key:any,json?:boolean){
    if(json)
      return JSON.parse(localStorage.getItem(this.storageKey+"_"+key));
    else localStorage.getItem(this.storageKey+"_"+key);
  }

  setLoggedInUser(key:any,data:any, json:boolean){
    if(json)
      localStorage.setItem(this.storageKey+"_"+key, JSON.stringify(data));
    else localStorage.setItem(this.storageKey+"_"+key, data);
  }

  removeUser(key:any){
    localStorage.removeItem(this.storageKey+"_"+key);
  }

  isLoggedIn(){
    if(this.getLoggedInUser("user",true)){
      return true;
    }else return false;
  }

  getUserData(key:any){
    if(this.getLoggedInUser("user",true)){
      var data  = this.getLoggedInUser("user",true);
      return data[key];
    }else return null;
  }
}
