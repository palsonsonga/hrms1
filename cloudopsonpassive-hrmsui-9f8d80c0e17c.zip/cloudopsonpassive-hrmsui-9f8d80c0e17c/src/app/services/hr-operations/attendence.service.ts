import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class AttendenceService {

  subApiUrl = 'admin/attendance';
  subdashboardApiUrl = 'admin/attendanceinfo';
  constructor(private _http: HttpClientService) { }

  getAttendenceList(params: any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  getAttendence(params: any): Observable<any> {
    return this._http.get(this.subApiUrl+'/'+params);
  }

  saveAttendence(params: any): Observable<any>{
    return this._http.post(this.subApiUrl , params);
  }

  updateAttendence(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl +'/'+ urlParams, params);
  }

  deleteAttendence(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl +'/'+ params);
  }
  getCategoryAttendanceList(params: any): Observable<any> {
    console.log(params);
    return this._http.get(this.subdashboardApiUrl+'/presentEmp', params);
  }
}

