import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class ProjectService {

  subApiUrl = 'admin/project';

  constructor(private _http: HttpClientService) { }

  getProjectList(params: any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  saveProject(params: any): Observable<any>{
    return this._http.post(this.subApiUrl , params);
  }

  updateProject(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl +'/'+urlParams, params);
  }

  deleteProject(params: any): Observable<any> {
    return this._http.delete(this.subApiUrl + '/'+ params);
  }

  getProjects(params: any): Observable<any> {
    return this._http.get(this.subApiUrl+'/list',params);
  }
}


