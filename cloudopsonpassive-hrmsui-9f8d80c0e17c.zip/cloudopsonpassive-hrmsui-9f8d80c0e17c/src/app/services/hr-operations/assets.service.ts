import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClientService } from 'src/app/util/http-client.service';


@Injectable({
  providedIn: 'root'
})
export class AssetsService {

  subApiUrl = 'admin/Assets';

  constructor(private _http: HttpClientService) { }

  getAssetsList(params?: any): Observable<any> {
    return this._http.get(this.subApiUrl+'/list');
  }

  saveAssets(params: any): Observable<any>{
    return this._http.post(this.subApiUrl , params);
  }

  updateAssets(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + '/'+urlParams, params);
  }

  deleteAssets(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params);
  }
}
