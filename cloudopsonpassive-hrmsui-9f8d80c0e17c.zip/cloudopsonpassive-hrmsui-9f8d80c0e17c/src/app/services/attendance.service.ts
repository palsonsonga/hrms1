import { HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpClientService } from '../util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class AttendanceService {
  subApiUrl = 'admin/attendance/uploadFile';
  subApiInfoUrl = '/admin/attendanceinfo/save';
  constructor(private _http : HttpClientService) { }

  getAttendanceSheet(parmas?:any){
    return this._http.get(this.subApiUrl+'',parmas);
  }

  uploadAttendanceSheet(parmas?:any){
    return this._http.post(this.subApiUrl+'',parmas);
  }

  saveManualAttendance(parmas?:any){
    return this._http.post(this.subApiInfoUrl+'',parmas);
  }
}
