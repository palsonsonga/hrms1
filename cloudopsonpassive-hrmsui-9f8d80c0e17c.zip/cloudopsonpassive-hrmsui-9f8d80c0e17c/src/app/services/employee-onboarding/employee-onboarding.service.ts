import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeOnboardingService {

  subApiUrl = 'onboard/employee';
  constructor(private _http : HttpClientService, private http : HttpClient) { }

  getEmployeesList(params:any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  saveEmployee(params:any): Observable<any> {
    return this._http.post(this.subApiUrl, params);
  }
  getEmployee(params:any): Observable<any> {
    return this._http.get(this.subApiUrl+"/"+params);
  }
  updateEmployee(params:any,id:any): Observable<any> {
    console.log(params);
    return this._http.put(this.subApiUrl+"/"+id, params);
  }

  updateEmployeeProjects(params:any,urlParams:any): Observable<any> {
    return this._http.put(this.subApiUrl+"/empproject/"+urlParams,params);
  }
  updateResources(params:any,id:any): Observable<any> {
    console.log(params);
    return this._http.put(this.subApiUrl+"/resources/"+id, params);
  } 

  deleteFile(id:any,fileId:any): Observable<any> {
    return this._http.delete(this.subApiUrl+"/"+id+"/"+fileId);
  }

  updateEmployeeStatus(params:any,urlParams:any): Observable<any> {
    return this._http.put(this.subApiUrl+"/empStatus/"+urlParams, params);
  }

  approveEmployee(params:any,urlParams:any): Observable<any> {
    return this._http.put(this.subApiUrl+"/approve/"+urlParams, params);
  }

  updateEmployeePolicy(params:any,urlParams:any): Observable<any> {
    return this._http.put(this.subApiUrl+"/emppolicy/"+urlParams, params);
  }

  getResourcesList() : Observable<any>{
    return this._http.get('onboard/ResourceItems');
  }
  
}
