import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { ProfileComponent } from './modules/profile/profile.component';
import { AuthGuard } from './util/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
    canActivate: [AuthGuard]
  },
  {
    path:'login',
    loadChildren: () => import('./modules/onboard/onboard.module').then(m => m.OnboardModule)
  },
  {
    path: '',
    component: UserLayoutComponent,
    children:[
      {
        path:'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard],
        data:{
          breadcrumb:'Dashboard'
        }
      },
      {
        path:'hr-operations',
        loadChildren: () => import('./modules/hr-operations/hr-operations.module').then(m => m.HrOperationsModule),
        canActivate: [AuthGuard],
        data:{
          breadcrumb:'HR Operations'
        }
      },
      {
        path:'employee-onboard',
        loadChildren: () => import('./modules/employee-onboard/employee-onboard.module').then(m => m.EmployeeOnboardModule),
        canActivate: [AuthGuard],
        data:{
          breadcrumb:'Employees'
        }
      },
      {
        path:'attendance',
        loadChildren: () => import('./modules/attendance/attendance.module').then(m => m.AttendanceModule),
        canActivate: [AuthGuard],
        data:{
          breadcrumb:'Attendance'
        }
      },
      {
        path:'leave',
        loadChildren: () => import('./modules/leave/leave.module').then(m => m.LeaveModule),
        canActivate: [AuthGuard],
        data:{
          breadcrumb:'Leave'
        }
      },
      {
        path:'profile',
        component: ProfileComponent,
        data:{
          breadcrumb : 'My Profile'
        }
      }
    ]
  },
  /*{ 
    path: '**',
    redirectTo: 'dashboard'
  }*/
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
