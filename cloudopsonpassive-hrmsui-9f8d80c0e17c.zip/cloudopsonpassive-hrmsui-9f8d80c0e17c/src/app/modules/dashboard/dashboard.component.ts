import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { Chart } from 'chart.js';
import * as Highcharts from 'highcharts';
import { MatTableDataSource } from '@angular/material/table';
import { AttendenceService } from 'src/app/services/hr-operations/attendence.service';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  // another pie chart complete
  ispieVisible: boolean;
  isdoughnutVisible: boolean;
  islineVisible: boolean;
  isbarVisible: boolean;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['employeeId', 'employeeName', 'date', 'inTime', 'outTime', 'hours'];
  barData:any = [
    {
      name: 'Abscent',
      data: [100, 200, 150, 45, 300, 350]
    },
    {
      name: 'Present',
      data: [1000, 900, 955, 1055, 800, 750]
    }
  ];
  pieData:any = [{
    name: 'Employees',
    colorByPoint: true,
    data: [{
      name: 'Present',
      y: 11.84
    },{
      name: 'Abscent',
      y: 4.67
    }]
  }];

  attendeeList = new MatTableDataSource();

  loading = true;
  chart: any
  doughnut
  pie
  constructor(private _toaster: ToasterService, 
    private _service: AttendenceService) { 

    }

  ngOnInit(): void {
    
  }

    highcharts = Highcharts;
    /*  Bar Chart Declarations  */
    chartOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Employees Attendance Week Wise'
      },
      legend: {
        align: 'right',
        x: -10,
        verticalAlign: 'top',
        y: 15,
        floating: true,
        layout: 'vertical',
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme) || '#FFFFFF'),
        shadow: true
      },
      xAxis: {
        categories: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        title: {
          text: null
        }
      },
      yAxis: {
        min: 0,
        title: {
          text: 'Employees'
        },
        labels: {
          overflow: 'justify'
        }
      },
      tooltip: {
        valueSuffix: ''
      },
      plotOptions: {
        series: {
          cursor: 'pointer',
          point: {
              events: {
                  click: function () {
                      alert('Category: ' + this.category + ',Name: ' + this.series.name + ', value: ' + this.y);
                  }
              }
          }
      },
        bar: {
          dataLabels: {
            enabled: true
          }
        },
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: true
          }
        }
      },
      credits: {
        enabled: false
      },
      colors: ['#ffbc75', '#90ed7d'],
      series: this.barData
      // [
      //   {
      //     name: 'Abscent',
      //     data: [100, 200, 150, 45, 300, 350]
      //   },
      //   {
      //     name: 'Present',
      //     data: [1000, 900, 955, 1055, 800, 750]
      //   }
      // ]
    };
  /*  Pie Chart Declarations  */
    pieChartOptions = {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
      },
      title: {
        text: 'Employee Attendance Day Wise'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      accessibility: {
        point: {
          valueSuffix: '%'
        }
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: false
          },
          // point: { events: { click: this.getChartdata } },
          point: { 
            
            events: { 
              click: function(oEvent) {
                //   console.log('HI'+'Category: ' + this.name + ', value: ' + this.y);
              this.callExternalFunction(oEvent.point.name);
            }
        } },
  
          showInLegend: true
        }
      },
      colors: ['#ffbc75', '#90ed7d'],
      series: this.pieData
      // [{
      //   name: 'Employees',
      //   colorByPoint: true,
      //   data: [{
      //     name: 'Present',
      //     y: 11.84
      //   },{
      //     name: 'Abscent',
      //     y: 4.67
      //   }]
      // }]
    };
  
    callExternalFunction(obj){
      console.log(obj)
      }
     
  
  

  getCategoryAttendanceList() {
    var params = {};
    this._service.getCategoryAttendanceList(params).subscribe(
      data => {
        this.attendeeList = new MatTableDataSource(data.data);
       
      });
  }
}
