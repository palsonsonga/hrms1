import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path:'',
    redirectTo: 'attendance'
  },
  {
    path:'attendance',
    loadChildren: () => import('./attendance/attendance.module').then(m => m.AttendanceModule),
    data:{
      breadcrumb:'Attendance'
    }
  },
  {
    path:'branch',
    loadChildren: () => import('./branch/branch.module').then(m => m.BranchModule),
    data:{
      breadcrumb:'Branches'
    }
  },
  {
    path:'company',
    loadChildren: () => import('./company/company.module').then(m => m.CompanyModule),
    data:{
      breadcrumb:'Companies'
    }
  },
  {
    path:'department',
    loadChildren: () => import('./department/department.module').then(m => m.DepartmentModule),
    data:{
      breadcrumb:'Departments'
    }
  },
  {
    path:'designation',
    loadChildren: () => import('./designation/designation.module').then(m => m.DesignationModule),
    data:{
      breadcrumb:'Designations'
    }
  },
  {
    path:'holidays',
    loadChildren: () => import('./holidays/holidays.module').then(m => m.HolidaysModule),
    data:{
      breadcrumb:'Yearly Holidays'
    }
  },
  {
    path:'leave-plan',
    loadChildren: () => import('./leave-plan/leave-plan.module').then(m => m.LeavePlanModule),
    data:{
      breadcrumb:'Leave Plan'
    }
  },
  {
    path:'notification',
    loadChildren: () => import('./notification/notification.module').then(m => m.NotificationModule),
    data:{
      breadcrumb:'Notifications'
    }
  },
  {
    path:'project',
    loadChildren: () => import('./project/Project.module').then(m => m.ProjectModule),
    data:{
      breadcrumb:'Projects'
    }
  },
  {
    path:'job',
    loadChildren: () => import('./job/job.module').then(m => m.JobModule),
    data:{
      breadcrumb:'Job'
    }
  },
  {
    path:'technology',
    loadChildren: () => import('./technology/technology.module').then(m => m.TechnologyModule),
    data:{
      breadcrumb:'Technologies'
    }
  },
  {
    path:'policy',
    loadChildren: () => import('./policy/policy.module').then(m => m.PolicyModule),
    data:{
      breadcrumb:'Policy'
    }
  },
  {
    path:'assets',
    loadChildren: () => import('./assets/assets.module').then(m => m.AssetsModule),
    data:{
      breadcrumb:'Assets'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HrOperationsRoutingModule { }
