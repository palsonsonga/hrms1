import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-update-compnay',
  templateUrl: '../create-compnay/create-compnay.component.html',
  styleUrls: ['../create-compnay/create-compnay.component.css']
})
export class UpdateCompnayComponent implements OnInit {

  companyForm: FormGroup;
  submitted: boolean = false;
  isUpdate: boolean = true;
  compName: any;
  compId: any;
  constructor(private formBuilder: FormBuilder,
    private _service: CompanyService,
    private _router: Router,
    private _ar: ActivatedRoute,
    private _toast: ToasterService,
  ) {
    _ar.paramMap.subscribe(params => {
      this.compName = params['params']['name'];
      this.compId = atob(params['params']['id']);      
    });
  }

  ngOnInit(): void {
    this.companyForm = new FormGroup({
      id : new FormControl(this.compId),
      name: new FormControl('', [Validators.required, Validators.pattern('[-A-Za-z ]*'),Validators.maxLength(60),Validators.minLength(2)]),
      contact: new FormControl('', [Validators.required,Validators.pattern('[0-9]{6,10}')]),
      email: new FormControl('', [Validators.required,
      Validators.maxLength(25),
      Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      website: new FormControl('', [Validators.required,
      Validators.maxLength(25),
      Validators.pattern("(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?")]),
      address: new FormGroup({
        address: new FormControl('', [Validators.required,Validators.pattern('[-A-Za-z.,0-9 ]*'), Validators.maxLength(100)]),
        country: new FormControl('', [Validators.required,Validators.pattern('[-A-Za-z., ]*'), Validators.maxLength(50)]),
        district: new FormControl('', [Validators.required, Validators.pattern('[-A-Za-z., ]*'),Validators.maxLength(50)]),
        landmark: new FormControl('', [Validators.required, Validators.pattern('[-A-Za-z., ]*'),Validators.maxLength(50)]),
        pincode: new FormControl('', [Validators.required, Validators.pattern('[0-9]*'),Validators.maxLength(8),Validators.minLength(6)]),
        state: new FormControl('', [Validators.required, Validators.pattern('[-A-Za-z., ]*'),Validators.maxLength(50)]),
        street: new FormControl('', [Validators.required, Validators.pattern('[-A-Za-z., ]*'),Validators.maxLength(50)]),
        village: new FormControl('', [Validators.required,Validators.pattern('[-A-Za-z., ]*'),Validators.maxLength(50)])
      })
    });
    this.getCompanyInfo(this.compId);
  }
  getCompanyInfo(id){
    this._service.getCompanyById(id).subscribe(data=>{
      if(data){
        console.log(data);
        this.companyForm.patchValue(data);
      }
    });
  }
  onSubmit() {
    this.submitted = true;
    if (this.companyForm.valid) {
      this._service.updateCompany(this.companyForm.value,this.compId).subscribe(data => {
        if (data.status)
          this.goToList();
      });
    } else {
      this._toast.show('warn', 'Please enter mandatory fields');
    }
  }
  public hasError(controlName: string, errorName: string, groupName?: string) {
    if (groupName)
      return this.companyForm.controls[groupName].get(controlName).hasError(errorName)
    else
      return this.companyForm.controls[controlName].hasError(errorName);
  }

  goToList() {
    this._router.navigate(['hr-operations/company/list']);
  }
}
