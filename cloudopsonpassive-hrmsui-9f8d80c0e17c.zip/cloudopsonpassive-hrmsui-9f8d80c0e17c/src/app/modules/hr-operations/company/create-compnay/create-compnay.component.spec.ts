import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateCompnayComponent } from './create-compnay.component';

describe('CreateCompnayComponent', () => {
  let component: CreateCompnayComponent;
  let fixture: ComponentFixture<CreateCompnayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreateCompnayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateCompnayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
