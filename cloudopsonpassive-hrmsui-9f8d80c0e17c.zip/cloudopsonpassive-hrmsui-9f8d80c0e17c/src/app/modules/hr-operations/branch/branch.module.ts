import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BranchRoutingModule } from './branch-routing.module';
import { BranchListComponent } from './branch-list/branch-list.component';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CreateBranchComponent } from './create-branch/create-branch.component';
import { UpadteBranchComponent } from './upadte-branch/upadte-branch.component';


@NgModule({
  declarations: [
    BranchListComponent,
    CreateBranchComponent,
    UpadteBranchComponent 
  ],
  imports: [
    CommonModule,
    BranchRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgbModule
  ]
})
export class BranchModule { }
