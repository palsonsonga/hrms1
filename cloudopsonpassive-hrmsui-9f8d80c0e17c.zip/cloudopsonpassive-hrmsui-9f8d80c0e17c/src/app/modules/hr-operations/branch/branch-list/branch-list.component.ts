import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { ModalDismissReasons, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.css']
})
export class BranchListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name', 'location', 'contactNo', 'email', 'action'];
  branchList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  closeResult: any;
  deleteBranch: any;
  modalHeader: string = '';
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: BranchService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private router:Router,
    private _ar : ActivatedRoute,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.getAllBranches();
  }

  getAllBranches(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getBranchList(params).subscribe(
      data => {
        console.log(data)
        this.branchList = new MatTableDataSource(data.data);
        this.totalRecords = data.totalRecords;
        this.branchList.sort = this.sort;
        this.pageSize = params['pageSize'];
      });
  }
  goToCreate() {
    this.router.navigate(['../create'],{relativeTo:this._ar});
  } 
  goToUpdate(data){
    console.log(data);
    this.router.navigate(['../update',data.name,btoa(data.id)],{relativeTo:this._ar});
  }
  openDelete(deleteConfirm, branch?) {
    this.deleteBranch = branch;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteBranch(this.deleteBranch.id).subscribe(
      (data: any) => {
        this.getAllBranches();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }
  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  clearSearchText() {
    this.filter.searchKey = '';
    this.getAllBranches();
  }
}
