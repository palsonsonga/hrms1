import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-upadte-branch',
  templateUrl: '../create-branch/create-branch.component.html',
  styleUrls: ['../create-branch/create-branch.component.css']
})
export class UpadteBranchComponent implements OnInit {

  isUpdate:boolean=true;
  brachName: any;
  brachId: any;
  branchForm: FormGroup;
  submitted: boolean = false;
  companies:any[];
  branchData:any;
  constructor(private _service: BranchService,
    public _toast: ToasterService,
    private _companyService : CompanyService,
    public dialog:MatDialog,
    private router:Router,
    private _ar : ActivatedRoute
  ) {
    _ar.paramMap.subscribe(params => {
      console.log("*-*-*-*-",atob(params['params']['id']));
      this.brachName = params['params']['name'];
      this.brachId = atob(params['params']['id']);      
    });    
  }
  ngOnInit(): void {
    this.getCompanies();
    this.branchForm = new FormGroup({
      id: new FormControl(this.brachId),
      name: new FormControl('', [Validators.required,
                                 Validators.pattern('[-A-Za-z ]{3,}')]),
      contactNo: new FormControl('', [Validators.required,
                                      Validators.pattern('[0-9]{6,10}')]),
      location: new FormControl('', [Validators.required]),
      companyId: new FormControl('',[Validators.required]),
      email: new FormControl('', [Validators.required,
                                  Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      fax: new FormControl('',  [Validators.required,
                                 Validators.pattern('[0-9-)(]{6,15}')]),
      address: new FormGroup({
        address: new FormControl('', [Validators.required,
                                      Validators.maxLength(50),
                                      Validators.minLength(3)]),
        street: new FormControl('', [Validators.required,
                                     Validators.maxLength(20),
                                     Validators.minLength(3)]),
        landmark: new FormControl('',[Validators.required,
                                      Validators.maxLength(30),
                                      Validators.minLength(3)]),        
        village: new FormControl('', [Validators.required,
                                      Validators.maxLength(20),
                                      Validators.minLength(3)]),
        district: new FormControl('',[Validators.required,
                                      Validators.maxLength(20),
                                      Validators.minLength(3)]),
        state: new FormControl('', [Validators.required,
                                    Validators.maxLength(20),
                                    Validators.minLength(3)]),
        country: new FormControl('', [Validators.required,
                                      Validators.maxLength(15),
                                      Validators.minLength(3)]),
        pincode: new FormControl('', [Validators.required,
                                      Validators.pattern('[-0-9]*'),
                                      Validators.maxLength(8),
                                      Validators.minLength(5)]),
      }) 
    });
    this.getBranchInfo();
  }
  getBranchInfo(){
    this._service.getBranch(this.brachId).subscribe(data=>{
      this.branchData = data;
      this.branchForm.patchValue(this.branchData);
    });
  }
  getCompanies(){
    this._companyService.getCompaniesDropdown().subscribe(data=>{
      if(data){
        this.companies = data;
      }
    });
  }
  goToList(){
    this.router.navigate(['hr-operations/branch/list']);
  }
  onSubmit() {
     this.submitted=true;
    if(this.branchForm.valid){
      this._service.updateBranch(this.branchForm.value,this.brachId).subscribe(data=>{
        if(data.status)
        this.goToList();
      });
    }else{
      this._toast.show('warn', "please enter mandatory fields");
    }
  }
  
  public hasError(controlName: string, errorName: string, groupName?: string) {
    if (groupName)
      return this.branchForm.controls[groupName].get(controlName).hasError(errorName)
    else
      return this.branchForm.controls[controlName].hasError(errorName);
  }

}
