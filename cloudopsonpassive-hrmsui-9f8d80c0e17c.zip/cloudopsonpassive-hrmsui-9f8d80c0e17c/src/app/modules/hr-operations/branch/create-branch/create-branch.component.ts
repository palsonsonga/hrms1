import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

interface Branch {
  name: string;
}

@Component({
  selector: 'app-create-branch',
  templateUrl: './create-branch.component.html',
  styleUrls: ['./create-branch.component.css']
})
export class CreateBranchComponent implements OnInit {
  
  branchForm: FormGroup;
  submitted: boolean = false;
  companies:any[];
  isUpdate:boolean=false;
  constructor(private _service: BranchService,
    public _toast: ToasterService,
    private _companyService : CompanyService,
    public dialog:MatDialog,
    private router:Router) { }

    goToList(){
      this.router.navigate(['hr-operations/branch/list']);
    }
 

  ngOnInit(): void {
    this.getCompanies();
    this.branchForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z0-9 ]{0,})'),Validators.maxLength(20),Validators.minLength(3)]),
      contactNo: new FormControl('', [Validators.required,
                                      Validators.pattern('[0-9]{6,10}')]),
      location: new FormControl('', [Validators.required]),
      companyId: new FormControl('',[Validators.required]),
      email: new FormControl('', [Validators.required,
                      Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      fax: new FormControl('',  [Validators.required,
                                 Validators.pattern('[0-9-)(]{6,15}')]),
      address: new FormGroup({
        address: new FormControl('', [Validators.required,
                                      Validators.maxLength(50),
                                      Validators.minLength(3)]),
        street: new FormControl('', [Validators.required,
                                     Validators.maxLength(20),
                                     Validators.minLength(3)]),
        landmark: new FormControl('',[Validators.required,
                                      Validators.maxLength(30),
                                      Validators.minLength(3)]),        
        village: new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z ]{0,})'),Validators.maxLength(20),Validators.minLength(3)]),
        district: new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z ]{0,})'),Validators.maxLength(20),Validators.minLength(3)]),
        state:new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z ]{0,})'),Validators.maxLength(20),Validators.minLength(3)]),
        country: new FormControl('', [Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z ]{0,})'),Validators.maxLength(20),Validators.minLength(3)]),
        pincode: new FormControl('', [Validators.required,
                                      Validators.pattern('[-0-9]*'),
                                      Validators.maxLength(8),
                                      Validators.minLength(5)]),
      }) 
    });
  } 
  getCompanies(){
    this._companyService.getCompaniesDropdown().subscribe(data=>{
      if(data){
        this.companies = data;
      }
    })
  }
  onSubmit() {
     this.submitted=true;
    if(this.branchForm.valid){
        this._service.saveBranch(this.branchForm.value).subscribe(data=>{
          if(data.status)
          this.goToList();
        });
      }
         else{
        this._toast.show('warn', "please enter mandatory fields");
      }
  }
  
  public hasError(controlName: string, errorName: string, groupName?: string) {
    if (groupName)
      return this.branchForm.controls[groupName].get(controlName).hasError(errorName)
    else
      return this.branchForm.controls[controlName].hasError(errorName);
  }
}




// Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")