import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { LocalStorageService } from 'src/app/util/local-storage.service';
// Do not touch these below 2 lines
// @ts-ignore
import jwt_decode from 'jwt-decode';
//
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  loading = false;
  submitted = false;
  hide = true;
  constructor(private _router: Router,
              private _service: AuthenticationService,
              private _aRouter: ActivatedRoute,
              private _toaster: ToasterService,
              private _ls: LocalStorageService) { }

  ngOnInit(): void {
    this.loginForm = new FormGroup({
      username: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.submitted = true;
      this.loading = true;
      this._service.login(this.loginForm.value).subscribe(data => {
        if (data.status) {
          this._ls.setLoggedInUser("user", data, true);
          var menu = this._ls.getUserData("menus")[0][0].menuPath;
          this._router.navigate([menu]);
          // token decoding
          /* var decoded = jwt_decode(data.token); 
           console.log(decoded);*/
        } else { }
      });
    }
  }

  goToForgotPassword() {
    this._router.navigate(['forgot-password'], { relativeTo: this._aRouter });
  }
}
