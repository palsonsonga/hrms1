import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LeaveService } from 'src/app/services/leave-management/leave.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { MY_FORMATS } from 'src/app/modals/date.format';
import { LocalStorageService } from 'src/app/util/local-storage.service';
import { LeavesService } from 'src/app/services/hr-operations/leaves.service';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.css'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ]
})
export class ApplyLeaveComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['leaveApplyDate', 'leaveType', 'startDate', 'endDate', 'totalDays', 'status'];
  leaveTypeList: any = [
    { label: 'Earned Leave', value: 'earned' },
    { label: 'Sick Leave', value: 'sick' },
    { label: 'Casual Leave', value: 'casual' },
    { label: 'Loss of pay', value: 'lop' }
  ];
  leavesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  leaveForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  minDate: Date;

  closeResult: any;
  deleteBranch: any;
  modalHeader: string = '';
  submitted: boolean = false;
  loading: boolean = true;

  constructor(private _service: LeaveService,
    public dialog: MatDialog,
    private _lg : LocalStorageService,
    private _leave: LeavesService,
    private _toast: ToasterService,
    private modalService: NgbModal) {
    this.minDate = new Date();
  }

  ngOnInit(): void {
    this.getLeavesList();
    this.getLeaveTypes();
    this.leaveForm = new FormGroup({
      leaveType: new FormControl('', [Validators.required]),
      startDate: new FormControl('', [Validators.required]),
      endDate: new FormControl('', [Validators.required]),
      reason: new FormControl('', [Validators.required])
    });
  }
  getLeaveTypes(){
    this._leave.getLeaveTypes().subscribe(data=>{
      if(data){
        this.leaveTypeList = data;
      }
    });
  }
  getLeavesList(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc') : 'asc'; // be default sorting will be in Ascending order

    this._service.getAppliedLeaves(params).subscribe(
      data => {
        this.leavesList = new MatTableDataSource(data.data);
        this.leavesList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        // this.leavesList.paginator = this.paginator;
        this.pageSize = params['pageSize'];
      });
    // console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getLeavesList();
  }
  sortTable(event) {
    console.log(event);
    this.getLeavesList(null, event);
  }
  applyLeave(content, type: boolean, leave?) {
    this.modalHeader = type ? "Apply" : "Update";
    this.leaveForm.reset();
    if (!type) {
      console.log("leave--", leave);
      this.leaveForm.patchValue(leave, { onlySelf: true });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  onSubmit() {
    this.submitted = true;
    if (this.leaveForm.valid) {
      var date1 = new Date(this.leaveForm.value.startDate);
      var date2 = new Date(this.leaveForm.value.endDate);
      // To calculate the time difference of two dates
      var Difference_In_Time = date2.getTime() - date1.getTime();
      // To calculate the no. of days between two dates
      var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
      this.leaveForm.value['totalDays'] = Difference_In_Days + 1;
      this.leaveForm.value['leaveApplyDate'] = new Date();
      this.leaveForm.value['employeeId'] = this._lg.getUserData('id');
      this.leaveForm.value['emailId'] = this._lg.getUserData('email');
      this._service.applyLeave(this.leaveForm.value).subscribe(data => {
        if (data) {
          console.log(data);
          this.getLeavesList();
          this.modalService.dismissAll();
        }
      });
    }
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.leaveForm.controls[controlName].hasError(errorName);
  }
}
