import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeOnboardRoutingModule } from './employee-onboard-routing.module';
import { EmployeesListComponent } from './employees-list/employees-list.component';
import { EmployeePolicyComponent } from './employee-policy/employee-policy.component';
import { EmployeeProjectComponent } from './employee-project/employee-project.component';
import { EmployeeResourcesComponent } from './employee-resources/employee-resources.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';
import { AngularDualListBoxModule } from 'angular-dual-listbox';
import { NgxMaskModule } from 'ngx-mask';


@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeePolicyComponent,
    EmployeeProjectComponent,
    EmployeeRegisterComponent,
    UpdateEmployeeComponent,
    EmployeeResourcesComponent
  ],
  imports: [
    CommonModule,
    EmployeeOnboardRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    MaterialModule,
    NgxMatSelectSearchModule,
    AngularDualListBoxModule,
    NgxMaskModule.forRoot(),
    // NgMultiSelectDropDownModule.forRoot()
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})
export class EmployeeOnboardModule { }
