import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeePolicyComponent } from './employee-policy/employee-policy.component';
import { EmployeeProjectComponent } from './employee-project/employee-project.component';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { EmployeeResourcesComponent } from './employee-resources/employee-resources.component';
import { EmployeesListComponent } from './employees-list/employees-list.component';
import { UpdateEmployeeComponent } from './update-employee/update-employee.component';

const routes: Routes = [
  /*{
    path:'',
    redirectTo: 'list'
  },*/
  {
    path:'',
    component: EmployeesListComponent    
  },
  {
    path:'register',
    component: EmployeeRegisterComponent,
    data:{
      breadcrumb :'Register Employee'
    }
  },
  {
    path:'update/:name/:id',
    component: UpdateEmployeeComponent,
    data:{
      breadcrumb :'Update Employee'
    }
  },
  {
    path:'policy/:name/:id',
    component: EmployeePolicyComponent,
    data:{
      breadcrumb :'Employee Policy'
    }
  },
  {
    path:'project',
    component: EmployeeProjectComponent,
    data:{
      breadcrumb :'Employee Projects'
    }
  },
  {
    path:'resources/:name/:id',
    component: EmployeeResourcesComponent,
    data:{
      breadcrumb :'Employee Resources'
    }
  },
  {
    path:'projects/:name/:id',
    component: EmployeeProjectComponent,
    data:{
      breadcrumb :'Employee Projects'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeOnboardRoutingModule { }
