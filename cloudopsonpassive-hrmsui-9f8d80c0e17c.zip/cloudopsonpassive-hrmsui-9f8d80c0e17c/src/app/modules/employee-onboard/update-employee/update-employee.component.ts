import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MY_FORMATS } from 'src/app/modals/date.format';
import { DepartmentService } from 'src/app/services/hr-operations/department.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-update-employee',
  templateUrl: '../employee-register/employee-register.component.html',
  styleUrls: ['../employee-register/employee-register.component.css'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class UpdateEmployeeComponent implements OnInit {

  employeeForm: FormGroup;
  submitted: boolean = false;
  isUpdate:boolean=true;
  maritalStatus: any = [
    { label: 'Un Married', value: 'unmarried' },
    { label: 'Married', value: 'married' },
    { label: 'Divorsed', value: 'divorsed' },
  ];
  bloodGroup: any = [
    { label: 'A +ve', value: 'A+ve' },
    { label: 'A -ve', value: 'A-ve' },
    { label: 'B +ve', value: 'B+ve' },
    { label: 'B -ve', value: 'B-ve' },
    { label: 'AB +ve', value: 'AB+ve' },
    { label: 'AB -ve', value: 'AB-ve' },
    { label: 'O +ve', value: 'O+ve' },
    { label: 'O -ve', value: 'O-ve' },
    { label: 'Other', value: 'other' },
  ];
  roles: string[] = ["HR", "HR Manager", "Manager", "Branch Manager", "Team Lead", "Software Engineer", "Senior Software Engineer"];
  deparments: string[] = ["Administration", "Java", "Angular", "Testing QA", "UI/UX Developer"];
  myFilter = (d: Date | null): boolean => {
    const day = (d || new Date()).getDay();
    // Prevent Saturday and Sunday from being selected.
    return day !== 0 && day !== 6;
  };
  maxDate = new Date();
  dummyDate:any;
  dummyDate1:any;
  empName:any;
  empId:any;
  employeeData:any;
  myFiles: any = [];
  uploadedFiles: string[] = [];
  profileImg:any;
  fileTypes = environment.fileTypes;
  imageTypes = environment.imageTypes;
  constructor(private formBuilder: FormBuilder,
    private _service: EmployeeOnboardingService,
    private _deptService : DepartmentService,
    private _router: Router,
    private _ar : ActivatedRoute,
    private _toast: ToasterService,
  ) { 
    const currentYear = new Date().getFullYear();
    this.dummyDate = new Date(currentYear - 25, 2, 11);
    this.dummyDate1 = new Date(currentYear, 5, 24);
    _ar.paramMap.subscribe(params => {
      console.log(params['params']['name']);
      this.empName = params['params']['name'];
      this.empId = atob(params['params']['id']);
    });
    console.log(this.empId);    
  }

  ngOnInit(): void {
    this.employeeForm = this.formBuilder.group({
      // Basic details
      id:new FormControl(''),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      gender: new FormControl(''),
      contactNo: new FormControl('', [Validators.required, Validators.minLength(6), Validators.pattern('[0-9 ]*')]),
      alternateContactNo: new FormControl('', [Validators.minLength(6), Validators.pattern('[0-9 ]*')]),
      email: new FormControl('', [Validators.email, Validators.required]),
      userName: new FormControl(''),
      dateOfBirth: new FormControl('', [Validators.required]),
      bloodGroup: new FormControl('', [Validators.required]),
      maritalStatus: new FormControl('', [Validators.required]),
      joiningDate: new FormControl('', [Validators.required]),
      image: new FormControl(''),
      addresses: this.formBuilder.group({
        isSameAddress:new FormControl(''),
        temporary: this.formBuilder.group({
          // Temporary Address fields
          id:new FormControl(''),
          address: new FormControl(''),
          landmark: new FormControl(''),
          street: new FormControl(''),
          village: new FormControl(''),
          district: new FormControl(''),
          state: new FormControl(''),
          country: new FormControl(''),
          pincode: new FormControl(''),
        }),
        permanant: this.formBuilder.group({
          // Permanant Address fields
          id:new FormControl(''),
          address: new FormControl(''),
          landmark: new FormControl(''),
          street: new FormControl(''),
          village: new FormControl(''),
          district: new FormControl(''),
          state: new FormControl(''),
          country: new FormControl(''),
          pincode: new FormControl(''),
        }),
      }),
      //academic details
      academicDetails: this.formBuilder.group({
        higher: this.setUpEducation(),
        postGraduation: this.setUpEducation(),
        graduation: this.setUpEducation(),
        intermediate: this.setUpEducation(),
        ssc: this.setUpEducation(),
        others: this.setUpEducation(),
      }),
      // professional details
      professionalDetails: new FormArray([]),
      professionalFields: this.getProfessionalForm(),
      bankDetail: this.formBuilder.group({
        // Bank account fields
        id:new FormControl(''),
        bankName: new FormControl(''),
        branchName: new FormControl(''),
        ifscCode: new FormControl(''),
        accountNo: new FormControl(''),
        accountHolderName: new FormControl(''),
      }),
      // company related fields
      departmentId: new FormControl('',[Validators.required]),
      designationId: new FormControl(''),
      aadharCard: new FormControl(''),
      panCard: new FormControl(''),
      voterID: new FormControl(''),
      files: new FormControl('')
    });
    this.getDepartmentsList();
    this.getEmployeeInfo();
  }
  get professionalInfo(){
    return (this.employeeForm.get('professionalDetails') as FormArray);
  }
  getProfessionalForm(){
    return this.formBuilder.group({
        companyName: new FormControl(''),
        joiningDate: new FormControl(''),
        relievingDate: new FormControl(''),
        experience: new FormControl(''),
        client: new FormControl('')
    });
  }
  setUpEducation() {
    return this.formBuilder.group({
      instituteName: new FormControl(''),
      yearOfPassing: new FormControl(''),
      type: new FormControl(''),
      percentage: new FormControl('')
    });
  }
  showExperienceForm : boolean = false;
  addExperience(){
    console.log(this.professionalInfo.controls);
    /*this.professionalInfo.insert(0,this.formBuilder.group({
      companyName: new FormControl(''),
      joiningDate: new FormControl(''),
      relievingDate: new FormControl(''),
      experience: new FormControl(''),
      client: new FormControl('')
    }));*/
    this.showExperienceForm = true;
  }
  resetExpereince() {
    this.showExperienceForm=false;
    this.employeeForm.get('professionalFields.companyName').setValue('');
    this.employeeForm.get('professionalFields.joiningDate').setValue('');
    this.employeeForm.get('professionalFields.relievingDate').setValue('');
    this.employeeForm.get('professionalFields.experience').setValue('');
    this.employeeForm.get('professionalFields.client').setValue('');
  }
  addToExperienceList() {
    this.professionalInfo.insert(this.professionalInfo.controls.length,
                                  this.formBuilder.group({
                                    companyName: new FormControl(this.employeeForm.value.professionalFields.companyName),
                                    joiningDate: new FormControl(this.employeeForm.value.professionalFields.joiningDate),
                                    relievingDate: new FormControl(this.employeeForm.value.professionalFields.relievingDate),
                                    experience: new FormControl(this.employeeForm.value.professionalFields.experience),
                                    client: new FormControl(this.employeeForm.value.professionalFields.client)
                                  }));
    this.resetExpereince();
  }
  getEmployeeInfo(){
    this._service.getEmployee(this.empId).subscribe(data=>{
      if(data)
      this.employeeData= data;
      this.uploadedFiles = data.files;
      this.profileImg = data.profileiamge;
      delete this.employeeData.files;
      console.log("*-*---",this.myFiles);
      this.employeeForm.patchValue(this.employeeData);
    });
  }
  getDepartmentsList(){
    this._deptService.getDepartmentDropdown().subscribe(data=>{
      if(data){
        console.log(data);
        this.deparments = data;
      }
    });
  }
  getDesignation(event){
    console.log(event);
  }
  onFileChange(event) {
    console.log(event.target.files);
    /*for (var i = 0; i < event.target.files.length; i++) {
      this.myFiles.push(event.target.files[i]);
    }*/
    if (event.target.files.length > 0) {
      Object.keys(event.target.files).forEach( key => {
        console.log(event.target.files[key].type);
        if(this.fileTypes.indexOf(event.target.files[key].type)> -1){
          // event.target.files[key].sizeVal = this.bytesToSize(event.target.files[key].size);        
          this.myFiles.push(event.target.files[key]);
        }
        else {
          this.myFiles=[];
          this._toast.show('warning','No file uploaded or invalid file type!');
          this.employeeForm.patchValue({
            files:''
          })
          return false;
        }
      });     
    }
  }
  onProfileChange(event){
   // this.profileImg = event.target.files[0];

    if (event.target.files.length > 0) {
      Object.keys(event.target.files).forEach( key => {        
        if(this.imageTypes.indexOf(event.target.files[key].type)> -1) {
          // event.target.files[key].sizeVal = this.bytesToSize(event.target.files[key].size);        
          this.profileImg = event.target.files[key];
        }
        else {
          this.profileImg='';
          this._toast.show('warning','No file uploaded or invalid file type!');
          this.employeeForm.patchValue({
            image:''
          })
          return false;
        }
      });     
    }
  }
  onSubmit(event?: any) {
    this.submitted = true;
    if (this.employeeForm.valid) {
      const formData = new FormData();
      for (var i = 0; i < this.myFiles.length; i++) {
        formData.append("files", this.myFiles[i]);
      }
      delete this.employeeForm.value.files;
      delete this.employeeForm.value.image;
      delete this.employeeForm.value.addresses.isSameAddress;
      delete this.employeeForm.value.professionalFields;
      var employee = this.employeeForm.value;
      employee['branchId']=1;
      employee['companyId']=1;
      formData.append("employee", JSON.stringify(employee));
      formData.append("image", this.profileImg);
      this._service.updateEmployee(formData,this.empId).subscribe(data => {
        this.goToList();
      });
    } else {
      this._toast.show('warn', 'Please enter mandatory fields');
    }
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.employeeForm.controls[controlName].hasError(errorName);
  }

  goToList() {
    this._router.navigate(['employee-onboard']);
  }
  sameAddress(isChecked){
    //console.log(this.employeeForm.value.addresses.temporary);
    //console.log(this.employeeForm.controls['addresses'].get('permanant').value);
    if(isChecked){
      this.employeeForm.controls['addresses'].get('permanant').setValue(this.employeeForm.value.addresses.temporary);
    }
  }

  deleteLocalFile(file,indx) {
    this.myFiles.splice(indx,1);
  }

  deleteFile(file) {
    this._service.deleteFile(this.empId,file.id).subscribe(data=>{
      if(data){
        this.getEmployeeInfo();
      }
    });
  }
}
