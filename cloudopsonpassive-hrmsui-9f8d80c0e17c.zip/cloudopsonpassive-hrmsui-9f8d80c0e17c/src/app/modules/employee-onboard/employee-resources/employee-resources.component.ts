import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { MatSelect } from '@angular/material/select';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';
import { AssetsService } from 'src/app/services/hr-operations/assets.service';

@Component({
  selector: 'app-employee-resources',
  templateUrl: './employee-resources.component.html',
  styleUrls: ['./employee-resources.component.css']
})
export class EmployeeResourcesComponent implements OnInit, OnDestroy {

  empName: any;
  empId: any;
  resourceForm: FormGroup;
  submitted: boolean = false;
  dropdownList = [];
  selectedItems = [];
  resources:any;
  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;
  protected _onDestroy = new Subject<void>();
  constructor(private _service: EmployeeOnboardingService,
    private _router: Router,
    private formBuilder: FormBuilder,
    private _assets: AssetsService,
    private _ar: ActivatedRoute,
    private _toast: ToasterService,
  ) {
    _ar.paramMap.subscribe(params => {
      console.log(params['params']['name']);
      this.empName = params['params']['name'];
      this.empId = atob(params['params']['id']);
    });
  }

  ngOnInit(): void {
    this.resourceForm = this.formBuilder.group({
      ipAddress: new FormControl('', [Validators.pattern('[0-9. ]*')]),
      port: new FormControl('', [Validators.pattern('[0-9]*'), Validators.maxLength(5)]),
      resourceItems: new FormArray([]),
      selectedItems: new FormControl(''),
    });
    this._assets.getAssetsList().subscribe(data=>{
      this.dropdownList = data;
    });
    this.getEmployeeInfo();
  }
  getEmployeeInfo(){
    this._service.getEmployee(this.empId).subscribe(data=>{
      if(data){
        this.resources= data.resourceItems;
        console.log("*-*---",this.resources);
        this.resourceForm.patchValue(this.resources);
        if(this.resources.items){
          this.resources.items.forEach((o,i) => {
            console.log(o,"----o");
            this.dynamicFields.insert(i, this.formBuilder.group({
              name: new FormControl(o.name),
              assetId: new FormControl(o.id),
              description: new FormControl(o.description),
              value: new FormControl(o.value)
            }));
          });
        }
      }        
    });
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }
  get f() { return this.resourceForm.controls; }
  get dynamicFields() {
    return this.f.resourceItems as FormArray;
  }
  onSubmit() {
    this.submitted = true;
    console.log(this.resourceForm.value);
    delete this.resourceForm.value.selectedItems;
    var params={};
    params = this.resourceForm.value;
    // params['employeeId'] = this.empId;
    if (this.resourceForm.valid) {
      this._service.updateResources(params,this.empId).subscribe(data=>{
        if(data){
          console.log(data);
          this.goToList();
        }
      });
    } else {
      this._toast.show('warn', 'Please Enter mandatory fields');
    }
  }
  onItemSelect(item: any) {
    let frmArray = this.resourceForm.get('resourceItems') as FormArray;
    frmArray.clear();
    item.value.forEach((obj, i) => {
      var fieldKey = obj['name'].toString().split(' ').join('');
      if (fieldKey) {
        console.log("*-*-*-*",obj);
        this.dynamicFields.insert(i, this.formBuilder.group({
          name: new FormControl(fieldKey),
          assetId: new FormControl(obj.id),
          description: new FormControl(obj.description),
          value: new FormControl('')
        }));
      }
    });
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.resourceForm.controls[controlName].hasError(errorName);
  }
  goToList() {
    this._router.navigate(['employee-onboard']);
  }
}
