import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AttendanceInfoComponent } from './attendance-info/attendance-info.component';
import { AttendanceListComponent } from './attendance-list/attendance-list.component';

const routes: Routes = [
  {
    path:'',
    component: AttendanceListComponent
  },
  {
    path:'attendance-info',
    component: AttendanceInfoComponent,
    data:{
      breadcrumb :'Attendance-info'
    }
  }
    
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AttendanceRoutingModule { }
