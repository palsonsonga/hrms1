import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AttendanceService } from 'src/app/services/attendance.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-attendance-list',
  templateUrl: './attendance-list.component.html',
  styleUrls: ['./attendance-list.component.css']
})
export class AttendanceListComponent implements OnInit {
  attendanceForm: FormGroup;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['employeeId', 'employeeName', 'date', 'inTime', 'outTime', 'hours'];
  attendanceList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  branchForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteBranch: any;
  modalHeader: string = '';
  submitted: boolean = false;
  loading: boolean = true;
  isListVisible: boolean;

  constructor(private _service: AttendanceService,private formBuilder: FormBuilder,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {    
    this.initValidation();
   // this.getAttendanceList();
   this.attendanceForm = this.formBuilder.group({
    files: new FormControl('')
   });
   
  }

  initValidation()
  {
    this.isListVisible = true;
  }
  getAttendanceList(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getAttendanceSheet(params).subscribe(
      data => {
        this.attendanceList = new MatTableDataSource([
          {employeeId:101011, employeeName: 'John Kate', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101026, employeeName: 'James', date: new Date(), inTime:'11:00 AM', outTime: '08:15 PM', hours: '09:15'},
          {employeeId:101028, employeeName: 'Praveen Kumar', date: new Date(), inTime:'10:30 AM', outTime: '07:00 PM', hours: '08:30'},
          {employeeId:101012, employeeName: 'Mallikarjun', date: new Date(), inTime:'10:05 AM', outTime: '07:15 PM', hours: '09:10'},
          {employeeId:101013, employeeName: 'Patlola Swetha', date: new Date(), inTime:'09:50 AM', outTime: '07:00 PM', hours: '09:10'},
          {employeeId:101045, employeeName: 'Madanala Jairam', date: new Date(), inTime:'10:40 AM', outTime: '07:00 PM', hours: '08:40'},
          {employeeId:101055, employeeName: 'Manikanta', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101056, employeeName: 'Suresh', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101078, employeeName: 'Ramesh', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101089, employeeName: 'Harish K', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101044, employeeName: 'Nithin T', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101066, employeeName: 'Gopi Krishna', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101033, employeeName: 'Anil Reddy', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101022, employeeName: 'Sachin Tendulkar', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101010, employeeName: 'Dravid', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101099, employeeName: 'Srinivas', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101085, employeeName: 'Mahendra Singh', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101075, employeeName: 'Krishnaveni kathi', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'},
          {employeeId:101071, employeeName: 'Yogitha Dasari', date: new Date(), inTime:'10:00 AM', outTime: '07:15 PM', hours: '09:15'}
        ]);
        this.attendanceList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        // this.attendanceList.paginator = this.paginator;
        this.pageSize = params['pageSize'];
      });
    // console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAttendanceList();
  }
  sortTable(event) {
    console.log(event);
    this.getAttendanceList(null, event);
  }


  myFiles: string[] = [];
  onFileChange(event) {
   
    for (var i = 0; i < event.target.files.length; i++) {
      this.myFiles.push(event.target.files[i]);
    }
    const formData = new FormData();
      for (var i = 0; i < this.myFiles.length; i++) {
        formData.append("file", this.myFiles[i]);
      }
      delete this.attendanceForm.value.files;
     // var attendance = this.attendanceForm.value;
     // formData.append("file", JSON.stringify(attendance));
      this._service.uploadAttendanceSheet(formData).subscribe(data => {
          console.log(data);
          if(data.status == true)
          {
              this.isListVisible = true;
              //cal list api pending
          }else{
            // export error csv to be shown with link to download
          }
        });
        this.myFiles = [];
  }
  clearSearchText() {
    this.filter.searchKey = '';
    this.getAttendanceList();
  }
  
}
