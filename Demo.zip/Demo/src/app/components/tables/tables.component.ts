import { ViewChild } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { TableService } from 'src/app/_services/table.service';

@Component({
  selector: 'app-tables',
  templateUrl: './tables.component.html',
  styleUrls: ['./tables.component.css']
})
export class TablesComponent implements OnInit {

  @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  data = new MatTableDataSource();
  currentUser
  pageIndex = 0;
  pageSize = 2;
  displayedColumns: string[] = ['Project', 'Budget', 'Status', 'Users', 'Completion', 'actions'];
  constructor(
    private _Service: TableService
  ) {}

  ngOnInit() {
    this.loadAlldata();
  }

  loadAlldata() {
    let list: any = this._Service.getData()
    this.data = new MatTableDataSource(list)
    this.data.paginator = this.paginator;
    this.data.sort = this.sort;
  }

  applyFilter(value) {
    this.data.filter = value.trim().toLowerCase()
  }
  getColor(num) {
    if (num >= 90) {
      return 'green'
    }
    else if (num >= 50) {
      return 'blue'
    }
    else return 'red'
  }

  open(val){

  }
}
