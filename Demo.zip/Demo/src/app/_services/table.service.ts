import { ThrowStmt } from '@angular/compiler';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

const data =[
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:90},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:40},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60},
  {project:'pro',budget:'$1255',status:'pending',users:['arjun','john','sam'],completion:60}
     ]
@Injectable({
  providedIn: 'root'
})
export class TableService {
proData
  constructor() { }

  getData():Observable<any>{
    this.proData=data
    return this.proData
  }
  
}
