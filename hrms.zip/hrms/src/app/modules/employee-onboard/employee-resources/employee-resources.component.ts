import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { MatSelect } from '@angular/material/select';
import { ReplaySubject, Subject } from 'rxjs';
import { take, takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-employee-resources',
  templateUrl: './employee-resources.component.html',
  styleUrls: ['./employee-resources.component.css']
})
export class EmployeeResourcesComponent implements OnInit, AfterViewInit, OnDestroy {

  empName: any;
  selectedItemsFilter: any;
  empId: any;
  resourceForm: FormGroup;
  submitted: boolean = false;
  ipAddress: any;
  port: any;  
  dropdownList = [];
  selectedItems = [];
  dropdownSettings = {};

  @ViewChild('multiSelect', { static: true }) multiSelect: MatSelect;
  protected _onDestroy = new Subject<void>();

  /** list of banks */
  protected banks: any = [
                          { id: 1, text: 'Laptop' },
                          { id: 2, text: 'Monitor' },
                          { id: 3, text: 'Mouse' },
                          { id: 4, text: 'Keyboard' },
                          { id: 5, text: 'Second Monitor' },
                          { id: 6, text: 'Headset' },
                          { id: 7, text: 'Blutooth' },
                          { id: 8, text: 'Dongle' },
                          { id: 9, text: 'USB Cable' },
                          { id: 10, text: 'Pen Drive' },
                          { id: 11, text: 'External Hard Disk' },
                          { id: 12, text: 'Laptop Charger' }
                        ];

  /** control for the selected bank for multi-selection */
  public bankMultiCtrl: FormControl = new FormControl();

  /** control for the MatSelect filter keyword multi-selection */
  public bankMultiFilterCtrl: FormControl = new FormControl();

  /** list of banks filtered by search keyword */
  public filteredBanksMulti: ReplaySubject<any> = new ReplaySubject<any>(1);

  constructor(private _service: EmployeeOnboardingService,
    private _router: Router,
    private formBuilder: FormBuilder,
    private _ar: ActivatedRoute,
    private _toast: ToasterService,
  ) {
    const currentYear = new Date().getFullYear();
    _ar.paramMap.subscribe(params => {
      console.log(params['params']['name']);
      this.empName = params['params']['name'];
      this.empId = atob(params['params']['id']);
    });
  }

  ngOnInit(): void {
    this.resourceForm = this.formBuilder.group({
      ipAddress: new FormControl('', [Validators.pattern('[0-9. ]*')]),
      port: new FormControl('', [Validators.pattern('[0-9]*'), Validators.maxLength(5)]),
      items: new FormArray([]),
      selectedItems: new FormControl(''),
      selectedItemsFilter: new FormControl(''),
    });

    this.dropdownList = [
      { id: 1, text: 'Laptop' },
      { id: 2, text: 'Monitor' },
      { id: 3, text: 'Mouse' },
      { id: 4, text: 'Keyboard' },
      { id: 5, text: 'Second Monitor' },
      { id: 6, text: 'Headset' },
      { id: 7, text: 'Blutooth' },
      { id: 8, text: 'Dongle' },
      { id: 9, text: 'USB Cable' },
      { id: 10, text: 'Pen Drive' },
      { id: 11, text: 'External Hard Disk' },
      { id: 12, text: 'Laptop Charger' }
    ];
    this.selectedItems = [];
    this.dropdownSettings = {
      singleSelection: false,
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 8,
      limitSelection: 3,
      enableCheckAll: false,
      allowSearchFilter: true
    };
  }
  ngAfterViewInit() {
    this.setInitialValue();
    console.log(this.filteredBanksMulti);
  }

  ngOnDestroy() {
    this._onDestroy.next();
    this._onDestroy.complete();
  }
  get f() { return this.resourceForm.controls; }
  get dynamicFields() {

    return this.f.items as FormArray;
  }
  onSubmit() {
    this.submitted = true;
    delete this.resourceForm.value.selectedItems;
    delete this.resourceForm.value.selectedItemsFilter;
    console.log(this.resourceForm.value);
    if (this.resourceForm.valid) {
      this._toast.show('success', 'Resources added Successfully!');
      this.goToList();
    } else {
      this._toast.show('warn', 'Please Enter mandatory fields');
    }

  }
  onItemSelect(item: any) {
    let frmArray = this.resourceForm.get('items') as FormArray;
    frmArray.clear();
    item.value.forEach((obj, i) => {
      var fieldKey = obj['text'].toString().split(' ').join('');
      if (fieldKey) {
        this.dynamicFields.insert(i, this.formBuilder.group({
          type: new FormControl(fieldKey),
          value: new FormControl('')
        }));
      }
    });
  }

  /*onItemRemove(item: any) {
    console.log(item.value);
    var fieldKey = item['text'].toString().split(' ').join('');
    this.dynamicFields.value.forEach((o, i) => {
      if (o.type == fieldKey) {
        this.dynamicFields.removeAt(i);
      }
    });
  }
  onSelectAll(items: any) {
    console.log(items);
    items.forEach(element => {
      var fieldKey = element['text'].toString().split(' ').join('');
      if (this.dynamicFields.value.length > 0) {
        this.dynamicFields.value.forEach((o, i) => {
          if (o.type == fieldKey) { }
          else {
            this.dynamicFields.push(this.formBuilder.group({
              type: new FormControl(fieldKey),
              value: new FormControl('')
            }));
          }
        });
      } else {}
    });
    console.log(this.resourceForm.value);
  }*/

  public hasError = (controlName: string, errorName: string) => {
    return this.resourceForm.controls[controlName].hasError(errorName);
  }
  goToList() {
    this._router.navigate(['employee-onboard']);
  }

  
  /**
   * Sets the initial value after the filteredBanks are loaded initially
   */
  protected setInitialValue() {
    this.filteredBanksMulti
      .pipe(take(1), takeUntil(this._onDestroy))
      .subscribe(() => {
        // setting the compareWith property to a comparison function
        // triggers initializing the selection according to the initial value of
        // the form control (i.e. _initializeSelection())
        // this needs to be done after the filteredBanks are loaded initially
        // and after the mat-option elements are available
        this.multiSelect.compareWith = (a: any, b: any) => a && b && a.id === b.id;
      });
  }

  protected filterBanksMulti() {
    if (!this.banks) {
      return;
    }
    // get the search keyword
    let search = this.selectedItemsFilter.value;
    if (!search) {
      this.filteredBanksMulti.next(this.banks.slice());
      return;
    } else {
      search = search.toLowerCase();
    }
    // filter the banks
    this.filteredBanksMulti.next(
      this.banks.filter(bank => bank.text.toLowerCase().indexOf(search) > -1)
    );
  }
}
