import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators ,AbstractControl} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';


@Component({
  selector: 'app-create-compnay',
  templateUrl: './create-compnay.component.html',
  styleUrls: ['./create-compnay.component.css']
})
export class CreateCompnayComponent implements OnInit {

  companyForm: FormGroup;
  submitted: boolean = false;

  constructor(private _service: CompanyService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private router: Router,
    private _ar: ActivatedRoute) { }

  ngOnInit(): void {
    this.companyForm = new FormGroup({
      id:new FormControl(''),
      name: new FormControl('', [ Validators.required, Validators.pattern('([a-zA-Z]{3,})([-A-Za-z0-9 ]{0,})'),Validators.maxLength(20) ]),
      contact: new FormControl('', [Validators.required, Validators.pattern('(?:8|9|7|6)([0-9]{9,9})')]),
      email: new FormControl('', [Validators.required,
      Validators.pattern("^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")]),
      website: new FormControl('', [Validators.required,
      Validators.pattern("(https?://)?(?:((www)+\\.([a-z]{1,})([a-zA-Z0-9]{2,})+\\.[a-z]{2,4}$)|(([a-z]{1,})([a-zA-Z0-9]{2,})+\\.[a-z]{2,4}$))")]),
      address: new FormGroup({
        address: new FormControl('', [Validators.required,Validators.pattern('([a-zA-Z]{3,})([-A-Za-z0-9, ]{0,})'), Validators.maxLength(40),Validators.minLength(3)]),
        country: new FormControl('', [Validators.required, Validators.maxLength(15),Validators.minLength(3)]),
        district: new FormControl('', [Validators.required, ,Validators.maxLength(20),Validators.minLength(3)]),
        landmark: new FormControl('', [Validators.required, ,Validators.maxLength(30),Validators.minLength(3)]),
        pincode: new FormControl('', [Validators.required,this.pincodeValidator, Validators.pattern('[0-9]*'),Validators.maxLength(8),Validators.minLength(6),]),
        state: new FormControl('', [Validators.required, Validators.maxLength(20),Validators.minLength(3)]),
        street: new FormControl('', [Validators.required, ,Validators.maxLength(20),Validators.minLength(3)]),
        village: new FormControl('', [Validators.required,Validators.maxLength(20),Validators.minLength(3)])
      })
    });
  }
  pincodeValidator(control: AbstractControl):{[key:string]: boolean} | null {
    if(control.value!== null && control.value <=10000){
          return {'pincodeValidator': true}
      }
      return null;
    };

  public hasError(controlName: string, errorName: string, groupName?: string) {
    if (groupName)
      return this.companyForm.controls[groupName].get(controlName).hasError(errorName)
    else
      return this.companyForm.controls[controlName].hasError(errorName);
  }
  onSubmit() {
    this.submitted = true;
    if (this.companyForm.valid) {
      this._service.saveCompany(this.companyForm.value).subscribe(data => {
        if (data.status)
          this.goToList();
      });
    } else {
      this._toast.show('warn', "Please enter mandatory fields");
    }
  }
  goToList() {
    this.router.navigate(['../'], { relativeTo: this._ar });
  }

}
