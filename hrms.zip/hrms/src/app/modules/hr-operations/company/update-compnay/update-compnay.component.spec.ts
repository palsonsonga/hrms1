import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateCompnayComponent } from './update-compnay.component';

describe('UpdateCompnayComponent', () => {
  let component: UpdateCompnayComponent;
  let fixture: ComponentFixture<UpdateCompnayComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdateCompnayComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateCompnayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
