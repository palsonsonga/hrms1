import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { PolicyService } from 'src/app/services/hr-operations/policy.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.css']
})
export class PolicyComponent implements OnInit,OnDestroy {

 
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name', 'attachmentLink', 'action'];
  policyList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  policyForm: FormGroup;
  imagePreview
  file 
  filechosen
  formate=['png','jpg','txt','pdf'];
  maxSize=500000;
  minSize=10000;
  policyData=[];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deletePolicy: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: PolicyService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private _router: Router,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.policyForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required,
                                 Validators.minLength(3),
                                 Validators.pattern('[a-zA-Z ]*')]),
      // attachmentLink:new FormControl(''),
    description: new FormControl('')
    });
    this.getAllPolicies();
  }

  myFiles: string[] = [];
  onFileChange(event) {
    console.log(event.target.files);
    for (var i = 0; i < event.target.files.length; i++) {
      this.myFiles.push(event.target.files[i]);
    }
  }
  // onAttachmentPicked(event:Event){
  //   const file=(event.target as HTMLInputElement).files[0];
  //   console.log(this.policyForm)
  //   var ext = file.name.substring(file.name.lastIndexOf('.')+ 1);
  //   console.log(ext)
  //   let i
  //   for(i=0; i<this.formate.length; i++){
  //     if(ext.toLowerCase()==this.formate[i]){
  //       this.filechosen=true
  //       break
  //     }else {
  //       this.filechosen=false
  //       console.log('called')
  //     }
  //   }

  //   if((this.filechosen==true)&& file.size <this.maxSize){
  //     this.policyForm.get('attachmentLink').updateValueAndValidity();
  //     const reader =new FileReader();
  //     console.log(this.policyForm.get('attachmentLink'))
  //     console.log(file)
  //     this.file = file.name 
  //     reader.onload = () => {
  //       this.imagePreview=reader.result;
  //       // console.log(this.imagePreview)
  //     };
  //     reader.readAsDataURL(file);
  //   }else {
  //     this.policyForm.get('attachmentLink').reset()
  //     this.filechosen=false
  //     this.file=null
  //   }
  // }

ngOnDestroy(){
  this.filechosen=null
  this.file=null
}
  getAllPolicies(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getPolicyList(params).subscribe(
      data => {
        this.policyList = new MatTableDataSource(data.data);
        this.totalRecords = data.totalRecords;
        this.policyList.sort = this.sort;
        this.pageSize = params['pageSize'];
      });
  }
  
  getPolicyId() {
    if (this.policyForm.value.id)
      return this.policyForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update policy
  */

onSubmit(event?: any) {
  // debugger;
    this.submitted = true;
    if (this.policyForm.valid) {
      const formData = new FormData();
      for (var i = 0; i < this.myFiles.length; i++) {
        formData.append("file", this.myFiles[i]);
      }
      delete this.policyForm.value.files;
      //delete this.policyForm.value.addresses.isSameAddress;
      var policy = this.policyForm.value;
      //  policy['policyId']=2;
      
       formData.append("policy", JSON.stringify(policy));

        this._service.savePolicy(formData).subscribe(data => {
          console.log(data);
          this.goToList();
          this.getAllPolicies();
        });
        this.modalService.dismissAll();
    } else {
      this._toast.show('warn', 'Please enter mandatory fields');
    }
  }
  goToList() {
    this._router.navigate(['policy']);
  }
  open(content, type: boolean, policy?) {
    this.modalHeader = type ? "Create" : "Update";
    this.policyForm.reset();
    if (!type) {
      console.log("policy--", policy);
      this.policyForm.patchValue(policy, { onlySelf: true });

    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, policy?) {
    this.deletePolicy = policy;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deletePolicy(this.deletePolicy.id).subscribe(
      (data: any) => {
        this.getAllPolicies();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }
  

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.policyForm.controls[controlName].hasError(errorName);
  }

}
