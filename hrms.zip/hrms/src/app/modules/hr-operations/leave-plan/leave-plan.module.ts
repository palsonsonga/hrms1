import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeavePlanListComponent } from './leave-plan-list/leave-plan-list.component';
import { LeavePlanRoutingModule } from './leave-plan-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';



@NgModule({
  declarations: [LeavePlanListComponent],
  imports: [
    CommonModule,
    LeavePlanRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgbModule
  ]
})
export class LeavePlanModule { }
