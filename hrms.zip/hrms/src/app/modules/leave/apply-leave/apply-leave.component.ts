import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormControlName, FormGroup, Validators } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { LeaveService } from 'src/app/services/leave-management/leave.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { MY_FORMATS } from 'src/app/modals/date.format';

@Component({
  selector: 'app-apply-leave',
  templateUrl: './apply-leave.component.html',
  styleUrls: ['./apply-leave.component.css'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MY_FORMATS},
  ]
})
export class ApplyLeaveComponent implements OnInit {
  
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['appliedDate', 'fromDate', 'toDate', 'totalDays', 'status'];
  leaveTypeList:any = [
    // {label:'Earned Leave',value:'earned'},
    // {label:'Sick Leave',value:'sick'},
    // {label:'Casual Leave',value:'casual'},
    // {label:'Loss of pay',value:'lop'}
  ];
  leavesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  leaveForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  minDate:Date;

  closeResult: any;
  deleteBranch: any;
  modalHeader: string = '';
  submitted: boolean = false;
  loading: boolean = true;
  LeavePlan:any[];

  constructor(private _service: LeaveService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private _leavesService:LeaveService,
    private modalService: NgbModal) { 
      this.minDate = new Date();
  }

  ngOnInit(): void {    
    this.getLeavesList();
    this.leaveForm = new FormGroup({
      leaveType : new FormControl('',[Validators.required]),
      fromDate : new FormControl('', [Validators.required]),
      toDate : new FormControl('', [Validators.required]),
      reason : new FormControl('', [Validators.required])
    });
  }

  getLeavesList(event?: any, sorting?: any) {
    var params = {};
    params['pageSize'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['pageIndex'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? ((sorting.direction) ? sorting.direction : 'asc'): 'asc'; // be default sorting will be in Ascending order

    this._service.getAppliedLeaves(params).subscribe(
      data => {
        this.leavesList = new MatTableDataSource([
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 1, status: 'Pending'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 2, status: 'Pending'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 10, status: 'Rejected'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 5, status: 'Approved'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 15, status: 'Rejected'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 20, status: 'Rejected'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 2, status: 'Approved'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 3, status: 'Approved'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 4, status: 'Approved'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 1, status: 'Approved'},
          {appliedDate :new Date(), fromDate: new Date(), toDate: new Date(), totalDays : 3, status: 'Approved'},
        ]);
        this.leavesList.sort = this.sort;
        this.totalRecords = data.totalRecords;
        // this.leavesList.paginator = this.paginator;
        this.pageSize = params['pageSize'];
      });
    // console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getLeavesList();
  }
  sortTable(event) {
    console.log(event);
    this.getLeavesList(null, event);
  }
  applyLeave(content, type: boolean, leave?){
    this.modalHeader = type ? "Apply": "Update";
    this.leaveForm.reset();
    if (!type) {
      console.log("leave--",leave);
      this.leaveForm.patchValue(leave, { onlySelf: true });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }

  // getleavePlans(){
  //   this._leavesService.getLeavePlansDropdown().subscribe(data=>{
  //     if(data){
  //       this.LeavePlan = data;
  //     }
  //   })
  // }
  onSubmit(){
    this.submitted = true;
    if(this.leaveForm.valid){
      this._toast.show('success','Leave applied successfully');
      this.modalService.dismissAll();
    }
  }
  // public hasError = (controlName: string, errorName: string) =>{
  //   return this.leaveForm.controls[controlName].hasError(errorName);
  // }

  public hasError(controlName: string, errorName: string, groupName?: string) {
    if (groupName)
      return this.leaveForm.controls[groupName].get(controlName).hasError(errorName)
    else
      return this.leaveForm.controls[controlName].hasError(errorName);
  }
}
