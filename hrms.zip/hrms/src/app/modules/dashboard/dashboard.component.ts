import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';
import { Chart } from 'chart.js';


@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {


  loading = true;
  chart:any
  doughnut
  pie
  constructor(private _toaster: ToasterService, private toastr: ToastrService) { }

  ngOnInit(): void {
   this.barChart()
   this.lineChart()
   this.doughnutChart()
   this.pieChart()
  }
  barChart(){
    this.chart = new Chart('bar', {
      type: 'bar',
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Combo Bar and line Chart'
        },
      },
      data: {
        labels: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'],// on x-axis
        datasets: [
          {
            type: 'bar',
            label: 'My First dataset',
            data: [243, 156, 365, 30, 156, 265, 356, 543],// on y-axis
            backgroundColor: 'blue',
            borderColor: '#0991f1f2',
            fill: false,
          },
          {
            type: 'bar',
            label: 'My Second dataset',
            data: [243, 156, 365, 30, 156, 265, 356, 543].reverse(),// on y-axis
            backgroundColor: 'rgba(0,0,255,0.4)',
            borderColor: 'rgba(0,0,255,0.4)',
            fill: false,
          }
        ]
      }
    });
  }

  lineChart(){
    this.chart = new Chart('line', {
      type: 'line',
      data: {
        labels: ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'],// on x-axis
        datasets: [
          {
            label: 'My First dataset',
            data: [243, 156, 365, 30, 156, 265, 356, 543],// on y-axis
            backgroundColor: 'rgba(255,0,255,0.4)',
            borderColor: 'rgba(255,0,244,0.4)',
            fill:true,
          },
          {
            label: 'My Second dataset',
            data: [243, 156, 365, 30, 156, 265, 356, 543].reverse(),// on y-axis
            backgroundColor: 'rgba(0,0,255,0.4)',
            borderColor: 'rgba(0,0,255,0.4)',
            fill: false,
          }
        ]
      }
    });
  }
  doughnutChart(){
    this.doughnut =  new Chart('doughnut',{
      type: 'doughnut',
      options: {
        spanGaps           : false,
        responsive: true,
        title: {
          display: true,
          text: 'Doughnut Chart'
        },legend: {
					position: 'top',
				},animation: {
					animateScale: true,
					animateRotate: true
				}
      },
      data: {
				datasets: [{
					data: [45,10,5,25,15],
          backgroundColor: ["red","orange","yellow","green","blue"],
          borderWidth:[0,0,0,0,0],
					label: 'Dataset 1'
				}],
				labels: ['Red','Orange','Yellow','Green','Blue']
			}
    })
  }
  pieChart(){
    this.pie = new Chart('pie',{
      type: 'pie',
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Pie Chart'
        },legend: {
					position: 'top',
				},animation: {
					animateScale: true,
					animateRotate: true
				}
      },
      data: {
				datasets: [{
					data: [45,10,5,25,15].reverse(),
					backgroundColor: ["red","orange","yellow","green","blue"],
					label: 'Dataset 1'
				}],
				labels: ['Red','Orange','Yellow','Green','Blue']
			}
    })
  }

  
}
