import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  forgotPassowrdForm : FormGroup;
  loading=false;
  submitted=false;
  hide=true;
  constructor(private _router: Router, private _atoute : ActivatedRoute) { }

  ngOnInit(): void {
    this.forgotPassowrdForm = new FormGroup({
      userName : new FormControl('',[Validators.required])
    });
  }

  onSubmit(){

  }
  goToLogin(){
    this._router.navigate(['login']);
  }
}
