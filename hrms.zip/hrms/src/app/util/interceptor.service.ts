import { HttpErrorResponse, HttpEvent, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable, throwError } from 'rxjs';
import { catchError, map, retry } from 'rxjs/operators';
import { ToasterService } from '../_helpers/toaster/toaster.service';
import { LocalStorageService } from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {
  constructor(private _ls: LocalStorageService, private _router: Router, private _toast: ToasterService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let currentUser = this._ls.getLoggedInUser("user",true);
    // console.log(currentUser);
      if (currentUser!=null) {
        if(currentUser.token){
          req = req.clone({
            setHeaders: {
                Authorization: "Bearer " + currentUser.token,
                // 'content-type': 'application/json',
                'Access-Control-Allow-Origin':'*'
            }
          });
        }
      }
      

   return next.handle(req)

   .pipe(
     retry(1),
     catchError((error: HttpErrorResponse) => {
       let errorMessage = '';
       if (error.error instanceof ErrorEvent) {
         // client-side error
         errorMessage = `Error: ${error.error.message}`;
       } else {
         // server-side error
         errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
       }
       this._toast.show('error',error.error.message);
       return throwError(errorMessage);
     }),
     map((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
         event = event.clone({ body: this.handleResponse(event.body) });
      }
      return event;
    })
   )}
     /* return next.handle(req).pipe(
        map((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
               event = event.clone({ body: this.handleResponse(event.body) });
            }
            return event;
        }));*/
  
    /**
   * @private
   * @author P Swetha
   * @param {any} res
   * @description handling Http Response 
   * @returns json object
   * @memberof HttpInterceptor
   */
  private handleResponse(res) {
    const resJson = res;
    console.log(resJson);
    if (resJson.status) {
      if (resJson.message) {
       if(resJson.token == undefined)
          this._toast.show('success',resJson.message);
      }
    } else {
      this._toast.show('error',resJson.message);
    }
    return resJson;
  }
}
