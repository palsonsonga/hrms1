import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';


@Injectable({
  providedIn: 'root'
})
export class LeavesService {

  subApiUrl = 'admin/leave';

  constructor(private _http: HttpClientService) { }

  getLeavePlanList(params: any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  
  saveLeavePlans(params: any): Observable<any>{
    return this._http.post(this.subApiUrl, params);
  }

  updateLeavePlans(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + '/'+urlParams, params);
  }

  deleteLeavePlans(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params);
  }
  // getLeavePlansDropdown(params: any): Observable<any> {
  //   console.log(params);
  //   return this._http.get(this.subApiUrl+'/list/'+params);
  // }  

}
