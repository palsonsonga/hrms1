import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeOnboardingService {

  subApiUrl = 'onboard/employee';
  constructor(private _http : HttpClientService, private http : HttpClient) { }

  getEmployeesList(params:any): Observable<any> {
    console.log(params);
    return this._http.post(this.subApiUrl+'/page', params);
  }

  saveEmployee(params:any): Observable<any> {
    return this._http.post(this.subApiUrl, params);
  }
  getEmployee(params:any): Observable<any> {
    return this._http.get(this.subApiUrl+"/"+params);
  }
  updateEmployee(params:any,id:any): Observable<any> {
    console.log(params);
    return this._http.put(this.subApiUrl+"/"+id, params);
  }
}
