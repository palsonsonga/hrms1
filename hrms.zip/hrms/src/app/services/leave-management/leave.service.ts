import { Injectable } from '@angular/core';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class LeaveService {
  subApiUrl = 'employee/leave';
  constructor(private _http : HttpClientService) { }
  getAppliedLeaves(parmas?:any){
    return this._http.get(this.subApiUrl+'',parmas);
  }
 
}
